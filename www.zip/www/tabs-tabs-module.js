(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tabs-tabs-module"],{

/***/ "./src/app/tabs/tabs.module.ts":
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.module.ts ***!
  \*************************************/
/*! exports provided: TabsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageModule", function() { return TabsPageModule; });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _tabs_router_module__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./tabs.router.module */ "./src/app/tabs/tabs.router.module.ts");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tabs.page */ "./src/app/tabs/tabs.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var TabsPageModule = /** @class */ (function () {
    function TabsPageModule() {
    }
    TabsPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_0__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _tabs_router_module__WEBPACK_IMPORTED_MODULE_4__["TabsPageRoutingModule"]
            ],
            declarations: [_tabs_page__WEBPACK_IMPORTED_MODULE_5__["TabsPage"]]
        })
    ], TabsPageModule);
    return TabsPageModule;
}());



/***/ }),

/***/ "./src/app/tabs/tabs.page.html":
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n \n     <ion-content *ngIf=\"isAuth\">\n     <ion-header>\n          <ion-toolbar color=\"primary\">\n              <ion-buttons slot=\"start\">\n                  <ion-menu-button></ion-menu-button>\n                </ion-buttons>\n            <ion-title>\n            <!-- <ion-img src=\"/assets/img/logo-white.png\" class=\"logo\"></ion-img> -->\n            <ion-label >Tracking</ion-label>\n            </ion-title>\n          </ion-toolbar>\n        </ion-header>\n        <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n          <ion-refresher-content\n            pullingIcon=\"arrow-dropdown\"\n            pullingText=\"Tirer pour rafraîchir\"\n            refreshingSpinner=\"circles\"\n            refreshingText=\"Rechargement en cours...\">\n          </ion-refresher-content>\n        </ion-refresher>\n      \n\n\n  <ion-tabs >\n\n    <ion-tab-bar slot=\"bottom\" color=\"primary\">\n\n  \n      <ion-tab-button  color=\"primary\" tab=\"faq\" >\n        <ion-icon name=\"chatboxes\"></ion-icon>\n        <ion-label>Questions fréquentes</ion-label>\n      </ion-tab-button>\n  \n      <ion-tab-button  color=\"primary\" tab=\"tab3\">\n          <ion-img src=\"/assets/img/logo-white.png\" class=\"logotalma\"></ion-img>\n        <ion-label>À propos d'Outalma</ion-label>\n      </ion-tab-button>\n    </ion-tab-bar>\n  </ion-tabs>\n</ion-content> \n\n\n"

/***/ }),

/***/ "./src/app/tabs/tabs.page.scss":
/*!*************************************!*\
  !*** ./src/app/tabs/tabs.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n.tab-button-item-active {\n  color: #454EB2; }\n.color-white {\n  color: white; }\n.tab-btn-selected, .tab-btn:hover {\n  color: var(–color-selected); }\nhr {\n  height: 3px !important;\n  width: 100% !important;\n  background: #ABB1B6 !important;\n  display: block !important;\n  font-size: 2em !important;\n  opacity: 1 !important;\n  visibility: visible !important; }\n.bg-dark-blue {\n  background-color: #333986 !important; }\n.outalma-title {\n  color: white;\n  float: left;\n  margin-left: -2vh;\n  margin-top: 1vh; }\n.logo {\n  height: 5vh;\n  margin-left: -4vh;\n  float: left;\n  overflow: hidden; }\n.choix {\n  height: 5vh;\n  margin-bottom: 5vh; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFicy90YWJzLnBhZ2Uuc2NzcyIsInNyYy9hcHAvdGFicy9DOlxcVXNlcnNcXElyaXMgR2VyYWxkb1xcRG9jdW1lbnRzXFxPdXRhbG1hZmluXFxPdXRhbG1hL3NyY1xcYXBwXFx0YWJzXFx0YWJzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxnQkFBZ0I7QUNBaEI7RUFDSSxjQUFjLEVBQUE7QUFNaEI7RUFDSSxZQUFZLEVBQUE7QUFFaEI7RUFDRSwyQkFBTyxFQUFxQjtBQUloQztFQUVFLHNCQUFzQjtFQUN0QixzQkFBc0I7RUFDdEIsOEJBQThCO0VBQzlCLHlCQUF5QjtFQUN6Qix5QkFBeUI7RUFDekIscUJBQXFCO0VBQ3JCLDhCQUE4QixFQUFBO0FBRWhDO0VBQ0Usb0NBQW9DLEVBQUE7QUFLdEM7RUFDRSxZQUFZO0VBQ1osV0FBVTtFQUNWLGlCQUFpQjtFQUNqQixlQUFlLEVBQUE7QUFHakI7RUFDRSxXQUFXO0VBQ1gsaUJBQWdCO0VBQ2hCLFdBQVU7RUFDVixnQkFBZ0IsRUFBQTtBQUdsQjtFQUNFLFdBQVU7RUFDVixrQkFBaUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL3RhYnMvdGFicy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAY2hhcnNldCBcIlVURi04XCI7XG4udGFiLWJ1dHRvbi1pdGVtLWFjdGl2ZSB7XG4gIGNvbG9yOiAjNDU0RUIyOyB9XG5cbi5jb2xvci13aGl0ZSB7XG4gIGNvbG9yOiB3aGl0ZTsgfVxuXG4udGFiLWJ0bi1zZWxlY3RlZCwgLnRhYi1idG46aG92ZXIge1xuICBjb2xvcjogdmFyKOKAk2NvbG9yLXNlbGVjdGVkKTsgfVxuXG5ociB7XG4gIGhlaWdodDogM3B4ICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6ICNBQkIxQjYgIWltcG9ydGFudDtcbiAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAyZW0gIWltcG9ydGFudDtcbiAgb3BhY2l0eTogMSAhaW1wb3J0YW50O1xuICB2aXNpYmlsaXR5OiB2aXNpYmxlICFpbXBvcnRhbnQ7IH1cblxuLmJnLWRhcmstYmx1ZSB7XG4gIGJhY2tncm91bmQtY29sb3I6ICMzMzM5ODYgIWltcG9ydGFudDsgfVxuXG4ub3V0YWxtYS10aXRsZSB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZmxvYXQ6IGxlZnQ7XG4gIG1hcmdpbi1sZWZ0OiAtMnZoO1xuICBtYXJnaW4tdG9wOiAxdmg7IH1cblxuLmxvZ28ge1xuICBoZWlnaHQ6IDV2aDtcbiAgbWFyZ2luLWxlZnQ6IC00dmg7XG4gIGZsb2F0OiBsZWZ0O1xuICBvdmVyZmxvdzogaGlkZGVuOyB9XG5cbi5jaG9peCB7XG4gIGhlaWdodDogNXZoO1xuICBtYXJnaW4tYm90dG9tOiA1dmg7IH1cbiIsIi50YWItYnV0dG9uLWl0ZW0tYWN0aXZle1xuICAgIGNvbG9yOiAjNDU0RUIyO1xuICB9XG5cbi8vICAgLmFjdGl2YXRlZCB7XG4vLyAgICAgYmFja2dyb3VuZC1jb2xvcjogZ3JlZW47XG4vLyAgfSAgXG4gIC5jb2xvci13aGl0ZXtcbiAgICAgIGNvbG9yOiB3aGl0ZTtcbiAgfVxuICAudGFiLWJ0bi1zZWxlY3RlZCwgLnRhYi1idG46aG92ZXIge1xuICAgIGNvbG9yOiB2YXIo4oCTY29sb3Itc2VsZWN0ZWQpO1xuICAgIH1cblxuICAgIFxuaHIge1xuICAvL2JvcmRlcjogMnB4IHNvbGlkIHJlZCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDNweCAhaW1wb3J0YW50O1xuICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kOiAjQUJCMUI2ICFpbXBvcnRhbnQ7XG4gIGRpc3BsYXk6IGJsb2NrICFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogMmVtICFpbXBvcnRhbnQ7XG4gIG9wYWNpdHk6IDEgIWltcG9ydGFudDtcbiAgdmlzaWJpbGl0eTogdmlzaWJsZSAhaW1wb3J0YW50O1xufVxuLmJnLWRhcmstYmx1ZXtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzMzMzk4NiAhaW1wb3J0YW50O1xuICAvLyBwYWRkaW5nLXRvcDogMnZoO1xuICAvLyBwYWRkaW5nLWJvdHRvbTogMnZoO1xufVxuXG4ub3V0YWxtYS10aXRsZXtcbiAgY29sb3I6IHdoaXRlO1xuICBmbG9hdDpsZWZ0O1xuICBtYXJnaW4tbGVmdDogLTJ2aDtcbiAgbWFyZ2luLXRvcDogMXZoO1xufVxuXG4ubG9nbyB7XG4gIGhlaWdodDogNXZoO1xuICBtYXJnaW4tbGVmdDotNHZoO1xuICBmbG9hdDpsZWZ0O1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4uY2hvaXgge1xuICBoZWlnaHQ6NXZoO1xuICBtYXJnaW4tYm90dG9tOjV2aDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/tabs/tabs.page.ts":
/*!***********************************!*\
  !*** ./src/app/tabs/tabs.page.ts ***!
  \***********************************/
/*! exports provided: TabsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPage", function() { return TabsPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_1__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var TabsPage = /** @class */ (function () {
    function TabsPage() {
        this.buttonColorP = '#333986';
        this.buttonColorS = '#333986';
    }
    TabsPage.prototype.ngOnInit = function () {
        var _this = this;
        firebase__WEBPACK_IMPORTED_MODULE_1__["auth"]().onAuthStateChanged(function (user) {
            if (user) {
                _this.isAuth = true;
                // this.navCtrl.navigateForward('tabs/tabs/suivi');
            }
            else {
                _this.isAuth = false;
            }
        });
    };
    TabsPage.prototype.doRefresh = function (event) {
        var _this = this;
        console.log('Rechargement');
        setTimeout(function () {
            console.log('Rechargement en cours');
            _this.ngOnInit();
            event.target.complete();
        }, 2000);
    };
    TabsPage.prototype.beSelectedP = function () {
        this.buttonColorP = '#454EB2'; //desired Color
        this.buttonColorS = '#333986'; //desired Color
    };
    TabsPage.prototype.beSelectedS = function () {
        this.buttonColorS = '#454EB2'; //desired Color
        this.buttonColorP = '#333986'; //desired Color
    };
    TabsPage.prototype.logOut = function () {
        this.navCtrl.navigateForward('');
    };
    TabsPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-tabs',
            template: __webpack_require__(/*! ./tabs.page.html */ "./src/app/tabs/tabs.page.html"),
            styles: [__webpack_require__(/*! ./tabs.page.scss */ "./src/app/tabs/tabs.page.scss")]
        })
    ], TabsPage);
    return TabsPage;
}());



/***/ }),

/***/ "./src/app/tabs/tabs.router.module.ts":
/*!********************************************!*\
  !*** ./src/app/tabs/tabs.router.module.ts ***!
  \********************************************/
/*! exports provided: TabsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TabsPageRoutingModule", function() { return TabsPageRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _tabs_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tabs.page */ "./src/app/tabs/tabs.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};



var routes = [
    {
        path: 'tabs',
        component: _tabs_page__WEBPACK_IMPORTED_MODULE_2__["TabsPage"],
        children: [
            {
                path: 'tab1',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab1/tab1.module#Tab1PageModule'
                    }
                ]
            },
            {
                path: 'tab2',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab2/tab2.module#Tab2PageModule'
                    }
                ]
            },
            {
                path: 'tab3',
                children: [
                    {
                        path: '',
                        loadChildren: '../tab3/tab3.module#Tab3PageModule'
                    }
                ]
            },
            {
                path: 'faq',
                children: [
                    {
                        path: '',
                        loadChildren: '../faq/faq.module#FaqPageModule'
                    }
                ]
            },
            {
                path: 'message2',
                children: [
                    {
                        path: '',
                        loadChildren: '../message2/message2.module#Message2PageModule'
                    }
                ]
            },
            {
                path: 'message3',
                children: [
                    {
                        path: '',
                        loadChildren: '../message3/message2.module#Message2PageModule'
                    }
                ]
            },
            {
                path: 'suivi',
                children: [
                    {
                        path: '',
                        loadChildren: '../suivi/suivi.module#SuiviPageModule'
                    }
                ]
            },
            {
                path: 'suivi-demande',
                children: [
                    {
                        path: '',
                        loadChildren: '../suivi-demande/suivi-demande.module#SuiviDemandePageModule'
                    }
                ]
            },
            {
                path: 'tableau-suivi',
                children: [
                    {
                        path: '',
                        loadChildren: '../tableau-suivi/tableau-suivi.module#TableauSuiviPageModule'
                    }
                ]
            },
            {
                path: 'forms',
                children: [
                    {
                        path: '',
                        loadChildren: '../forms/forms.module#FormsPageModule'
                    }
                ]
            },
            {
                path: 'form1',
                children: [
                    {
                        path: '',
                        loadChildren: '../form1/form1.module#Form1PageModule'
                    }
                ]
            },
            {
                path: 'form2',
                children: [
                    {
                        path: '',
                        loadChildren: '../form2/form2.module#Form2PageModule'
                    }
                ]
            },
            {
                path: 'form3',
                children: [
                    {
                        path: '',
                        loadChildren: '../form3/form3.module#Form3PageModule'
                    }
                ]
            },
            {
                path: '',
                redirectTo: '/tabs/tab1',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: '/tabs/tab1',
        pathMatch: 'full'
    }
];
var TabsPageRoutingModule = /** @class */ (function () {
    function TabsPageRoutingModule() {
    }
    TabsPageRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild(routes)
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], TabsPageRoutingModule);
    return TabsPageRoutingModule;
}());



/***/ })

}]);
//# sourceMappingURL=tabs-tabs-module.js.map