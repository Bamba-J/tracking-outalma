(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./src/app/Modal/contact/contact.module.ts":
/*!*************************************************!*\
  !*** ./src/app/Modal/contact/contact.module.ts ***!
  \*************************************************/
/*! exports provided: ContactPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactPageModule", function() { return ContactPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _contact_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./contact.page */ "./src/app/Modal/contact/contact.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var ContactPageModule = /** @class */ (function () {
    function ContactPageModule() {
    }
    ContactPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
            ],
            declarations: [_contact_page__WEBPACK_IMPORTED_MODULE_4__["ContactPage"]],
            entryComponents: [
                _contact_page__WEBPACK_IMPORTED_MODULE_4__["ContactPage"]
            ]
        })
    ], ContactPageModule);
    return ContactPageModule;
}());



/***/ }),

/***/ "./src/app/Modal/contact/contact.page.html":
/*!*************************************************!*\
  !*** ./src/app/Modal/contact/contact.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Nous contacter</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  <iframe src=\"https://www.outalma.com/outalma-maritime/contact\" height=\"99%\" width=\"99%\"></iframe>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/Modal/contact/contact.page.scss":
/*!*************************************************!*\
  !*** ./src/app/Modal/contact/contact.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL01vZGFsL2NvbnRhY3QvY29udGFjdC5wYWdlLnNjc3MifQ== */"

/***/ }),

/***/ "./src/app/Modal/contact/contact.page.ts":
/*!***********************************************!*\
  !*** ./src/app/Modal/contact/contact.page.ts ***!
  \***********************************************/
/*! exports provided: ContactPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContactPage", function() { return ContactPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var ContactPage = /** @class */ (function () {
    function ContactPage(modalCtrl, actionSheetController) {
        this.modalCtrl = modalCtrl;
        this.actionSheetController = actionSheetController;
    }
    ContactPage.prototype.ngOnInit = function () {
    };
    ContactPage.prototype.close = function () {
        this.modalCtrl.dismiss();
    };
    ContactPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-contact',
            template: __webpack_require__(/*! ./contact.page.html */ "./src/app/Modal/contact/contact.page.html"),
            styles: [__webpack_require__(/*! ./contact.page.scss */ "./src/app/Modal/contact/contact.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ActionSheetController"]])
    ], ContactPage);
    return ContactPage;
}());



/***/ }),

/***/ "./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.module.ts ***!
  \***************************************************************************/
/*! exports provided: RgpdConfidentialitePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RgpdConfidentialitePageModule", function() { return RgpdConfidentialitePageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _rgpd_confidentialite_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./rgpd-confidentialite.page */ "./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var RgpdConfidentialitePageModule = /** @class */ (function () {
    function RgpdConfidentialitePageModule() {
    }
    RgpdConfidentialitePageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"]
            ],
            declarations: [_rgpd_confidentialite_page__WEBPACK_IMPORTED_MODULE_4__["RgpdConfidentialitePage"]],
            entryComponents: [
                _rgpd_confidentialite_page__WEBPACK_IMPORTED_MODULE_4__["RgpdConfidentialitePage"]
            ]
        })
    ], RgpdConfidentialitePageModule);
    return RgpdConfidentialitePageModule;
}());



/***/ }),

/***/ "./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.page.html":
/*!***************************************************************************!*\
  !*** ./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.page.html ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>POLITIQUE DE CONFIDENTIALITÉ</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<style>\n  .box {\n    background: rgba(79, 82, 247, 0.3);\n    padding: 5%;\n    border-radius: 10px;\n  }\n\n  div.transbox {\n    margin-top: 3%;\n    background-color: #ffffff;\n    border: 1px solid black;\n    opacity: 0.6;\n    filter: alpha(opacity=60);\n    border-radius: 10px;\n    /* For IE8 and earlier */\n  }\n\n  div.transbox p {\n    margin: 5%;\n    /* font-weight: bold; */\n    color: #000000;\n  }\n\n  div.transbox li {\n    margin: 5%;\n    /* font-weight: bold; */\n    color: #000000;\n  }\n\n  div.transbox h2 {\n    margin: 5%;\n\n  }\n</style>\n\n<ion-content padding>\n  <div class=\"box\">\n    <h1>Politique de protection de la vie privée et des données personnelles</h1>\n    <div class=\"transbox\">\n    <p>L’entreprise Outalma s’engage à protéger et à respecter votre vie privée et vos données personnelles. La présente\n      politique de protection de la vie privée et des données personnelles a pour but d’expliquer la manière dont notre\n      entreprise collecte et traite vos données personnelles.</p>\n\n    <p>Notre entreprise prend les mesures nécessaires pour respecter le Règlement général sur la protection des données\n      du 27 avril 2016, entré en vigueur le 25 mai 2018, ainsi que les lois nationales sur la vie privée et la\n      protection des données.</p>\n    </div>\n    <div class=\"transbox\">\n      <h2>Qui traite vos données personnelles ?</h2>\n\n      <p>Vos données sont collectées par Outalma par l’intermédiaire de notre prestataire de services d’hébergement et\n        de maintenance de sites Web situé au sein de l’Union européenne.</p>\n\n      <p>Le possesseur de vos données personnelles est Outalma, situé à l’adresse suivante : 8 Place Boulnois, 75017\n        Paris.</p>\n    </div>\n    <div class=\"transbox\">\n      <h2>Quelles sont les données personnelles que nous collectons ?</h2>\n\n      <p>Nous collectons automatiquement vos données de navigation, et votre adresse IP lorsque vous consultez notre\n        site\n        Web.</p>\n\n      <p>Nous collectons également des données personnelles telles que vos nom, prénom, adresse électronique, numéro de\n        téléphone, adresse lorsque vous choisissez de nous les fournir volontairement en utilisant notre formulaire\n        d’inscription ou en effectuant une demande de livraison.</p>\n    </div>\n    <div class=\"transbox\">\n      <h2>Quand collectons-nous vos données personnelles ?</h2>\n\n      <p>Nous collectons les données personnelles que vous nous fournissez volontairement quand :</p>\n      <ol>\n        <li>vous utilisez le formulaire d’inscription ;</li>\n        <li>vous effectuez une demande de livraison.</li>\n      </ol>\n      <p>Nous vous informons que la collecte des informations que vous nous fournissez dans le formulaire d’inscription\n        est nécessaire pour traiter votre demande.</p>\n    </div>\n    <div class=\"transbox\">\n      <h2>Quel est le cadre légal du traitement de vos données personnelles ?</h2>\n\n      <p>Le traitement de vos données personnelles est basé sur votre consentement, donné lors de votre inscription et\n        lors du traitement de vos demandes.</p>\n\n      <p>Lorsque nous traitons les données de navigation et l’adresse IP, le traitement des données personnelles est\n        basé\n        sur notre intérêt légitime à consulter des statistiques sur l’utilisation de notre site Web.</p>\n    </div>\n    <div class=\"transbox\">\n      <h2>Comment utilisons-nous vos données personnelles ?</h2>\n\n      <p>Nous utilisons les données personnelles collectées aux fins suivantes :</p>\n\n        <li>traitement de vos demandes</li>\n        \n    </div>\n    <div class=\"transbox\">\n      <h2>Collecte et utilisation des cookies</h2>\n\n      <p>Nous utilisons et collectons des cookies de l’utilisateur de notre site Web. Veuillez consulter notre politique\n        en matière de cookies pour en savoir plus.</p>\n    </div>\n    <div class=\"transbox\">\n      <h2>Qui sont les destinataires de vos données personnelles ?</h2>\n\n      <p>Vos données personnelles, qui sont collectées directement par Outalma ou par l’intermédiaire de ses\n        prestataires\n        de services de maintenance et d’hébergement de sites Web situés au sein de l’Union européenne, sont destinées\n        exclusivement à l’usage d’Outalma.</p>\n\n      <p>Aucune communication à d’autres tiers ou entreprises n’est envisagée sans l’accord préalable de l’utilisateur,\n        à\n        l’exception des communications et divulgations obligatoires pour satisfaire aux exigences légales et\n        réglementaires, ou à la demande légitime et fondée d’une administration ou d’une autorité judiciaire.</p>\n    </div>\n    <div class=\"transbox\">\n      <h2>Où vos données personnelles sont-elles conservées ?</h2>\n\n      <p>Vos données personnelles sont conservées soit dans nos bases de données, soit dans celles de nos prestataires\n        de\n        services qui sont situés au sein de l’Union européenne. Nos prestataires de services ne traiteront pas vos\n        données\n        personnelles.</p>\n    </div>\n    <div class=\"transbox\">\n      <h2>La sécurité de vos données personnelles</h2>\n\n      <p>Nous prenons toutes les mesures nécessaires pour empêcher, dans la mesure du possible, toute modification ou\n        perte de vos données personnelles et/ou tout accès non autorisé à celles-ci.</p>\n    </div>\n    <div class=\"transbox\">\n      <h2>Quelle est la durée de conservation de vos données personnelles ?</h2>\n\n      <p>Les données personnelles collectées via ce site Web sont conservées pendant une période qui n’excède pas la\n        durée\n        nécessaire à la finalité pour laquelle elles ont été collectées. Les données collectées via ce site Web sont\n        conservées pendant 3 ans au maximum.</p>\n    </div>\n    <div class=\"transbox\">\n      <h2>Quels sont vos droits en ce qui concerne vos données personnelles ?</h2>\n\n      <p>Conformément au Règlement général sur la protection des données du 27 avril 2016, vous avez un droit d’accès,\n        de\n        rectification, d’effacement ou d’opposition à l’utilisation de vos données personnelles. En outre, vous avez le\n        droit de demander la limitation du traitement ou de la transférabilité des données.</p>\n\n      <p>Conformément au règlement général sur la protection des données du 27 avril 2016, vous avez le droit de déposer\n        une réclamation auprès des autorités nationales compétentes en matière de protection des données.</p>\n    </div>\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.page.scss":
/*!***************************************************************************!*\
  !*** ./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.page.scss ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL01vZGFsL3JncGQtY29uZmlkZW50aWFsaXRlL3JncGQtY29uZmlkZW50aWFsaXRlLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.page.ts":
/*!*************************************************************************!*\
  !*** ./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.page.ts ***!
  \*************************************************************************/
/*! exports provided: RgpdConfidentialitePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RgpdConfidentialitePage", function() { return RgpdConfidentialitePage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var RgpdConfidentialitePage = /** @class */ (function () {
    function RgpdConfidentialitePage(modalCtrl) {
        this.modalCtrl = modalCtrl;
    }
    RgpdConfidentialitePage.prototype.ngOnInit = function () {
    };
    RgpdConfidentialitePage.prototype.close = function () {
        this.modalCtrl.dismiss();
    };
    RgpdConfidentialitePage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-rgpd-confidentialite',
            template: __webpack_require__(/*! ./rgpd-confidentialite.page.html */ "./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.page.html"),
            styles: [__webpack_require__(/*! ./rgpd-confidentialite.page.scss */ "./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"]])
    ], RgpdConfidentialitePage);
    return RgpdConfidentialitePage;
}());



/***/ }),

/***/ "./src/app/Modal/rgpd-cookies/rgpd-cookies.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/Modal/rgpd-cookies/rgpd-cookies.module.ts ***!
  \***********************************************************/
/*! exports provided: RgpdCookiesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RgpdCookiesPageModule", function() { return RgpdCookiesPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _rgpd_cookies_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./rgpd-cookies.page */ "./src/app/Modal/rgpd-cookies/rgpd-cookies.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var RgpdCookiesPageModule = /** @class */ (function () {
    function RgpdCookiesPageModule() {
    }
    RgpdCookiesPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"]
            ],
            declarations: [_rgpd_cookies_page__WEBPACK_IMPORTED_MODULE_4__["RgpdCookiesPage"]],
            entryComponents: [
                _rgpd_cookies_page__WEBPACK_IMPORTED_MODULE_4__["RgpdCookiesPage"]
            ]
        })
    ], RgpdCookiesPageModule);
    return RgpdCookiesPageModule;
}());



/***/ }),

/***/ "./src/app/Modal/rgpd-cookies/rgpd-cookies.page.html":
/*!***********************************************************!*\
  !*** ./src/app/Modal/rgpd-cookies/rgpd-cookies.page.html ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>POLITIQUE EN MATIÈRE DE COOKIES</ion-title>\n  </ion-toolbar>\n</ion-header>\n<style>\n  .box {\n    background: rgba(79, 82, 247, 0.3);\n    padding: 5%;\n    border-radius: 10px;\n  }\n\n  div.transbox {\n    margin-top: 3%;\n    background-color: #ffffff;\n    border: 1px solid black;\n    opacity: 0.6;\n    filter: alpha(opacity=60);\n    border-radius: 10px;\n    /* For IE8 and earlier */\n  }\n\n  div.transbox p {\n    margin: 5%;\n    /* font-weight: bold; */\n    color: #000000;\n  }\n  div.transbox li {\n    margin: 5%;\n    /* font-weight: bold; */\n    color: #000000;\n  }\n\n  div.transbox h2 {\n    margin: 5%;\n\n  }\n</style>\n\n<ion-content padding>\n  <div class=\"box\">\n      <div class=\"transbox\">\n    <p>La présente politique relative aux cookies complète notre politique de confidentialité et de protection des\n      données personnelles. Elle vous permet de configurer vos cookies et d’en savoir plus sur vos droits, ainsi que sur\n      l’origine et l’utilisation des informations de navigation traitées lors de votre visite sur notre site.</p>\n    </div><div class=\"transbox\">\n    <h2>Qu’est-ce qu’un cookie ?</h2>\n\n\n    <p>Lors de votre visite sur notre site Internet, un cookie peut s’installer automatiquement sur votre appareil via\n      votre navigateur.</p>\n\n    <p>Un cookie est un fichier texte généré et enregistré par le serveur d’un site Internet que vous consultez\n      directement sur le navigateur de votre appareil (ordinateur, smartphone ou autre type d’appareil). Un cookie\n      permet à ce site Internet de reconnaître le navigateur de votre appareil lors d’une nouvelle connexion à partir du\n      même appareil. Un cookie contient le nom du serveur qui l’a déposé, un identifiant (un numéro unique) et une date\n      d’expiration.</p>\n    </div><div class=\"transbox\">\n    <h2>Quels cookies utilise Outalma sur ce site Internet ?</h2>\n   \n      <li>Cookies nécessaires sur le plan technique</li>\n   \n    <p>Ce type de cookie vise uniquement à faciliter la navigation sur notre site Internet, en permettant une\n      utilisation optimale des différentes fonctions et fonctionnalités disponibles.</p>\n\n    <p>Notre site Internet contient 17 cookies nécessaires techniquement.</p>\n   \n      </div><div class=\"transbox\">\n      <h2>Quel est le but des cookies que nous collectons ?</h2>\n\n      <p>Les cookies ont pour but de garantir le bon fonctionnement de notre site Internet.</p>\n    </div><div class=\"transbox\">\n      <h2>Qui utilise les informations collectées par le biais de ces cookies ?</h2>\n\n      <p>L’entreprise Outalma peut accéder aux données collectées via les cookies et les utiliser.</p>\n    </div><div class=\"transbox\">\n      <h2>Quelle est la durée de conservation de ces cookies ?</h2>\n\n      <p>Les cookies sont conservés pendant douze mois au maximum.</p>\n    </div><div class=\"transbox\">\n\n      <h2>Vos données personnelles collectées via des cookies sont-elles transférées vers d’autres pays ?</h2>\n\n      <p>Non, les données collectées via des cookies ne sont pas transférées vers d’autres pays.</p>\n    </div><div class=\"transbox\">\n      <h2>Comment activer ou désactiver les cookies ?</h2>\n\n      <p>Vous pouvez configurer votre logiciel de navigation pour accepter ou refuser l’enregistrement de cookies sur\n        votre appareil.</p>\n\n      <p>Chaque navigateur possède ses propres outils de configuration de gestion des cookies. Le menu d’assistance de\n        votre navigateur vous permettra de savoir comment modifier vos paramètres de cookies.</p>\n\n      <p>Outalma décline toute responsabilité quant aux conséquences liées à un mauvais fonctionnement de son site\n        Internet et de ses fonctionnalités si vous refusez l’enregistrement de cookies sur votre appareil ou si vous\n        supprimez ceux qui sont enregistrés.</p>\n\n      <p>Veuillez-vous reporter à notre politique de confidentialité et de protection des données personnelles si vous\n        souhaitez obtenir plus d’informations sur la protection de vos données personnelles.</p>\n        </div>\n  </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/Modal/rgpd-cookies/rgpd-cookies.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/Modal/rgpd-cookies/rgpd-cookies.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL01vZGFsL3JncGQtY29va2llcy9yZ3BkLWNvb2tpZXMucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/Modal/rgpd-cookies/rgpd-cookies.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/Modal/rgpd-cookies/rgpd-cookies.page.ts ***!
  \*********************************************************/
/*! exports provided: RgpdCookiesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RgpdCookiesPage", function() { return RgpdCookiesPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};


var RgpdCookiesPage = /** @class */ (function () {
    function RgpdCookiesPage(modalCtrl) {
        this.modalCtrl = modalCtrl;
    }
    RgpdCookiesPage.prototype.ngOnInit = function () {
    };
    RgpdCookiesPage.prototype.close = function () {
        this.modalCtrl.dismiss();
    };
    RgpdCookiesPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-rgpd-cookies',
            template: __webpack_require__(/*! ./rgpd-cookies.page.html */ "./src/app/Modal/rgpd-cookies/rgpd-cookies.page.html"),
            styles: [__webpack_require__(/*! ./rgpd-cookies.page.scss */ "./src/app/Modal/rgpd-cookies/rgpd-cookies.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"]])
    ], RgpdCookiesPage);
    return RgpdCookiesPage;
}());



/***/ }),

/***/ "./src/app/Modal/sign-in/sign-in.module.ts":
/*!*************************************************!*\
  !*** ./src/app/Modal/sign-in/sign-in.module.ts ***!
  \*************************************************/
/*! exports provided: SignInPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignInPageModule", function() { return SignInPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _sign_in_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./sign-in.page */ "./src/app/Modal/sign-in/sign-in.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var SignInPageModule = /** @class */ (function () {
    function SignInPageModule() {
    }
    SignInPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
            ],
            declarations: [_sign_in_page__WEBPACK_IMPORTED_MODULE_4__["SignInPage"]],
            entryComponents: [
                _sign_in_page__WEBPACK_IMPORTED_MODULE_4__["SignInPage"]
            ]
        })
    ], SignInPageModule);
    return SignInPageModule;
}());



/***/ }),

/***/ "./src/app/Modal/sign-in/sign-in.page.html":
/*!*************************************************!*\
  !*** ./src/app/Modal/sign-in/sign-in.page.html ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Inscription</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content *ngIf=\"!isAuth\" padding class=\"bg\">\n  <form [formGroup]=\"authForm\" >\n      <ion-item class=\"{{faux3}}\">\n        <ion-label><ion-icon ios=\"ios-person\" md=\"md-person\"></ion-icon></ion-label>\n          <ion-input placeholder=\"Nom de famille\" type=\"text\" autocomplete=\"true\" [formControl]=\"nom\" clearInput></ion-input>\n    </ion-item>\n    <ion-item class=\"{{faux2}}\">\n      <ion-label><ion-icon ios=\"ios-person\" md=\"md-person\"></ion-icon></ion-label>\n        <ion-input placeholder=\"Prénom\" type=\"text\" autocomplete=\"true\" [formControl]=\"prenom\" clearInput></ion-input>\n  </ion-item>\n    <ion-item class=\"{{faux4}}\">\n      <ion-label><ion-icon name=\"call\"></ion-icon>&nbsp;<ion-icon name=\"add\"></ion-icon></ion-label>\n      <ion-input patern=\"[0-9]{1-11}\" type=\"tel\" inputmode=\"tel\" placeholder=\"ex : 33123456789\" type=\"text\" autocomplete=\"true\"  [formControl]=\"phoneNumber\" clearInput></ion-input>\n    </ion-item>\n    <ion-item>\n        <ion-label><ion-icon ios=\"ios-mail\" md=\"md-mail\"></ion-icon></ion-label>\n          <ion-input pattern=\"[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$\" inputmode=\"email\" placeholder=\"Email\" type=\"email\" [formControl]=\"email\" autocomplete=\"true\" clearInput></ion-input>\n    </ion-item>\n    <ion-item class=\"{{faux5}}\">\n        <ion-label><ion-icon name=\"calendar\"> </ion-icon>&nbsp;&nbsp;Date de naissance :</ion-label><ion-input placeholder=\"Date de naissance\" type=\"date\" [formControl]=\"date\" autocomplete=\"true\"  required clearInput></ion-input>\n    </ion-item>\n    <ion-item class=\"{{faux}}\">\n      <ion-label><ion-icon ios=\"ios-unlock\" md=\"md-unlock\"></ion-icon></ion-label>\n      <ion-input [formControl]=\"password\" id=\"password\" type=\"{{passwordtype}}\" required placeholder=\"Mot de passe\" clearInput></ion-input>\n      <button ion-button fill=\"clear\" autocomplete=\"true\"  class=\"eye-icon-btn buttoneye\" type=\"button\" item-right (click)=\"managePassword()\">\n        <ion-icon name=\"{{passeye}}\"></ion-icon></button>\n    </ion-item>\n    <ion-item class=\"{{faux1}}\">\n      <ion-label><ion-icon ios=\"ios-unlock\" md=\"md-unlock\"></ion-icon></ion-label>\n      <ion-input [formControl]=\"password2\" id=\"password2\" type=\"{{passwordtype2}}\" required placeholder=\"Confirmer le mot de passe\" clearInput></ion-input>\n      <button  ion-button fill=\"clear\" autocomplete=\"true\"  class=\"eye-icon-btn buttoneye\" type=\"button\" item-right (click)=\"managePassword2()\">\n        <ion-icon name=\"{{passeye2}}\"></ion-icon></button>\n    </ion-item> \n\n      <div id=\"recaptcha-container\" ></div>\n\n  </form>\n</ion-content>\n\n<!-- <ion-toolbar color=\"primary\"> -->\n  <ion-button expand=\"block\" type=\"submit\" (click)=\"ionViewDidLoad(); onSubmitForm()\">CRÉER UN COMPTE</ion-button>\n<!-- </ion-toolbar> -->\n"

/***/ }),

/***/ "./src/app/Modal/sign-in/sign-in.page.scss":
/*!*************************************************!*\
  !*** ./src/app/Modal/sign-in/sign-in.page.scss ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .faux {\n  color: red; }\n\n:host .eye-icon-btn {\n  background-color: transparent !important;\n  color: black;\n  font-size: 2.2rem !important; }\n\n:host .buttoneye {\n  color: #333986 !important;\n  background: none !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvTW9kYWwvc2lnbi1pbi9DOlxcVXNlcnNcXElyaXMgR2VyYWxkb1xcRG9jdW1lbnRzXFxPdXRhbG1hZmluXFxPdXRhbG1hL3NyY1xcYXBwXFxNb2RhbFxcc2lnbi1pblxcc2lnbi1pbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFTyxVQUNILEVBQUE7O0FBSEo7RUFNUSx3Q0FBd0M7RUFDeEMsWUFBWTtFQUNaLDRCQUE0QixFQUFBOztBQVJwQztFQVdRLHlCQUEyQjtFQUMzQiwyQkFBNEIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL01vZGFsL3NpZ24taW4vc2lnbi1pbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdHtcclxuICAgIC5mYXV4e1xyXG4gICAgICAgY29sb3I6cmVkXHJcbiAgICB9XHJcblxyXG4gICAgLmV5ZS1pY29uLWJ0bntcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gICAgICAgIGNvbG9yOiBibGFjaztcclxuICAgICAgICBmb250LXNpemU6IDIuMnJlbSAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgLmJ1dHRvbmV5ZXtcclxuICAgICAgICBjb2xvciA6ICAjMzMzOTg2ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgYmFja2dyb3VuZDogIG5vbmUgIWltcG9ydGFudDtcclxuICAgICAgfVxyXG59Il19 */"

/***/ }),

/***/ "./src/app/Modal/sign-in/sign-in.page.ts":
/*!***********************************************!*\
  !*** ./src/app/Modal/sign-in/sign-in.page.ts ***!
  \***********************************************/
/*! exports provided: SignInPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignInPage", function() { return SignInPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var src_Services_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/Services/auth.service */ "./src/Services/auth.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_5__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var nb_gest;
var SignInPage = /** @class */ (function () {
    function SignInPage(modalCtrl, navCtrl, toastCtrl, menuCtrl, authService, formBuilder, alertCtrl, actionSheetController) {
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.toastCtrl = toastCtrl;
        this.menuCtrl = menuCtrl;
        this.authService = authService;
        this.formBuilder = formBuilder;
        this.alertCtrl = alertCtrl;
        this.actionSheetController = actionSheetController;
        this.VigiK = "";
        this.passwordtype = 'password';
        this.passeye = 'eye';
        this.passwordtype2 = 'password';
        this.passeye2 = 'eye';
        this.faux = '';
        this.faux1 = '';
        this.faux2 = '';
        this.faux3 = '';
        this.faux4 = '';
        this.faux5 = '';
    }
    SignInPage.prototype.ngOnInit = function () {
        firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().languageCode = 'fr';
        this.initForm();
    };
    SignInPage.prototype.ionViewDidLoad = function () {
        this.recaptchaVerifier = new firebase__WEBPACK_IMPORTED_MODULE_2__["auth"].RecaptchaVerifier('recaptcha-container', {
            // 'size': 'invisible',
            'callback': function (response) {
                // reCAPTCHA solved - will proceed with submit function
                console.log(response);
                return true;
            },
            'expired-callback': function () {
                console.log('coucou');
            }
        });
    };
    SignInPage.prototype.onSubmitForm = function () {
        var _this = this;
        var password = this.authForm.get('password').value;
        var password2 = this.authForm.get('password2').value;
        var num = this.authForm.get('phoneNumber').value;
        var email2 = num + '@fakeMail.outalma';
        var email = this.authForm.get('email').value;
        var prenom = this.authForm.get('prenom').value;
        var nom = this.authForm.get('nom').value;
        var userName = nom + " " + prenom;
        var phoneNumber = '+' + num;
        var date = this.authForm.get('date').value;
        var navCtrol = this.navCtrl;
        var menuCtrol = this.menuCtrl;
        var addmail = this.AjouteEmail;
        var toast = this.toastCtrl;
        var Bravo = this.presentToastBravo;
        var Modal = this.modalCtrl;
        var present = this.presentToast;
        var str = phoneNumber;
        var ret = "";
        var writeUser = this.writeUserData;
        var appVerifier = this.recaptchaVerifier;
        if (password == null) {
            this.faux = "item ion-focusable hydrated item-label item-interactive item-input item-has-placeholder ion-touched ion-dirty ion-invalid";
        }
        if (password2 == null) {
            this.faux1 = "item ion-focusable hydrated item-label item-interactive item-input item-has-placeholder ion-touched ion-dirty ion-invalid";
        }
        if (prenom == null) {
            this.faux2 = "item ion-focusable hydrated item-label item-interactive item-input item-has-placeholder ion-touched ion-dirty ion-invalid";
        }
        if (nom == null) {
            this.faux3 = "item ion-focusable hydrated item-label item-interactive item-input item-has-placeholder ion-touched ion-dirty ion-invalid";
        }
        if (num == null) {
            this.faux4 = "item ion-focusable hydrated item-label item-interactive item-input item-has-placeholder ion-touched ion-dirty ion-invalid";
        }
        if (date == null) {
            this.faux5 = "item ion-focusable hydrated item-label item-interactive item-input item-has-placeholder ion-touched ion-dirty ion-invalid";
        }
        else if (this.authForm.get('email').valid != true || this.authForm.get('prenom').valid != true || this.authForm.get('nom').valid != true || this.authForm.get('password2').valid != true || this.authForm.get('password').valid != true || this.authForm.get('date').valid != true || this.authForm.get('phoneNumber').valid != true) {
            var err = { code: "Input erronés", message: "" };
            this.presentToast(err, toast);
            console.log('coucou');
        }
        else {
            if (password == password2) {
                for (var i = 0; i < str.length; i++) {
                    if (i >= str.length - 3) {
                        ret += str.charAt(i);
                    }
                    else {
                        ret += "x";
                    }
                }
                firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().signInWithPhoneNumber(phoneNumber, appVerifier)
                    .then(function (confirmationResult) { return __awaiter(_this, void 0, void 0, function () {
                    var prompt;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0: return [4 /*yield*/, this.alertCtrl.create({
                                    header: 'Un code de confimation a été envoyé au : ' + '+' + ret,
                                    inputs: [{ name: 'confirmationCode', placeholder: 'Entrez le code de confirmation' }],
                                    buttons: [
                                        {
                                            text: 'Annuler',
                                            handler: function (data) {
                                                appVerifier.clear();
                                                console.log('Cancel clicked');
                                            }
                                        },
                                        {
                                            text: 'Valider',
                                            handler: function (data) {
                                                confirmationResult.confirm(data.confirmationCode)
                                                    .then(function (result) {
                                                    firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.updateProfile({
                                                        displayName: userName,
                                                        photoURL: date
                                                    });
                                                    if (email == "") {
                                                        var credential = firebase__WEBPACK_IMPORTED_MODULE_2__["auth"].EmailAuthProvider.credential(email2, password);
                                                        firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.linkAndRetrieveDataWithCredential(credential).then(function (usercred) {
                                                            var user = usercred.user;
                                                            Bravo(toast);
                                                            navCtrol.navigateForward('tabs/tabs/forms');
                                                            menuCtrol.enable(true);
                                                            Modal.dismiss();
                                                            writeUser(nom, prenom, email);
                                                        }).catch(function (error) {
                                                            present(error, toast);
                                                            appVerifier.clear();
                                                        });
                                                    }
                                                    else {
                                                        var credential = firebase__WEBPACK_IMPORTED_MODULE_2__["auth"].EmailAuthProvider.credential(email, password);
                                                        firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.linkAndRetrieveDataWithCredential(credential).then(function (usercred) {
                                                            return __awaiter(this, void 0, void 0, function () {
                                                                var user;
                                                                return __generator(this, function (_a) {
                                                                    switch (_a.label) {
                                                                        case 0: return [4 /*yield*/, firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.sendEmailVerification()];
                                                                        case 1:
                                                                            _a.sent();
                                                                            user = usercred.user;
                                                                            writeUser(nom, prenom, email);
                                                                            if (firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.emailVerified == false) {
                                                                                window.alert("Un mail de vérification d'adresse mail vous a été envoyé");
                                                                            }
                                                                            else {
                                                                                Bravo(toast);
                                                                                navCtrol.navigateForward('tabs/tabs/forms');
                                                                                menuCtrol.enable(true);
                                                                                Modal.dismiss();
                                                                            }
                                                                            return [2 /*return*/];
                                                                    }
                                                                });
                                                            });
                                                        }, function (error) {
                                                            present(error, toast);
                                                            appVerifier.clear();
                                                        });
                                                    }
                                                }).catch(function (error) {
                                                    present(error, toast);
                                                    appVerifier.clear();
                                                });
                                            }
                                        }
                                    ]
                                })];
                            case 1:
                                prompt = _a.sent();
                                prompt.present();
                                return [2 /*return*/];
                        }
                    });
                }); }).catch(function (error) {
                    present(error, toast);
                    appVerifier.clear();
                });
            }
            else {
                // this.presentToastBravo(toast)
                this.presentToastMdp();
                appVerifier.clear();
                // 
            }
        }
    };
    // async UpdatePhone(){
    //     const num = this.authForm.get('NewphoneNumber').value;
    //     const phoneNumber = '+' + num;
    //     const appVerifier = this.recaptchaVerifier;
    //     var provider = new firebase.auth.PhoneAuthProvider();
    //     provider.verifyPhoneNumber(phoneNumber, appVerifier)
    //       .then( async confirmationResult => {
    //         let prompt = await this.alertCtrl.create({
    //         header: 'Enter the Confirmation code',
    //         inputs: [{ name: 'confirmationCode', placeholder: 'Entrez le code de confirmation' }],
    //         buttons: [
    //           { text: 'Cancel',
    //             handler: data => { console.log('Cancel clicked'); }
    //           },
    //           { text: 'Send',
    //             handler: data => {
    //               var verificationCode = data.confirmationCode
    //               console.log(confirmationResult,data.confirmationCode)
    //               var credential = firebase.auth.PhoneAuthProvider.credential(confirmationResult,verificationCode);
    //               firebase.auth().signInWithCredential(credential)
    //               .then((function () {
    //               }));
    //             }
    //           }
    //         ]
    //       });
    //       prompt.present()  
    //     })
    //     .catch(function (error) {
    //       console.error('SMS not sent', phoneNumber, error);
    //     });
    // }
    SignInPage.prototype.writeUserData = function (nom, prenom, email) {
        console.log(nom, prenom, email, firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid);
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        console.log('VigiK', VigiK);
        var vide = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(' '.trim(), VigiK.trim()).toString();
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('user/' + firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid).set([
            {
                email: crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(email.trim(), VigiK.trim()).toString(),
                phoneNumber: crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.phoneNumber.trim(), VigiK.trim()).toString(),
                Nom: crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(nom.trim(), VigiK.trim()).toString(),
                Prenom: crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(prenom.trim(), VigiK.trim()).toString(),
                date_naiss: crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.photoURL.trim(), VigiK.trim()).toString(),
                Ad_pay_e: vide,
                Ad_pay_l: vide,
                Ad_pos_e: vide,
                Ad_pos_l: vide,
                Ad_rue_e: vide,
                Ad_rue_l: vide,
                désativé: vide,
                emailVerified: vide,
            }
        ]).then(function (snapshot) {
            console.log('data :', snapshot.val());
        }, function (error) {
            console.log(error);
        });
        ;
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('Gestion/').on("value", function (snapshot) {
            var gest = snapshot.val();
            if (gest == null) {
                nb_gest = 0;
            }
            else {
                nb_gest = gest.length;
            }
        }, function (error) {
            console.log("Error dans Gestion: " + error.code);
        });
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('Gestion/' + nb_gest).set({
            ID: firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid,
            Nom: nom,
            Prenom: prenom
        }).then(function (snapshot) {
            console.log('data :', snapshot.val());
        }, function (error) {
            console.log(error);
        });
    };
    SignInPage.prototype.initForm = function () {
        this.authForm = this.formBuilder.group({
            'nom': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'prenom': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'email': [null],
            'password': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'password2': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'phoneNumber': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
            'date': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_4__["Validators"].required])],
        });
        this.nom = this.authForm.controls['nom'];
        this.prenom = this.authForm.controls['prenom'];
        this.email = this.authForm.controls['email'];
        this.password = this.authForm.controls['password'];
        this.password2 = this.authForm.controls['password2'];
        this.phoneNumber = this.authForm.controls['phoneNumber'];
        this.date = this.authForm.controls['date'];
    };
    SignInPage.prototype.AjouteEmail = function (email, email2, userName, password, date, navCtrol, menuCtrol, Bravo, toast) {
        firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.updateProfile({
            displayName: userName,
            photoURL: date
        });
        if (email == "") {
            var credential = firebase__WEBPACK_IMPORTED_MODULE_2__["auth"].EmailAuthProvider.credential(email2, password);
            firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.linkAndRetrieveDataWithCredential(credential).then(function (usercred) {
                var user = usercred.user;
                Bravo(toast);
                navCtrol('tabs/tabs/forms');
                menuCtrol(true);
                console.log("Account linking success", user);
            }, function (error) {
                // this.presentToast(error);
                console.log("Account linking error", error, "email2", email2);
            });
        }
        else {
            var credential = firebase__WEBPACK_IMPORTED_MODULE_2__["auth"].EmailAuthProvider.credential(email, password);
            firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.linkAndRetrieveDataWithCredential(credential).then(function (usercred) {
                return __awaiter(this, void 0, void 0, function () {
                    var user;
                    return __generator(this, function (_a) {
                        switch (_a.label) {
                            case 0: return [4 /*yield*/, firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.sendEmailVerification()];
                            case 1:
                                _a.sent();
                                user = usercred.user;
                                console.log("Account linking success", user);
                                if (firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.emailVerified == false) {
                                    window.alert("Un mail de vérification de l'adresse mail vous a été envoyé.");
                                }
                                else {
                                    this.navCtrl.navigateForward('tabs/tabs/forms');
                                    this.menuCtrl.enable(true);
                                }
                                return [2 /*return*/];
                        }
                    });
                });
            }, function (error) {
                // this.presentToast(error);
                console.log("Account linking error", error, "email", email);
            });
        }
        console.log("email", email, "email2", email2, "password", password);
    };
    SignInPage.prototype.sendEmailVerification = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.sendEmailVerification()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    SignInPage.prototype.presentToast = function (err, toast) {
        return __awaiter(this, void 0, void 0, function () {
            var tooast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (err.code == "auth/provider-already-linked") {
                            err.message = "Cet utilisateur existe déjà.";
                        }
                        // else if (err.code == "auth/argument-error") {
                        //   err.message = "Veuillez vérifier les paramètres du formulaire."
                        // } 
                        else if (err.code == "auth/network-request-failed") {
                            err.message = "Veuillez vérifier vos paramètres réseau.";
                        }
                        else if (err.code == "auth/too-many-request") {
                            err.message = "Les demandes de votre périphérique sont bloquées en raison d'activités inhabituelles. Veuillez réessayer plus tard.";
                        }
                        else if (err.code == "auth/invalid-email") {
                            err.message = "L'email est invalide.";
                        }
                        else if (err.code == "auth/invalid-phone-number") {
                            err.message = "Le format du numéro de téléphone est invalide.";
                        }
                        else if (err.code == "auth/wrong-password") {
                            err.message = "Le mot de passe est invalide.";
                        }
                        else if (err.code == "auth/user-disabled") {
                            err.message = "Le compte a été désactivé par un administrateur. Veuillez contacter le service client.";
                        }
                        else if (err.code == "auth/weak-password") {
                            err.message = "Le mot de passe doit contenir 6 caractères.";
                        }
                        else if (err.code == "Input erronés") {
                            err.message = "Veuillez vérifier les valeurs entrées.";
                        }
                        return [4 /*yield*/, toast.create({
                                message: err.message,
                                duration: 10000,
                                position: 'middle',
                                color: 'danger',
                                showCloseButton: true,
                                closeButtonText: 'FERMER'
                            })];
                    case 1:
                        tooast = _a.sent();
                        tooast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    SignInPage.prototype.presentToastMdp = function () {
        return __awaiter(this, void 0, void 0, function () {
            var toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Les mots de passe ne sont pas identiques.',
                            duration: 10000,
                            position: 'middle',
                            color: 'danger',
                            showCloseButton: true,
                            closeButtonText: 'FERMER'
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    SignInPage.prototype.presentToastBravo = function (toast) {
        return __awaiter(this, void 0, void 0, function () {
            var tooast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, toast.create({
                            message: 'L\'utilisateur a bien été enregitré',
                            duration: 3000,
                            position: 'middle',
                            color: 'success'
                        })];
                    case 1:
                        tooast = _a.sent();
                        tooast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    SignInPage.prototype.moveToHome = function (res) {
        if (firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.email.includes("@outalma.com")) {
            this.navCtrl.navigateForward('tabs/tabs/tableau-suivi');
        }
        else {
            this.navCtrl.navigateForward('tabs/tabs/forms');
        }
        this.menuCtrl.enable(true);
    };
    SignInPage.prototype.close = function () {
        this.modalCtrl.dismiss();
    };
    SignInPage.prototype.managePassword = function () {
        if (this.passwordtype == 'password') {
            this.passwordtype = 'text';
            this.passeye = 'eye-off';
        }
        else {
            this.passwordtype = 'password';
            this.passeye = 'eye';
        }
    };
    SignInPage.prototype.managePassword2 = function () {
        if (this.passwordtype2 == 'password') {
            this.passwordtype2 = 'text';
            this.passeye2 = 'eye-off';
        }
        else {
            this.passwordtype2 = 'password';
            this.passeye2 = 'eye';
        }
    };
    SignInPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-sign-in',
            template: __webpack_require__(/*! ./sign-in.page.html */ "./src/app/Modal/sign-in/sign-in.page.html"),
            styles: [__webpack_require__(/*! ./sign-in.page.scss */ "./src/app/Modal/sign-in/sign-in.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["MenuController"],
            src_Services_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormBuilder"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ActionSheetController"]])
    ], SignInPage);
    return SignInPage;
}());



/***/ }),

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");
/* harmony import */ var _Modal_sign_in_sign_in_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Modal/sign-in/sign-in.module */ "./src/app/Modal/sign-in/sign-in.module.ts");
/* harmony import */ var _Modal_contact_contact_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Modal/contact/contact.module */ "./src/app/Modal/contact/contact.module.ts");
/* harmony import */ var _Modal_up_password_up_password_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Modal/up-password/up-password.module */ "./src/app/Modal/up-password/up-password.module.ts");
/* harmony import */ var _Modal_up_phone_up_phone_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Modal/up-phone/up-phone.module */ "./src/app/Modal/up-phone/up-phone.module.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _Modal_rgpd_confidentialite_rgpd_confidentialite_module__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../Modal/rgpd-confidentialite/rgpd-confidentialite.module */ "./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.module.ts");
/* harmony import */ var _Modal_rgpd_cookies_rgpd_cookies_module__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../Modal/rgpd-cookies/rgpd-cookies.module */ "./src/app/Modal/rgpd-cookies/rgpd-cookies.module.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};













var routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_5__["LoginPage"]
    }
];
var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _Modal_sign_in_sign_in_module__WEBPACK_IMPORTED_MODULE_6__["SignInPageModule"],
                _Modal_contact_contact_module__WEBPACK_IMPORTED_MODULE_7__["ContactPageModule"],
                _Modal_up_password_up_password_module__WEBPACK_IMPORTED_MODULE_8__["UpPasswordPageModule"],
                _Modal_up_phone_up_phone_module__WEBPACK_IMPORTED_MODULE_9__["UpPhonePageModule"],
                _Modal_rgpd_confidentialite_rgpd_confidentialite_module__WEBPACK_IMPORTED_MODULE_11__["RgpdConfidentialitePageModule"],
                _Modal_rgpd_cookies_rgpd_cookies_module__WEBPACK_IMPORTED_MODULE_12__["RgpdCookiesPageModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes),
                _angular_common_http__WEBPACK_IMPORTED_MODULE_10__["HttpClientModule"]
            ],
            declarations: [_login_page__WEBPACK_IMPORTED_MODULE_5__["LoginPage"]]
        })
    ], LoginPageModule);
    return LoginPageModule;
}());



/***/ }),

/***/ "./src/app/login/login.page.html":
/*!***************************************!*\
  !*** ./src/app/login/login.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n\n<ion-header>\n\n  <ion-toolbar  mode=\"md\" class=\"bg-dark-blue\">\n        <ion-title class=\"outalma-title bg-dark-blue centered\">CONNEXION</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content *ngIf=\"!isAuth\" padding class=\"bg\">\n    <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n        <ion-refresher-content\n          pullingIcon=\"arrow-dropdown\"\n          pullingText=\"Tirer pour rafraîchir\"\n          refreshingSpinner=\"circles\"\n          refreshingText=\"Rechargement en cours...\">\n        </ion-refresher-content>\n      </ion-refresher>\n  <form [formGroup]=\"authForm\" >\n   \n    <ion-img src=\"/assets/img/logo-full.png\" class=\"logo centered\"></ion-img>\n    <br><br><br>\n    <ion-item mode=\"md\">\n      <ion-label><ion-icon name=\"call\"></ion-icon>&nbsp;<ion-icon name=\"add\"></ion-icon></ion-label>\n      <ion-input placeholder=\"ex : 33123456789\" autocomplete=\"true\"  type=\"tel\" formControlName=\"phoneNumber\" clearInput></ion-input>\n    </ion-item>\n    <ion-item mode=\"md\">\n      <ion-label><ion-icon ios=\"ios-unlock\" md=\"md-unlock\"></ion-icon>&nbsp;&nbsp;&nbsp;&nbsp;</ion-label>\n      <ion-input  (keyup)=\"fctn()\"  minlength=\"6\"  [formControl]=\"password\"  id=\"password\" type=\"{{passwordtype}}\" required placeholder=\"Mot de passe\"></ion-input>\n      <button ion-button fill=\"clear\" autocomplete=\"true\" class=\"eye-icon-btn buttoneye\" type=\"button\"  item-right (click)=\"managePassword()\">\n        <ion-icon size=\"large\" name=\"{{passeye}}\"></ion-icon></button>\n    </ion-item>\n    <br><br>\n  \n    <div class=\"centered\" id=\"recaptcha-container-login\" ></div>\n    <br><br>\n      <button ion-button class=\"buttongd centered\" type=\"submit\" (click)=\" signIn()\">SE CONNECTER</button>\n    \n    \n  </form>\n  <br><br>\n  <ion-item class=\"centered item connbut buttongd\">\n      <button ion-button class=\"buttong\" (click)=\"goToSignIn()\">Nouveau chez Outalma ? Créez un compte</button>\n      <button ion-button class=\"buttong\" (click)=\"goToUpPassword()\">Mot de passe oublié ?</button>\n      <button ion-button class=\"buttong\" (click)=\"goToUpPhone()\">Vous avez changé de numéro de téléphone ?</button>\n    <br> \n    </ion-item>\n</ion-content>\n\n<div>\n\n</div>\n\n<ion-toolbar  color=\"primary\">\n\n<ion-button size=\"small\" color=\"light\" expand=\"full\"  (click)=\"goToContact()\" fill=\"clear\">Nous contacter</ion-button>\n<div style=\"width:100%;text-align:center\" >\n<a  (click)=\"goToRGPGConfidentialite()\" fill=\"clear\"><label style=\"font-size: 12px\">Privacy Policy&nbsp;&nbsp;</label></a>\n<a  (click)=\"goToRGPGCookies()\" style=\"font-size: 12px\" fill=\"clear\">&nbsp;&nbsp; Cookies Policy</a>\n</div>\n</ion-toolbar>\n\n"

/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host {\n  border-color: none;\n  --inner-border-width: 0px 0px 0px 0px !important;\n  --border: 0px ; }\n  :host page-register .socialLogin {\n    float: left;\n    width: 100%;\n    text-align: center; }\n  :host page-register .facebook {\n    background-color: #3b5998; }\n  :host page-register .google {\n    background-color: #d13d35; }\n  :host page-register .github {\n    background-color: #000000; }\n  :host page-register .twitter {\n    background-color: #728fdb; }\n  :host page-register .container-logo {\n    display: inline-block;\n    width: 100%;\n    margin: 20px 0; }\n  :host page-register .container-logo img {\n      max-width: 250px; }\n  :host page-register .main-content {\n    min-height: 100%; }\n  :host page-register .item-inner {\n    border-bottom: 0px !important; }\n  :host page-register .list-md, :host page-register .list-ios {\n    margin: 0 !important; }\n  :host page-register .list {\n    padding: 0 !important; }\n  :host page-register form .button-md,\n  :host page-register form .button-ios {\n    margin: 0px !important;\n    background-color: black;\n    padding: 26px !important; }\n  :host page-register .form-bottom-text label,\n  :host page-register a {\n    color: white; }\n  :host page-register .errormsg p {\n    background-color: rgba(255, 0, 0, 0.3);\n    color: white;\n    border: 1px solid #FF0000;\n    padding: 5px; }\n  :host page-register .sepretor-or {\n    display: inline-block;\n    width: 100%;\n    text-align: center; }\n  :host page-register .sepretor-or p {\n    color: white;\n    font-size: 16px;\n    text-transform: lowercase; }\n  :host page-register .sepretor-or p::before,\n  :host page-register .sepretor-or p::after {\n    float: left;\n    width: calc(48% - 10px);\n    display: inline-block;\n    height: 1px;\n    margin-top: 8px;\n    background-image: url('bg-outalma-1.jpg');\n    background-repeat: repeat;\n    content: ''; }\n  :host page-register .sepretor-or p::after {\n    float: right; }\n  :host page-register .eye-icon-btn {\n    background-color: transparent !important;\n    color: black;\n    font-size: 2.2rem !important; }\n  hr {\n  height: 3px !important;\n  width: 30% !important;\n  background: #ABB1B6 !important;\n  display: block !important;\n  font-size: 2em !important;\n  opacity: 1 !important;\n  visibility: visible !important; }\n  ion-toolbar {\n  --background: #333986;\n  --opacity: 1; }\n  a {\n  background-color: transparent;\n  color: #f4f5f8; }\n  ion-content .bg {\n  --background-color:red !important;\n  --background:none !important;\n  --background-image: url('bg-outalma-1.jpg');\n  background-repeat: no-repeat;\n  background-size: cover; }\n  ion-item .item {\n  --background: none;\n  --opacity: 1;\n  --min-height: 10px;\n  --border: none !important; }\n  ion-item .itemb {\n  --opacity: 1;\n  --border: 1px solid #333986;\n  border-width: none;\n  border-style: none;\n  border-color: none;\n  --inner-border-width: 0px;\n  border: 1px solid red !important; }\n  .bg-dark-blue {\n  --background-color: #333986 !important;\n  --background: #333986 !important; }\n  .bottom-bar {\n  padding-top: 3vh;\n  padding-bottom: 3vh; }\n  .bottom-hr-centerer {\n  width: 35vh; }\n  .bottom-hr {\n  width: 30vh;\n  color: white; }\n  .item-inner {\n  border: 5px solid blue !important; }\n  .bottom-title {\n  border: 5px solid 333986 !important;\n  z-index: 10000000000 !important;\n  font-size: small;\n  color: white;\n  min-width: 100% !important;\n  height: 100% !important;\n  font-style: italic;\n  border-bottom: 1px solid white; }\n  .buttongd {\n  margin-left: auto;\n  margin-right: auto;\n  text-align: center;\n  color: #333986 !important;\n  background: none !important;\n  width: 48vh !important;\n  border-left: 1px solid #333986;\n  border-right: 1px solid #333986;\n  font-weight: bold;\n  font-size: 15px; }\n  .buttong {\n  margin-left: auto;\n  margin-right: auto;\n  text-align: center;\n  color: #333986 !important;\n  background: none !important;\n  width: 48vh !important; }\n  .buttoneye {\n  color: #333986 !important;\n  background: none !important; }\n  .buttongd-between {\n  margin-left: auto;\n  margin-right: auto;\n  text-align: center;\n  color: #333986 !important;\n  background: #333986 !important;\n  width: 2% !important; }\n  .centered {\n  margin-left: auto;\n  margin-right: auto;\n  text-align: center;\n  width: 100% !important; }\n  .centered2 {\n  margin-left: -2% !important;\n  margin-right: auto;\n  text-align: center;\n  width: 100% !important; }\n  .choix {\n  height: 5vh;\n  margin-bottom: 5vh; }\n  .connbut {\n  margin-top: 5%; }\n  .logo {\n  height: 5vh;\n  float: left;\n  overflow: hidden; }\n  .inputer {\n  margin-top: 1vh;\n  width: 40vh; }\n  .input-container {\n  height: 40vh; }\n  .outalma-title {\n  color: white;\n  width: 100% !important;\n  height: 100% !important;\n  margin-top: 1vh; }\n  .small-font {\n  font-size: small;\n  text-align: left;\n  color: #333986 !important;\n  width: 100%; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vQzpcXFVzZXJzXFxJcmlzIEdlcmFsZG9cXERvY3VtZW50c1xcT3V0YWxtYWZpblxcT3V0YWxtYS9zcmNcXGFwcFxcbG9naW5cXGxvZ2luLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVFLGtCQUFrQjtFQUNsQixnREFBcUI7RUFDcEIsY0FBUyxFQUFBO0VBSlo7SUFRTSxXQUFXO0lBQ1gsV0FBVztJQUNYLGtCQUFrQixFQUFBO0VBVnhCO0lBYU0seUJBQXlCLEVBQUE7RUFiL0I7SUFnQk0seUJBQXlCLEVBQUE7RUFoQi9CO0lBbUJNLHlCQUF5QixFQUFBO0VBbkIvQjtJQXNCTSx5QkFBeUIsRUFBQTtFQXRCL0I7SUF5Qk0scUJBQXFCO0lBQ3JCLFdBQVc7SUFDWCxjQUFjLEVBQUE7RUEzQnBCO01BNkJRLGdCQUFnQixFQUFBO0VBN0J4QjtJQW1DTSxnQkFBZ0IsRUFBQTtFQW5DdEI7SUEyQ00sNkJBQTZCLEVBQUE7RUEzQ25DO0lBOENNLG9CQUFtQixFQUFBO0VBOUN6QjtJQWlETSxxQkFBb0IsRUFBQTtFQWpEMUI7O0lBc0RRLHNCQUFzQjtJQUN0Qix1QkFBdUI7SUFDdkIsd0JBQXdCLEVBQUE7RUF4RGhDOztJQTZETSxZQUFZLEVBQUE7RUE3RGxCO0lBcUVNLHNDQUFrQztJQUNsQyxZQUFZO0lBQ1oseUJBQXlCO0lBQ3pCLFlBQVksRUFBQTtFQXhFbEI7SUEyRU0scUJBQXFCO0lBQ3JCLFdBQVc7SUFDWCxrQkFBa0IsRUFBQTtFQTdFeEI7SUFnRk0sWUFBYztJQUNkLGVBQWU7SUFDZix5QkFBeUIsRUFBQTtFQWxGL0I7O0lBc0ZNLFdBQVc7SUFHWCx1QkFBdUI7SUFDdkIscUJBQXFCO0lBQ3JCLFdBQVc7SUFDWCxlQUFlO0lBQ2YseUNBQTBEO0lBQzFELHlCQUF5QjtJQUN6QixXQUFXLEVBQUE7RUEvRmpCO0lBa0dNLFlBQVksRUFBQTtFQWxHbEI7SUFxR00sd0NBQXdDO0lBQ3hDLFlBQVk7SUFDWiw0QkFBNEIsRUFBQTtFQUtoQztFQUVFLHNCQUFzQjtFQUN0QixxQkFBcUI7RUFDckIsOEJBQThCO0VBQzlCLHlCQUF5QjtFQUN6Qix5QkFBeUI7RUFDekIscUJBQXFCO0VBQ3JCLDhCQUE4QixFQUFBO0VBRWhDO0VBQ0kscUJBQWE7RUFNYixZQUFVLEVBQUE7RUFPZDtFQUNFLDZCQUE2QjtFQUM3QixjQUFjLEVBQUE7RUFJaEI7RUFDRSxpQ0FBbUI7RUFDbkIsNEJBQWE7RUFDYiwyQ0FBbUI7RUFDbkIsNEJBQTRCO0VBQzVCLHNCQUFxQixFQUFBO0VBRXZCO0VBQ0Usa0JBQWE7RUFDYixZQUFVO0VBQ1Ysa0JBQWE7RUFDYix5QkFBUyxFQUFBO0VBR1g7RUFDRSxZQUFVO0VBQ1YsMkJBQVM7RUFDVCxrQkFBa0I7RUFDbEIsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQix5QkFBcUI7RUFDckIsZ0NBQWdDLEVBQUE7RUFHbEM7RUFDRSxzQ0FBbUI7RUFDbkIsZ0NBQWEsRUFBQTtFQUtmO0VBQ0ksZ0JBQWdCO0VBQ2hCLG1CQUFtQixFQUFBO0VBRXZCO0VBQ0ksV0FBVSxFQUFBO0VBRWQ7RUFDRSxXQUFVO0VBQ1YsWUFBVyxFQUFBO0VBR2I7RUFFRSxpQ0FBaUMsRUFBQTtFQUduQztFQUNFLG1DQUFtQztFQUNuQywrQkFBK0I7RUFDL0IsZ0JBQWdCO0VBQ2hCLFlBQVk7RUFDWiwwQkFBMEI7RUFDMUIsdUJBQXVCO0VBR3ZCLGtCQUFrQjtFQUNsQiw4QkFBOEIsRUFBQTtFQUdoQztFQUNFLGlCQUFpQjtFQUNqQixrQkFBa0I7RUFDbEIsa0JBQWtCO0VBQ2xCLHlCQUF5QjtFQUN6QiwyQkFBMkI7RUFDM0Isc0JBQXNCO0VBQ3RCLDhCQUE4QjtFQUM5QiwrQkFBK0I7RUFDL0IsaUJBQWlCO0VBQ2pCLGVBQWUsRUFBQTtFQUVqQjtFQUNFLGlCQUFpQjtFQUNqQixrQkFBa0I7RUFDbEIsa0JBQWtCO0VBQ2xCLHlCQUEyQjtFQUMzQiwyQkFBNEI7RUFDNUIsc0JBQXNCLEVBQUE7RUFHeEI7RUFDRSx5QkFBMkI7RUFDM0IsMkJBQTRCLEVBQUE7RUFFOUI7RUFDRSxpQkFBaUI7RUFDakIsa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQix5QkFBMkI7RUFDM0IsOEJBQStCO0VBQy9CLG9CQUFvQixFQUFBO0VBRXRCO0VBQ0UsaUJBQWlCO0VBQ2pCLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsc0JBQXNCLEVBQUE7RUFFeEI7RUFDRSwyQkFBMkI7RUFDM0Isa0JBQWtCO0VBQ2xCLGtCQUFrQjtFQUNsQixzQkFBc0IsRUFBQTtFQUV4QjtFQUNFLFdBQVU7RUFDVixrQkFBaUIsRUFBQTtFQUdyQjtFQUNFLGNBQWMsRUFBQTtFQUdkO0VBQ0UsV0FBVztFQUNYLFdBQVU7RUFDVixnQkFBZ0IsRUFBQTtFQUdsQjtFQUNFLGVBQWM7RUFHZCxXQUFVLEVBQUE7RUFFWjtFQUNJLFlBQVcsRUFBQTtFQUdmO0VBQ0UsWUFBWTtFQUNaLHNCQUFzQjtFQUN0Qix1QkFBdUI7RUFFdkIsZUFBZSxFQUFBO0VBR2pCO0VBQ0UsZ0JBQWdCO0VBQ2hCLGdCQUFnQjtFQUNoQix5QkFBMkI7RUFDM0IsV0FBVSxFQUFBIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3R7XHJcbiAgXHJcbiAgYm9yZGVyLWNvbG9yOiBub25lO1xyXG4gIC0taW5uZXItYm9yZGVyLXdpZHRoOiAwcHggMHB4IDBweCAwcHggIWltcG9ydGFudDtcclxuICAgLS1ib3JkZXI6IDBweCA7XHJcblxyXG4gICBwYWdlLXJlZ2lzdGVyIHtcclxuICAgIC5zb2NpYWxMb2dpbiB7XHJcbiAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgfVxyXG4gICAgLmZhY2Vib29re1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjM2I1OTk4OztcclxuICAgIH1cclxuICAgIC5nb29nbGV7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICNkMTNkMzU7XHJcbiAgICB9XHJcbiAgICAuZ2l0aHVie1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjMDAwMDAwO1xyXG4gICAgfVxyXG4gICAgLnR3aXR0ZXJ7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6ICM3MjhmZGI7XHJcbiAgICB9XHJcbiAgICAuY29udGFpbmVyLWxvZ28ge1xyXG4gICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBtYXJnaW46IDIwcHggMDtcclxuICAgICAgaW1nIHtcclxuICAgICAgICBtYXgtd2lkdGg6IDI1MHB4O1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAubWFpbi1jb250ZW50IHtcclxuICAgICAgLy8gQGluY2x1ZGUgZmxleGJveCgpO1xyXG4gICAgICAvLyBAaW5jbHVkZSBmbGV4LXdyYXAod3JhcCk7XHJcbiAgICAgIG1pbi1oZWlnaHQ6IDEwMCU7XHJcbiAgICB9XHJcbiAgICAuY29udGFpbmVyLWJvdHRvbSB7XHJcbiAgICAgIC8vIEBpbmNsdWRlIGlubGluZS1mbGV4O1xyXG4gICAgICAvLyBAaW5jbHVkZSBmbGV4LXdyYXAod3JhcCk7XHJcbiAgICAgIC8vIEBpbmNsdWRlIGFsaWduLXNlbGYoZmxleC1lbmQpO1xyXG4gICAgfVxyXG4gICAgLml0ZW0taW5uZXJ7XHJcbiAgICAgIGJvcmRlci1ib3R0b206IDBweCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgLmxpc3QtbWQsIC5saXN0LWlvcyB7XHJcbiAgICAgIG1hcmdpbjowICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAubGlzdCB7XHJcbiAgICAgIHBhZGRpbmc6MCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgZm9ybSB7XHJcbiAgICAgIC5idXR0b24tbWQsXHJcbiAgICAgIC5idXR0b24taW9zIHtcclxuICAgICAgICBtYXJnaW46IDBweCAhaW1wb3J0YW50O1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IGJsYWNrO1xyXG4gICAgICAgIHBhZGRpbmc6IDI2cHggIWltcG9ydGFudDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmZvcm0tYm90dG9tLXRleHQgbGFiZWwsXHJcbiAgICBhIHtcclxuICAgICAgY29sb3I6IHdoaXRlO1xyXG4gICAgfVxyXG4gICAgLy8gYVtkaXNhYmxlZF0sXHJcbiAgICAvLyBidXR0b25bZGlzYWJsZWRdLFxyXG4gICAgLy8gW2lvbi1idXR0b25dW2Rpc2FibGVkXSB7XHJcbiAgICAvLyAgIG9wYWNpdHk6IDAuOCAhaW1wb3J0YW50O1xyXG4gICAgLy8gfVxyXG4gICAgLmVycm9ybXNnIHAge1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI1NSwwLDAsLjMpO1xyXG4gICAgICBjb2xvcjogd2hpdGU7XHJcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNGRjAwMDA7XHJcbiAgICAgIHBhZGRpbmc6IDVweDtcclxuICAgIH1cclxuICAgIC5zZXByZXRvci1vciB7XHJcbiAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIH1cclxuICAgIC5zZXByZXRvci1vciBwIHtcclxuICAgICAgY29sb3I6IHdoaXRlICA7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgdGV4dC10cmFuc2Zvcm06IGxvd2VyY2FzZTtcclxuICAgIH1cclxuICAgIC5zZXByZXRvci1vciBwOjpiZWZvcmUsXHJcbiAgICAuc2VwcmV0b3Itb3IgcDo6YWZ0ZXIge1xyXG4gICAgICBmbG9hdDogbGVmdDtcclxuICAgICAgd2lkdGg6IC13ZWJraXQtY2FsYyg0OCUgLSAxMHB4KTtcclxuICAgICAgd2lkdGg6IC1tb3otY2FsYyg0OCUgLSAxMHB4KTtcclxuICAgICAgd2lkdGg6IGNhbGMoNDglIC0gMTBweCk7XHJcbiAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgaGVpZ2h0OiAxcHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDhweDtcclxuICAgICAgYmFja2dyb3VuZC1pbWFnZTogdXJsKCcuLi8uLi9hc3NldHMvaW1nL2JnLW91dGFsbWEtMS5qcGcnKTtcclxuICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IHJlcGVhdDtcclxuICAgICAgY29udGVudDogJyc7XHJcbiAgICB9XHJcbiAgICAuc2VwcmV0b3Itb3IgcDo6YWZ0ZXIge1xyXG4gICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICB9XHJcbiAgICAuZXllLWljb24tYnRue1xyXG4gICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gICAgICBjb2xvcjogYmxhY2s7XHJcbiAgICAgIGZvbnQtc2l6ZTogMi4ycmVtICFpbXBvcnRhbnQ7XHJcbiAgICAgIH1cclxuICB9XHJcbiAgXHJcbn1cclxuICBociB7XHJcbiAgICAvL2JvcmRlcjogMnB4IHNvbGlkIHJlZCAhaW1wb3J0YW50O1xyXG4gICAgaGVpZ2h0OiAzcHggIWltcG9ydGFudDtcclxuICAgIHdpZHRoOiAzMCUgIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQ6ICNBQkIxQjYgIWltcG9ydGFudDtcclxuICAgIGRpc3BsYXk6IGJsb2NrICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXNpemU6IDJlbSAhaW1wb3J0YW50O1xyXG4gICAgb3BhY2l0eTogMSAhaW1wb3J0YW50O1xyXG4gICAgdmlzaWJpbGl0eTogdmlzaWJsZSAhaW1wb3J0YW50O1xyXG4gIH1cclxuICBpb24tdG9vbGJhciB7XHJcbiAgICAgIC0tYmFja2dyb3VuZDogIzMzMzk4NjtcclxuICAgICAgLy8tLWJvcmRlci1jb2xvcjogIzM4ODBmZjtcclxuICAgICAgLy8tLWJvcmRlci1zdHlsZTogc29saWQ7XHJcbiAgICAgIC8vLS1ib3JkZXItd2lkdGg6IDhweDtcclxuICAgICAgLy8tLWNvbG9yOiAjMzg4MGZmO1xyXG4gICAgICAvLyAtLW1pbi1oZWlnaHQ6IDIwcHg7XHJcbiAgICAgIC0tb3BhY2l0eTogMTtcclxuICAgIC8vICAgLS1wYWRkaW5nLWJvdHRvbTogNHB4O1xyXG4gICAgLy8gICAtLXBhZGRpbmctZW5kOiA0cHg7XHJcbiAgICAvLyAgIC0tcGFkZGluZy1zdGFydDogNHB4O1xyXG4gICAgLy8gICAtLXBhZGRpbmctdG9wOiA0cHg7XHJcbiAgfVxyXG5cclxuICBhIHtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gICAgY29sb3I6ICNmNGY1Zjg7XHJcbn1cclxuXHJcblxyXG4gIGlvbi1jb250ZW50IC5iZ3tcclxuICAgIC0tYmFja2dyb3VuZC1jb2xvcjpyZWQgIWltcG9ydGFudDtcclxuICAgIC0tYmFja2dyb3VuZDpub25lICFpbXBvcnRhbnQ7XHJcbiAgICAtLWJhY2tncm91bmQtaW1hZ2U6IHVybCgnLi4vLi4vYXNzZXRzL2ltZy9iZy1vdXRhbG1hLTEuanBnJyk7XHJcbiAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgYmFja2dyb3VuZC1zaXplOmNvdmVyO1xyXG4gIH1cclxuICBpb24taXRlbSAuaXRlbXtcclxuICAgIC0tYmFja2dyb3VuZDogbm9uZTtcclxuICAgIC0tb3BhY2l0eTogMTtcclxuICAgIC0tbWluLWhlaWdodDogMTBweDtcclxuICAgIC0tYm9yZGVyOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgfSAgXHJcbiAgXHJcbiAgaW9uLWl0ZW0gLml0ZW1ie1xyXG4gICAgLS1vcGFjaXR5OiAxO1xyXG4gICAgLS1ib3JkZXI6IDFweCBzb2xpZCAjMzMzOTg2O1xyXG4gICAgYm9yZGVyLXdpZHRoOiBub25lO1xyXG4gICAgYm9yZGVyLXN0eWxlOiBub25lO1xyXG4gICAgYm9yZGVyLWNvbG9yOiBub25lO1xyXG4gICAgLS1pbm5lci1ib3JkZXItd2lkdGg6IDBweDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHJlZCAhaW1wb3J0YW50O1xyXG4gIH1cclxuXHJcbiAgLmJnLWRhcmstYmx1ZXtcclxuICAgIC0tYmFja2dyb3VuZC1jb2xvcjogIzMzMzk4NiAhaW1wb3J0YW50O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjMzMzOTg2ICFpbXBvcnRhbnQ7XHJcbiAgICAvLyBwYWRkaW5nLXRvcDogMnZoO1xyXG4gICAgLy8gcGFkZGluZy1ib3R0b206IDJ2aDtcclxuICB9XHJcblxyXG4gIC5ib3R0b20tYmFye1xyXG4gICAgICBwYWRkaW5nLXRvcDogM3ZoO1xyXG4gICAgICBwYWRkaW5nLWJvdHRvbTogM3ZoO1xyXG4gIH1cclxuICAuYm90dG9tLWhyLWNlbnRlcmVye1xyXG4gICAgICB3aWR0aDozNXZoO1xyXG4gIH1cclxuICAuYm90dG9tLWhye1xyXG4gICAgd2lkdGg6MzB2aDtcclxuICAgIGNvbG9yOndoaXRlO1xyXG4gIH1cclxuXHJcbiAgLml0ZW0taW5uZXJ7XHJcbiAgICBcclxuICAgIGJvcmRlcjogNXB4IHNvbGlkIGJsdWUgIWltcG9ydGFudDtcclxuICB9XHJcblxyXG4gIC5ib3R0b20tdGl0bGV7XHJcbiAgICBib3JkZXI6IDVweCBzb2xpZCAzMzM5ODYgIWltcG9ydGFudDtcclxuICAgIHotaW5kZXg6IDEwMDAwMDAwMDAwICFpbXBvcnRhbnQ7XHJcbiAgICBmb250LXNpemU6IHNtYWxsO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gICAgbWluLXdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XHJcbiAgICBoZWlnaHQ6IDEwMCUgIWltcG9ydGFudDtcclxuICAgIC8vbWFyZ2luLWxlZnQ6IC0ydmg7XHJcbiAgICAvL21hcmdpbi10b3A6IDF2aDtcclxuICAgIGZvbnQtc3R5bGU6IGl0YWxpYztcclxuICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCB3aGl0ZTtcclxuICB9XHJcblxyXG4gIC5idXR0b25nZHtcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3I6ICMzMzM5ODYgIWltcG9ydGFudDtcclxuICAgIGJhY2tncm91bmQ6IG5vbmUgIWltcG9ydGFudDtcclxuICAgIHdpZHRoOiA0OHZoICFpbXBvcnRhbnQ7XHJcbiAgICBib3JkZXItbGVmdDogMXB4IHNvbGlkICMzMzM5ODY7XHJcbiAgICBib3JkZXItcmlnaHQ6IDFweCBzb2xpZCAjMzMzOTg2O1xyXG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICBmb250LXNpemU6IDE1cHg7XHJcbn1cclxuICAuYnV0dG9uZ3tcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgY29sb3IgOiAgIzMzMzk4NiAhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZDogIG5vbmUgIWltcG9ydGFudDtcclxuICAgIHdpZHRoOiA0OHZoICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG5cclxuICAuYnV0dG9uZXlle1xyXG4gICAgY29sb3IgOiAgIzMzMzk4NiAhaW1wb3J0YW50O1xyXG4gICAgYmFja2dyb3VuZDogIG5vbmUgIWltcG9ydGFudDtcclxuICB9XHJcbiAgLmJ1dHRvbmdkLWJldHdlZW4ge1xyXG4gICAgbWFyZ2luLWxlZnQ6IGF1dG87XHJcbiAgICBtYXJnaW4tcmlnaHQ6IGF1dG87XHJcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICBjb2xvciA6ICAjMzMzOTg2ICFpbXBvcnRhbnQ7XHJcbiAgICBiYWNrZ3JvdW5kOiAgIzMzMzk4NiAhaW1wb3J0YW50O1xyXG4gICAgd2lkdGg6IDIlICFpbXBvcnRhbnQ7XHJcbiAgfVxyXG4gIC5jZW50ZXJlZHtcclxuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxuICB9ICBcclxuICAuY2VudGVyZWQye1xyXG4gICAgbWFyZ2luLWxlZnQ6IC0yJSAhaW1wb3J0YW50O1xyXG4gICAgbWFyZ2luLXJpZ2h0OiBhdXRvO1xyXG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcclxuICB9ICBcclxuICAuY2hvaXgge1xyXG4gICAgaGVpZ2h0OjV2aDtcclxuICAgIG1hcmdpbi1ib3R0b206NXZoO1xyXG4gIH1cclxuICAgIFxyXG4uY29ubmJ1dHtcclxuICBtYXJnaW4tdG9wOiA1JTtcclxufVxyXG5cclxuICAubG9nbyB7XHJcbiAgICBoZWlnaHQ6IDV2aDtcclxuICAgIGZsb2F0OmxlZnQ7XHJcbiAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gIH1cclxuICBcclxuICAuaW5wdXRlcntcclxuICAgIG1hcmdpbi10b3A6MXZoO1xyXG4gICAgLy9ib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XHJcbiAgICAvL2JvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICB3aWR0aDo0MHZoO1xyXG4gIH1cclxuICAuaW5wdXQtY29udGFpbmVye1xyXG4gICAgICBoZWlnaHQ6NDB2aDtcclxuICB9XHJcbiAgXHJcbiAgLm91dGFsbWEtdGl0bGV7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgICB3aWR0aDogMTAwJSAhaW1wb3J0YW50O1xyXG4gICAgaGVpZ2h0OiAxMDAlICFpbXBvcnRhbnQ7XHJcbiAgICAvL21hcmdpbi1sZWZ0OiAtMnZoO1xyXG4gICAgbWFyZ2luLXRvcDogMXZoO1xyXG4gIH1cclxuXHJcbiAgLnNtYWxsLWZvbnR7XHJcbiAgICBmb250LXNpemU6IHNtYWxsO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICAgIGNvbG9yIDogICMzMzM5ODYgIWltcG9ydGFudDtcclxuICAgIHdpZHRoOjEwMCU7XHJcbiAgfVxyXG5cclxuXHJcbi8vIH1cclxuIl19 */"

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var src_Services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/Services/auth.service */ "./src/Services/auth.service.ts");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _Modal_sign_in_sign_in_page__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../Modal/sign-in/sign-in.page */ "./src/app/Modal/sign-in/sign-in.page.ts");
/* harmony import */ var _Modal_contact_contact_page__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../Modal/contact/contact.page */ "./src/app/Modal/contact/contact.page.ts");
/* harmony import */ var _Modal_up_password_up_password_page__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../Modal/up-password/up-password.page */ "./src/app/Modal/up-password/up-password.page.ts");
/* harmony import */ var _Modal_up_phone_up_phone_page__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../Modal/up-phone/up-phone.page */ "./src/app/Modal/up-phone/up-phone.page.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/fesm5/http.js");
/* harmony import */ var _Modal_rgpd_cookies_rgpd_cookies_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../Modal/rgpd-cookies/rgpd-cookies.page */ "./src/app/Modal/rgpd-cookies/rgpd-cookies.page.ts");
/* harmony import */ var _Modal_rgpd_confidentialite_rgpd_confidentialite_page__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../Modal/rgpd-confidentialite/rgpd-confidentialite.page */ "./src/app/Modal/rgpd-confidentialite/rgpd-confidentialite.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (undefined && undefined.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};















var LoginPage = /** @class */ (function () {
    function LoginPage(navCtrl, toastCtrl, menuCtrl, modalCtrl, authService, formBuilder, alertCtrl, HttpCLient, router, document) {
        this.navCtrl = navCtrl;
        this.toastCtrl = toastCtrl;
        this.menuCtrl = menuCtrl;
        this.modalCtrl = modalCtrl;
        this.authService = authService;
        this.formBuilder = formBuilder;
        this.alertCtrl = alertCtrl;
        this.HttpCLient = HttpCLient;
        this.router = router;
        this.mdp8char = "";
        this.passwordtype = 'password';
        this.passeye = 'eye';
        this.passwordtype2 = 'password';
        this.passeye2 = 'eye';
    }
    LoginPage.prototype.ngOnChanges = function (changes) {
    };
    LoginPage.prototype.ngOnInit = function () {
        this.presentToastRGPD();
        firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().languageCode = 'fr';
        this.initForm();
        this.menuCtrl.enable(false);
        if (this.recaptchaVerifier != undefined) {
            this.recaptchaVerifier.clear();
        }
    };
    LoginPage.prototype.fctn = function () {
        // console.log('clic')
        // if (this.authForm.get('password').valid == true) {
        //   this.mdp8char = ""
        // } else {
        //   this.mdp8char = "Veuillez entrer 8 char ptn d merde"
        //   console.log('clicbo')
        // }
    };
    LoginPage.prototype.ionViewDidLoad = function () {
        this.recaptchaVerifier = new firebase__WEBPACK_IMPORTED_MODULE_6__["auth"].RecaptchaVerifier('recaptcha-container-login', {
            // 'size': 'invisible',
            'callback': function (response) {
                // reCAPTCHA solved - will proceed with submit function
                console.log(response);
                return true;
            },
            'expired-callback': function () {
                // Reset reCAPTCHA?
                this.recaptchaVerifier.clear();
                console.log('expired-callback');
            }
        });
    };
    LoginPage.prototype.signIn = function () {
        var _this = this;
        this.ionViewDidLoad();
        var appVerifier = this.recaptchaVerifier;
        var num = this.authForm.get('phoneNumber').value;
        var phoneNumber = '+' + num;
        var password = this.authForm.get('password').value;
        var SubmitForm = this.onSubmitForm;
        var authServ = this.authService;
        var move = this.moveToHome;
        var nav = this.navCtrl;
        var menu = this.menuCtrl;
        var str = phoneNumber;
        var ret = "";
        var toast = this.toastCtrl;
        var presentToast = this.presentToast;
        var deconnect = this.deconnect;
        console.log("authval", this.authForm.get('password').valid, this.authForm.get('phoneNumber').valid);
        if (this.authForm.get('password').valid == true && this.authForm.get('phoneNumber').valid == true) {
            for (var i = 0; i < str.length; i++) {
                if (i >= str.length - 3) {
                    ret += str.charAt(i);
                }
                else {
                    ret += "x";
                }
            }
            firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().signInWithPhoneNumber(phoneNumber, appVerifier)
                .then(function (confirmationResult) { return __awaiter(_this, void 0, void 0, function () {
                var prompt;
                var _this = this;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.alertCtrl.create({
                                header: 'Un code de confimation a été envoyé au : ' + '+' + ret,
                                inputs: [{ name: 'confirmationCode', placeholder: 'Entrez le code de confirmation' }],
                                buttons: [
                                    {
                                        text: 'ANNULER',
                                        handler: function (data) { console.log('Cancel clicked'); _this.recaptchaVerifier.clear(); }
                                    },
                                    {
                                        text: 'VALIDER',
                                        handler: function (data) {
                                            confirmationResult.confirm(data.confirmationCode)
                                                .then(function (result) {
                                                SubmitForm(password, authServ, move, nav, menu, toast, deconnect, presentToast);
                                                console.log(result.user);
                                                appVerifier.clear();
                                            }).catch(function (error) {
                                                console.log(error);
                                                presentToast(error, toast);
                                                appVerifier.clear();
                                                // L'utilisateur ne peut pas se connecter 
                                                // ...
                                            });
                                        }
                                    }
                                ]
                            })];
                        case 1:
                            prompt = _a.sent();
                            prompt.present();
                            return [2 /*return*/];
                    }
                });
            }); })
                .catch(function (error) {
                console.error('SMS not sent', phoneNumber, error);
                presentToast(error, toast);
                appVerifier.clear();
            });
        }
        else {
            var err = { code: "Input erronés", message: "" };
            presentToast(err, toast);
        }
    };
    LoginPage.prototype.initForm = function () {
        this.authForm = this.formBuilder.group({
            'password': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required])],
            'phoneNumber': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_5__["Validators"].required])],
        });
        this.password = this.authForm.controls['password'];
        this.phoneNumber = this.authForm.controls['phoneNumber'];
    };
    LoginPage.prototype.goToSecondPage = function () {
        console.log("second page");
        this.navCtrl.navigateForward('tabs/tabs/suivi');
        this.menuCtrl.enable(true);
    };
    LoginPage.prototype.AjouteNum = function () {
        var num = this.authForm.get('phoneNumber').value;
        var phoneNumber = "+" + num;
        var password = this.authForm.get('password').value;
        var code = "";
        var applicationVerifier = new firebase__WEBPACK_IMPORTED_MODULE_6__["auth"].RecaptchaVerifier('recaptcha-container-login');
        var provider = new firebase__WEBPACK_IMPORTED_MODULE_6__["auth"].PhoneAuthProvider();
        provider.verifyPhoneNumber(phoneNumber, applicationVerifier)
            .then(function (verificationId) {
            var verificationCode = password;
            console.log("verificationId :", verificationId, "code", code);
            // var credential = firebase.auth.PhoneAuthProvider.credential(verificationId,code);
            // firebase.auth().currentUser.updatePhoneNumber(credential);
            return firebase__WEBPACK_IMPORTED_MODULE_6__["auth"].PhoneAuthProvider.credential(verificationId, verificationCode);
        })
            .then(function (phoneCredential) {
            return firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().signInWithCredential(phoneCredential);
        });
        console.log(code);
    };
    LoginPage.prototype.goToSignIn = function () {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _Modal_sign_in_sign_in_page__WEBPACK_IMPORTED_MODULE_7__["SignInPage"],
                            mode: "ios",
                            showBackdrop: true,
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.present();
                        console.log("jeld,");
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.goToRGPGCookies = function () {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _Modal_rgpd_cookies_rgpd_cookies_page__WEBPACK_IMPORTED_MODULE_12__["RgpdCookiesPage"],
                            mode: "ios",
                            showBackdrop: true,
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.goToRGPGConfidentialite = function () {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _Modal_rgpd_confidentialite_rgpd_confidentialite_page__WEBPACK_IMPORTED_MODULE_13__["RgpdConfidentialitePage"],
                            mode: "ios",
                            showBackdrop: true,
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    // SendMail() {
    //   var nodemailer = require('../../../node_modules/nodemailer');
    //   var transporter = nodemailer.createTransport({
    //     host: 'smtp.ionos.fr',
    //     port:587,
    //     secure: false,
    //     auth: {
    //       user: 'notification@tracking.outalma.com',
    //       pass: 'GddPUSqH89$'
    //     }
    //   });
    //   var mailOptions = {
    //     from: 'notification@tracking.outalma.com',
    //     to: 'iris.geraldo@hotmail.fr, setrak.caron@viacesi.fr',
    //     subject: 'Test des mails',
    //     text: 'Coucou c\'est Iris test mail'
    //   };
    //   transporter.sendMail(mailOptions, function (error, info) {
    //     if (error) {
    //       console.log(error);
    //     } else {
    //       console.log('Email sent: ' + info.response);
    //     }
    //   });
    // }
    // SendSMS() {
    //   var Message = "Coucou c'est Iris test ça marche ?"
    //   this.HttpCLient.get("https://api.allmysms.com/http/9.0/?login=pdieye&apiKey=567cae5f68e5385&message=" + Message + "&mobile=00221773733331;0033662235967&tpoa=OUTALMA").subscribe(
    //     (response) => {
    //       console.log(response)
    //     },
    //     (error) => {
    //       console.log('Erreur ! : ' + error);
    //     }
    //   );
    //   console.log('message envoyé')
    // }
    LoginPage.prototype.deconnect = function () {
        firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().signOut();
    };
    LoginPage.prototype.goToUpPhone = function () {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _Modal_up_phone_up_phone_page__WEBPACK_IMPORTED_MODULE_10__["UpPhonePage"],
                            mode: "ios",
                            showBackdrop: true,
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.present();
                        modal.onWillDismiss().then(function () {
                            firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().signOut();
                            console.log("Je t'ai déco");
                        });
                        console.log("jeld,");
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.goToUpPassword = function () {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            mode: "ios",
                            showBackdrop: true,
                            component: _Modal_up_password_up_password_page__WEBPACK_IMPORTED_MODULE_9__["UpPasswordPage"],
                            componentProps: {
                                'phoneNumber': "this.phonehNumber.value"
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.present();
                        modal.onWillDismiss().then(function () {
                            firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().signOut();
                            console.log("Je t'ai déco");
                        });
                        console.log("jeld,");
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.goToContact = function () {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _Modal_contact_contact_page__WEBPACK_IMPORTED_MODULE_8__["ContactPage"],
                            mode: "ios",
                            showBackdrop: true,
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.present();
                        console.log("jeld,");
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.onSubmitForm = function (password, authServ, move, nav, menu, toast, deconnect, presentToast) {
        var email = firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().currentUser.email;
        if (email.includes('@fakeMail.outalma')) {
            authServ.signInUser(email, password).then(function (result) {
                console.log('result >>', result, email);
                move(nav, menu);
                // console.log(this.isAuth)
            }, function (err) {
                deconnect();
                // console.log(this.isAuth)
                console.log('err', err);
                presentToast(err, toast);
            });
        }
        else if (firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().currentUser.emailVerified == false) {
            alert('Veuillez valider votre adresse mail');
        }
        else {
            authServ.signInUser(email, password).then(function (result) {
                console.log('result >>', result, email);
                move(nav, menu);
                // console.log(this.isAuth)
            }, function (err) {
                deconnect();
                // console.log(this.isAuth)
                console.log('err', err);
                presentToast(err, toast);
            });
        }
    };
    LoginPage.prototype.moveToHome = function (nav, menu) {
        if (firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().currentUser.email.includes("@outalma.com")) {
            nav.navigateForward('tabs/tabs/tableau-suivi');
        }
        else {
            nav.navigateForward('tabs/tabs/forms');
        }
        menu.enable(true);
    };
    LoginPage.prototype.presentToast = function (err, toast) {
        return __awaiter(this, void 0, void 0, function () {
            var tooast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (err.code == "auth/provider-already-linked") {
                            err.message = "Cet utilisateur existe déjà.";
                        }
                        else if (err.code == "auth/argument-error") {
                            err.message = "Veuillez vérifier les paramètres du formulaire.";
                        }
                        else if (err.code == "auth/network-request-failed") {
                            err.message = "Veuillez vérifier vos paramètres réseau.";
                        }
                        else if (err.code == "auth/too-many-request") {
                            err.message = "Les demandes de votre périphérique sont bloquées en raison d'activités inhabituelles. Veuillez réessayer plus tard.";
                        }
                        else if (err.code == "auth/invalid-email") {
                            err.message = "L'email est invalide.";
                        }
                        else if (err.code == "auth/invalid-phone-number") {
                            err.message = "Le format du numéro de téléphone est invalide.";
                        }
                        else if (err.code == "auth/wrong-password") {
                            err.message = "Le mot de passe est invalide.";
                        }
                        else if (err.code == "auth/user-disabled") {
                            err.message = "Le compte a été désactivé par un administrateur. Veuillez contacter le service client.";
                        }
                        else if (err.code == "auth/weak-password") {
                            err.message = "Le mot de passe doit contenir 6 caractères.";
                        }
                        else if (err.code == "Input erronés") {
                            err.message = "Veuillez vérifier les valeurs entrées.";
                        }
                        else if (err.message == "Unable to load external reCAPTCHA dependencies!") {
                            err.message = "Veuillez vérifier votre connexion internet.";
                            if (this.recaptchaVerifier != undefined) {
                                this.recaptchaVerifier.clear();
                            }
                        }
                        return [4 /*yield*/, toast.create({
                                message: err.message,
                                duration: 10000,
                                position: 'middle',
                                color: 'danger',
                                showCloseButton: true,
                                closeButtonText: 'FERMER'
                            })];
                    case 1:
                        tooast = _a.sent();
                        tooast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.presentToastMdp = function () {
        return __awaiter(this, void 0, void 0, function () {
            var toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Les mots de passe ne sont pas identiques.',
                            duration: 10000,
                            position: 'middle',
                            color: 'danger',
                            showCloseButton: true,
                            closeButtonText: 'FERMER'
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.presentToastRGPD = function () {
        return __awaiter(this, void 0, void 0, function () {
            var toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: "En poursuivant votre navigation sur ce site, vous acceptez l'utilisation de cookies conformément à notre politique de cookies. ",
                            duration: 50000,
                            color: 'dark',
                            showCloseButton: true,
                            closeButtonText: 'OK'
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.managePassword = function () {
        if (this.passwordtype == 'password') {
            this.passwordtype = 'text';
            this.passeye = 'eye-off';
        }
        else {
            this.passwordtype = 'password';
            this.passeye = 'eye';
        }
    };
    LoginPage.prototype.doRefresh = function (event) {
        var _this = this;
        console.log('Rechargement');
        setTimeout(function () {
            console.log('Rechargement en cours');
            _this.ngOnInit();
            event.target.complete();
        }, 2000);
    };
    LoginPage.prototype.sendEmailVerification = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().currentUser.sendEmailVerification()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.goToOutalma = function () {
        window.open("hdttps://www.outalma.com/contact", '_system', 'location=yes');
    };
    LoginPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! ./login.page.html */ "./src/app/login/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")]
        }),
        __param(9, Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"])(_angular_common__WEBPACK_IMPORTED_MODULE_3__["DOCUMENT"])),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            src_Services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__["FormBuilder"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"],
            _angular_common_http__WEBPACK_IMPORTED_MODULE_11__["HttpClient"],
            _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"], Object])
    ], LoginPage);
    return LoginPage;
}());



/***/ })

}]);
//# sourceMappingURL=login-login-module.js.map