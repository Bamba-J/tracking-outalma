(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["message3-message2-module"],{

/***/ "./src/app/message3/message2.module.ts":
/*!*********************************************!*\
  !*** ./src/app/message3/message2.module.ts ***!
  \*********************************************/
/*! exports provided: Message2PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Message2PageModule", function() { return Message2PageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _message2_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./message2.page */ "./src/app/message3/message2.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _message2_page__WEBPACK_IMPORTED_MODULE_5__["Message2Page"]
    }
];
var Message2PageModule = /** @class */ (function () {
    function Message2PageModule() {
    }
    Message2PageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_message2_page__WEBPACK_IMPORTED_MODULE_5__["Message2Page"]]
        })
    ], Message2PageModule);
    return Message2PageModule;
}());



/***/ }),

/***/ "./src/app/message3/message2.page.html":
/*!*********************************************!*\
  !*** ./src/app/message3/message2.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"primary\">\n        <ion-buttons slot=\"start\">\n            <ion-button (click)=\"close()\">\n              <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n            </ion-button>\n          </ion-buttons>\n      <ion-title >Chat #{{i}}\n      </ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <ion-content padding>\n  \n        \n        <div class=\"mesgs\">\n          <div class=\"msg_history\" >\n            <div *ngFor=\"let message of messages\">\n              \n            <div *ngIf=\"message.itext\">\n              <div class=\"incoming_msg\" >\n                <div class=\"incoming_msg_img\"> <img [src]=\"'assets/img/noavatar.png'\" /> </div>\n                <div class=\"received_msg\">\n                  <div class=\"received_withd_msg\">\n                    <p>{{message.itext}}</p>\n                    <span class=\"time_date\">{{message.idate}}</span></div>\n                    <br>\n                </div>\n              </div>\n            </div>               \n          <div *ngIf=\"message.otext\">\n            <div class=\"outgoing_msg\">\n              <div class=\"sent_msg\">\n                <p>{{message.otext}}</p>\n                <span class=\"time_date\">{{message.odate}}</span> </div>\n            </div>\n          </div>\n        </div>\n  \n          </div>\n  \n  \n    </div>\n  \n  </ion-content>\n  <ion-footer>\n      <ion-toolbar>\n          <ion-buttons slot=\"start\">\n        </ion-buttons>\n        <ion-textarea id=\"IMsg2Send\" class=\"message-input\" placeholder=\"Écrivez votre message\" rows=\"1\" autocapitalize=\"off\" [(ngModel)]=\"Msg2Send\"></ion-textarea>\n        <ion-buttons slot=\"end\">\n          <ion-button color=\"primary\" (click)=\"sendMsg();\">\n            <ion-icon slot=\"icon-only\" name=\"md-send\"></ion-icon>\n          </ion-button>\n        </ion-buttons>\n      </ion-toolbar>\n    </ion-footer>\n  "

/***/ }),

/***/ "./src/app/message3/message2.page.scss":
/*!*********************************************!*\
  !*** ./src/app/message3/message2.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .container {\n  max-width: 1170px;\n  margin: auto; }\n\n:host img {\n  max-width: 100%; }\n\n:host .inbox_people {\n  background: #f8f8f8 none repeat scroll 0 0;\n  float: left;\n  overflow: hidden;\n  width: 40%;\n  border-right: 1px solid #c4c4c4; }\n\n:host .inbox_msg {\n  border: 1px solid #c4c4c4;\n  clear: both;\n  overflow: hidden; }\n\n:host .top_spac {\n  margin: 20px 0 0; }\n\n:host .recent_heading {\n  float: left;\n  width: 40%; }\n\n:host .srch_bar {\n  display: inline-block;\n  text-align: right;\n  width: 60%; }\n\n:host .headind_srch {\n  padding: 10px 29px 10px 20px;\n  overflow: hidden;\n  border-bottom: 1px solid #c4c4c4; }\n\n:host .recent_heading h4 {\n  color: #05728f;\n  font-size: 21px;\n  margin: auto; }\n\n:host .srch_bar input {\n  border: 1px solid #cdcdcd;\n  border-width: 0 0 1px 0;\n  width: 80%;\n  padding: 2px 0 4px 6px;\n  background: none; }\n\n:host .srch_bar .input-group-addon button {\n  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;\n  border: medium none;\n  padding: 0;\n  color: #707070;\n  font-size: 18px; }\n\n:host .srch_bar .input-group-addon {\n  margin: 0 0 0 -27px; }\n\n:host .chat_ib h5 {\n  font-size: 15px;\n  color: #464646;\n  margin: 0 0 8px 0; }\n\n:host .chat_ib h5 span {\n  font-size: 13px;\n  float: right; }\n\n:host .chat_ib p {\n  font-size: 14px;\n  color: #989898;\n  margin: auto; }\n\n:host .chat_img {\n  float: left;\n  width: 11%; }\n\n:host .chat_ib {\n  float: left;\n  padding: 0 0 0 15px;\n  width: 88%; }\n\n:host .chat_people {\n  overflow: hidden;\n  clear: both; }\n\n:host .chat_list {\n  border-bottom: 1px solid #c4c4c4;\n  margin: 0;\n  padding: 18px 16px 10px; }\n\n:host .inbox_chat {\n  height: 550px;\n  overflow-y: scroll; }\n\n:host .active_chat {\n  background: #ebebeb; }\n\n:host .incoming_msg_img {\n  display: inline-block;\n  width: 6%; }\n\n:host .received_msg {\n  display: inline-block;\n  padding: 0 0 0 10px;\n  vertical-align: top;\n  width: 92%; }\n\n:host .received_withd_msg p {\n  background: #ebebeb none repeat scroll 0 0;\n  border-radius: 3px;\n  color: #646464;\n  font-size: 14px;\n  margin: 0;\n  padding: 5px 10px 5px 12px;\n  width: 100%; }\n\n:host .time_date {\n  color: #747474;\n  display: block;\n  font-size: 12px;\n  margin: 8px 0 0; }\n\n:host .received_withd_msg {\n  width: 57%; }\n\n:host .mesgs {\n  float: left;\n  padding: 30px 15px 0 25px;\n  width: 100%; }\n\n:host .sent_msg p {\n  background: #333986 none repeat scroll 0 0;\n  border-radius: 3px;\n  font-size: 14px;\n  margin: 0;\n  color: #fff;\n  padding: 5px 10px 5px 12px;\n  width: 100%; }\n\n:host .outgoing_msg {\n  overflow: hidden;\n  margin: 26px 0 26px; }\n\n:host .sent_msg {\n  float: right;\n  width: 46%; }\n\n:host .input_msg_write input {\n  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;\n  border: medium none;\n  color: #4c4c4c;\n  font-size: 15px;\n  min-height: 48px;\n  width: 100%; }\n\n:host .type_msg {\n  border-top: 1px solid #c4c4c4;\n  position: relative; }\n\n:host .msg_send_btn {\n  background: #05728f none repeat scroll 0 0;\n  border: medium none;\n  border-radius: 50%;\n  color: #fff;\n  cursor: pointer;\n  font-size: 17px;\n  height: 33px;\n  position: absolute;\n  right: 0;\n  top: 11px;\n  width: 33px; }\n\n:host .messaging {\n  padding: 0vh;\n  height: 80%; }\n\n:host .msg_history {\n  height: 100%;\n  overflow-y: auto; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWVzc2FnZTMvQzpcXFVzZXJzXFxJcmlzIEdlcmFsZG9cXERvY3VtZW50c1xcT3V0YWxtYWZpblxcT3V0YWxtYS9zcmNcXGFwcFxcbWVzc2FnZTNcXG1lc3NhZ2UyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUEwRkE7RUFDaUIsaUJBQWdCO0VBQUUsWUFBVyxFQUFBOztBQUQ5QztFQUVXLGVBQWMsRUFBQTs7QUFGekI7RUFJUSwwQ0FBMEM7RUFDMUMsV0FBVztFQUNYLGdCQUFnQjtFQUNoQixVQUFVO0VBQUUsK0JBQThCLEVBQUE7O0FBUGxEO0VBVVEseUJBQXlCO0VBQ3pCLFdBQVc7RUFDWCxnQkFBZ0IsRUFBQTs7QUFaeEI7RUFjaUIsZ0JBQWdCLEVBQUE7O0FBZGpDO0VBaUJ1QixXQUFXO0VBQUUsVUFBUyxFQUFBOztBQWpCN0M7RUFtQlEscUJBQXFCO0VBQ3JCLGlCQUFpQjtFQUNqQixVQUFVLEVBQUE7O0FBckJsQjtFQXVCcUIsNEJBQTJCO0VBQUUsZ0JBQWU7RUFBRSxnQ0FBK0IsRUFBQTs7QUF2QmxHO0VBMEJRLGNBQWM7RUFDZCxlQUFlO0VBQ2YsWUFBWSxFQUFBOztBQTVCcEI7RUE4QnVCLHlCQUF3QjtFQUFFLHVCQUFzQjtFQUFFLFVBQVM7RUFBRSxzQkFBcUI7RUFBRSxnQkFBZSxFQUFBOztBQTlCMUg7RUFnQ1EsbURBQW1EO0VBQ25ELG1CQUFtQjtFQUNuQixVQUFVO0VBQ1YsY0FBYztFQUNkLGVBQWUsRUFBQTs7QUFwQ3ZCO0VBc0NxQyxtQkFBbUIsRUFBQTs7QUF0Q3hEO0VBd0NtQixlQUFjO0VBQUUsY0FBYTtFQUFFLGlCQUFnQixFQUFBOztBQXhDbEU7RUF5Q3dCLGVBQWM7RUFBRSxZQUFXLEVBQUE7O0FBekNuRDtFQTBDa0IsZUFBYztFQUFFLGNBQWE7RUFBRSxZQUFXLEVBQUE7O0FBMUM1RDtFQTRDUSxXQUFXO0VBQ1gsVUFBVSxFQUFBOztBQTdDbEI7RUFnRFEsV0FBVztFQUNYLG1CQUFtQjtFQUNuQixVQUFVLEVBQUE7O0FBbERsQjtFQXFEb0IsZ0JBQWU7RUFBRSxXQUFVLEVBQUE7O0FBckQvQztFQXVEUSxnQ0FBZ0M7RUFDaEMsU0FBUztFQUNULHVCQUF1QixFQUFBOztBQXpEL0I7RUEyRG9CLGFBQWE7RUFBRSxrQkFBa0IsRUFBQTs7QUEzRHJEO0VBNkRvQixtQkFBa0IsRUFBQTs7QUE3RHRDO0VBZ0VRLHFCQUFxQjtFQUNyQixTQUFTLEVBQUE7O0FBakVqQjtFQW9FUSxxQkFBcUI7RUFDckIsbUJBQW1CO0VBQ25CLG1CQUFtQjtFQUNuQixVQUFVLEVBQUE7O0FBdkVsQjtFQTBFUSwwQ0FBMEM7RUFDMUMsa0JBQWtCO0VBQ2xCLGNBQWM7RUFDZCxlQUFlO0VBQ2YsU0FBUztFQUNULDBCQUEwQjtFQUMxQixXQUFXLEVBQUE7O0FBaEZuQjtFQW1GUSxjQUFjO0VBQ2QsY0FBYztFQUNkLGVBQWU7RUFDZixlQUFlLEVBQUE7O0FBdEZ2QjtFQXdGNEIsVUFBVSxFQUFBOztBQXhGdEM7RUEwRlEsV0FBVztFQUNYLHlCQUF5QjtFQUN6QixXQUFXLEVBQUE7O0FBNUZuQjtFQWdHUSwwQ0FBMEM7RUFDMUMsa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixTQUFTO0VBQUUsV0FBVTtFQUNyQiwwQkFBMEI7RUFDMUIsV0FBVSxFQUFBOztBQXJHbEI7RUF1R3FCLGdCQUFlO0VBQUUsbUJBQWtCLEVBQUE7O0FBdkd4RDtFQXlHUSxZQUFZO0VBQ1osVUFBVSxFQUFBOztBQTFHbEI7RUE2R1EsbURBQW1EO0VBQ25ELG1CQUFtQjtFQUNuQixjQUFjO0VBQ2QsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixXQUFXLEVBQUE7O0FBbEhuQjtFQXFIaUIsNkJBQTZCO0VBQUMsa0JBQWtCLEVBQUE7O0FBckhqRTtFQXVIUSwwQ0FBMEM7RUFDMUMsbUJBQW1CO0VBQ25CLGtCQUFrQjtFQUNsQixXQUFXO0VBQ1gsZUFBZTtFQUNmLGVBQWU7RUFDZixZQUFZO0VBQ1osa0JBQWtCO0VBQ2xCLFFBQVE7RUFDUixTQUFTO0VBQ1QsV0FBVyxFQUFBOztBQWpJbkI7RUFtSW1CLFlBQVk7RUFDekIsV0FBVyxFQUFBOztBQXBJakI7RUF1SVEsWUFBWTtFQUNaLGdCQUFnQixFQUFBIiwiZmlsZSI6InNyYy9hcHAvbWVzc2FnZTMvbWVzc2FnZTIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gOmhvc3Qge1xyXG4vLyAgICAgaW9uLXRpdGxlIHtcclxuLy8gICAgICAgdGV4dC10cmFuc2Zvcm06IGNhcGl0YWxpemU7XHJcbi8vICAgICB9XHJcbiAgICBcclxuLy8gICAgIGlvbi1pdGVtIHtcclxuLy8gICAgICAgLS1ib3JkZXItd2lkdGg6IDAhaW1wb3J0YW50O1xyXG4vLyAgICAgICAtLWlubmVyLWJvcmRlci13aWR0aDogMCFpbXBvcnRhbnQ7XHJcbiAgXHJcbi8vICAgICAgIGlvbi1hdmF0YXIge1xyXG4vLyAgICAgICAgIHdpZHRoOiAzNnB4O1xyXG4vLyAgICAgICAgIGhlaWdodDogMzZweDtcclxuLy8gICAgICAgfVxyXG4vLyAgICAgfVxyXG4gICAgXHJcbi8vICAgICAubWVzc2FnZS11c2VyIHtcclxuLy8gICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4vLyAgICAgICBsZWZ0OiA2MHB4O1xyXG4vLyAgICAgICB0b3A6IDEwcHg7XHJcbi8vICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuLy8gICAgICAgY29sb3I6IHJnYmEoMCwwLDAsLjkpO1xyXG4vLyAgICAgfVxyXG4gICAgXHJcbi8vICAgICAubWVzc2FnZS10ZXh0IHtcclxuLy8gICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4vLyAgICAgICBwYWRkaW5nOiA4cHg7XHJcbi8vICAgICAgIGJvcmRlci1yYWRpdXM6IDRweDtcclxuLy8gICAgICAgbWF4LXdpZHRoOiAyNDBweDtcclxuLy8gICAgICAgbWluLXdpZHRoOiAxMzZweDtcclxuLy8gICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4vLyAgICAgICBmb250LWZhbWlseTogTGF0bywgXCJIZWx2ZXRpY2EgTmV1ZVwiLCBcIlJvYm90b1wiLCBcIlNlZ29lIFVJXCIsIHNhbnMtc2VyaWY7XHJcbi8vICAgICAgIGxpbmUtaGVpZ2h0OiAyMHB4O1xyXG4vLyAgICAgICB3aGl0ZS1zcGFjZTogcHJlLWxpbmU7XHJcbi8vICAgICAgIC13ZWJraXQtYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuLy8gICAgICAgYm94LXNpemluZzogYm9yZGVyLWJveDtcclxuICAgIFxyXG4vLyAgICAgICAmLmxlZnQge1xyXG4vLyAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNhN2U0ZWQ7XHJcbi8vICAgICAgICAgY29sb3I6ICM0NDQ7XHJcbi8vICAgICAgICAgZmxvYXQ6IGxlZnQgIWltcG9ydGFudDtcclxuLy8gICAgICAgICBtYXJnaW4tbGVmdDogNDZweDtcclxuLy8gICAgICAgICBtYXJnaW4tdG9wOiAtMTRweDtcclxuLy8gICAgICAgfVxyXG4gICAgXHJcbi8vICAgICAgICYubGVmdDpiZWZvcmUge1xyXG4vLyAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuLy8gICAgICAgICBsZWZ0OiA1NnB4O1xyXG4vLyAgICAgICAgIGNvbnRlbnQ6Jyc7XHJcbi8vICAgICAgICAgd2lkdGg6IDA7XHJcbi8vICAgICAgICAgaGVpZ2h0OiAwO1xyXG4vLyAgICAgICAgIGJvcmRlci13aWR0aDogN3B4IDE0cHggN3B4IDA7XHJcbi8vICAgICAgICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuLy8gICAgICAgICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50ICNhN2U0ZWQgdHJhbnNwYXJlbnQ7XHJcbi8vICAgICAgIH1cclxuICAgIFxyXG4vLyAgICAgICAmLnJpZ2h0IHtcclxuLy8gICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZDdlNGVkO1xyXG4vLyAgICAgICAgIG1hcmdpbi1yaWdodDogMTJweDtcclxuLy8gICAgICAgICBjb2xvcjogIzQ0NDtcclxuLy8gICAgICAgICBmbG9hdDogcmlnaHQgIWltcG9ydGFudDtcclxuLy8gICAgICAgfVxyXG4gICAgXHJcbi8vICAgICAgICYucmlnaHQ6YmVmb3JlIHtcclxuLy8gICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbi8vICAgICAgICAgcmlnaHQ6IDIycHg7XHJcbi8vICAgICAgICAgYm90dG9tOiAyMnB4O1xyXG4vLyAgICAgICAgIGNvbnRlbnQ6Jyc7XHJcbi8vICAgICAgICAgd2lkdGg6IDA7XHJcbi8vICAgICAgICAgaGVpZ2h0OiAwO1xyXG4vLyAgICAgICAgIGJvcmRlci13aWR0aDogN3B4IDAgN3B4IDE0cHg7XHJcbi8vICAgICAgICAgYm9yZGVyLXN0eWxlOiBzb2xpZDtcclxuLy8gICAgICAgICBib3JkZXItY29sb3I6IHRyYW5zcGFyZW50ICNkN2U0ZWQgdHJhbnNwYXJlbnQ7XHJcbi8vICAgICAgIH1cclxuLy8gICAgIH1cclxuICAgIFxyXG4vLyAgICAgLm1lc3NhZ2UtdGltZSB7XHJcbi8vICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuLy8gICAgICAgb3BhY2l0eTogLjY7XHJcbi8vICAgICB9XHJcbiAgICBcclxuLy8gICAgIGlvbi1mb290ZXIge1xyXG4vLyAgICAgICAtLWlvbi10b29sYmFyLWJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci13aGl0ZSk7XHJcbiAgICBcclxuLy8gICAgICAgLm1lc3NhZ2UtaW5wdXQge1xyXG4vLyAgICAgICAgIHBhZGRpbmctbGVmdDogOHB4O1xyXG4vLyAgICAgICB9XHJcbi8vICAgICB9XHJcbiAgICBcclxuLy8gICB9XHJcblxyXG46aG9zdHtcclxuICAgICAgLmNvbnRhaW5lcnttYXgtd2lkdGg6MTE3MHB4OyBtYXJnaW46YXV0bzt9XHJcbiAgICAgIGltZ3sgbWF4LXdpZHRoOjEwMCU7fVxyXG4gICAgICAuaW5ib3hfcGVvcGxlIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjZjhmOGY4IG5vbmUgcmVwZWF0IHNjcm9sbCAwIDA7XHJcbiAgICAgICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgICB3aWR0aDogNDAlOyBib3JkZXItcmlnaHQ6MXB4IHNvbGlkICNjNGM0YzQ7XHJcbiAgICAgIH1cclxuICAgICAgLmluYm94X21zZyB7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2M0YzRjNDtcclxuICAgICAgICBjbGVhcjogYm90aDtcclxuICAgICAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgICB9XHJcbiAgICAgIC50b3Bfc3BhY3sgbWFyZ2luOiAyMHB4IDAgMDt9XHJcblxyXG5cclxuICAgICAgLnJlY2VudF9oZWFkaW5nIHtmbG9hdDogbGVmdDsgd2lkdGg6NDAlO31cclxuICAgICAgLnNyY2hfYmFyIHtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogcmlnaHQ7XHJcbiAgICAgICAgd2lkdGg6IDYwJTtcclxuICAgICAgfVxyXG4gICAgICAuaGVhZGluZF9zcmNoeyBwYWRkaW5nOjEwcHggMjlweCAxMHB4IDIwcHg7IG92ZXJmbG93OmhpZGRlbjsgYm9yZGVyLWJvdHRvbToxcHggc29saWQgI2M0YzRjNDt9XHJcblxyXG4gICAgICAucmVjZW50X2hlYWRpbmcgaDQge1xyXG4gICAgICAgIGNvbG9yOiAjMDU3MjhmO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjFweDtcclxuICAgICAgICBtYXJnaW46IGF1dG87XHJcbiAgICAgIH1cclxuICAgICAgLnNyY2hfYmFyIGlucHV0eyBib3JkZXI6MXB4IHNvbGlkICNjZGNkY2Q7IGJvcmRlci13aWR0aDowIDAgMXB4IDA7IHdpZHRoOjgwJTsgcGFkZGluZzoycHggMCA0cHggNnB4OyBiYWNrZ3JvdW5kOm5vbmU7fVxyXG4gICAgICAuc3JjaF9iYXIgLmlucHV0LWdyb3VwLWFkZG9uIGJ1dHRvbiB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwKSBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xyXG4gICAgICAgIGJvcmRlcjogbWVkaXVtIG5vbmU7XHJcbiAgICAgICAgcGFkZGluZzogMDtcclxuICAgICAgICBjb2xvcjogIzcwNzA3MDtcclxuICAgICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgIH1cclxuICAgICAgLnNyY2hfYmFyIC5pbnB1dC1ncm91cC1hZGRvbiB7IG1hcmdpbjogMCAwIDAgLTI3cHg7fVxyXG5cclxuICAgICAgLmNoYXRfaWIgaDV7IGZvbnQtc2l6ZToxNXB4OyBjb2xvcjojNDY0NjQ2OyBtYXJnaW46MCAwIDhweCAwO31cclxuICAgICAgLmNoYXRfaWIgaDUgc3BhbnsgZm9udC1zaXplOjEzcHg7IGZsb2F0OnJpZ2h0O31cclxuICAgICAgLmNoYXRfaWIgcHsgZm9udC1zaXplOjE0cHg7IGNvbG9yOiM5ODk4OTg7IG1hcmdpbjphdXRvfVxyXG4gICAgICAuY2hhdF9pbWcge1xyXG4gICAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICAgIHdpZHRoOiAxMSU7XHJcbiAgICAgIH1cclxuICAgICAgLmNoYXRfaWIge1xyXG4gICAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICAgIHBhZGRpbmc6IDAgMCAwIDE1cHg7XHJcbiAgICAgICAgd2lkdGg6IDg4JTtcclxuICAgICAgfVxyXG5cclxuICAgICAgLmNoYXRfcGVvcGxleyBvdmVyZmxvdzpoaWRkZW47IGNsZWFyOmJvdGg7fVxyXG4gICAgICAuY2hhdF9saXN0IHtcclxuICAgICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgI2M0YzRjNDtcclxuICAgICAgICBtYXJnaW46IDA7XHJcbiAgICAgICAgcGFkZGluZzogMThweCAxNnB4IDEwcHg7XHJcbiAgICAgIH1cclxuICAgICAgLmluYm94X2NoYXQgeyBoZWlnaHQ6IDU1MHB4OyBvdmVyZmxvdy15OiBzY3JvbGw7fVxyXG5cclxuICAgICAgLmFjdGl2ZV9jaGF0eyBiYWNrZ3JvdW5kOiNlYmViZWI7fVxyXG5cclxuICAgICAgLmluY29taW5nX21zZ19pbWcge1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICB3aWR0aDogNiU7XHJcbiAgICAgIH1cclxuICAgICAgLnJlY2VpdmVkX21zZyB7XHJcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgIHBhZGRpbmc6IDAgMCAwIDEwcHg7XHJcbiAgICAgICAgdmVydGljYWwtYWxpZ246IHRvcDtcclxuICAgICAgICB3aWR0aDogOTIlO1xyXG4gICAgICB9XHJcbiAgICAgIC5yZWNlaXZlZF93aXRoZF9tc2cgcCB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2ViZWJlYiBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcclxuICAgICAgICBjb2xvcjogIzY0NjQ2NDtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgIHBhZGRpbmc6IDVweCAxMHB4IDVweCAxMnB4O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICB9XHJcbiAgICAgIC50aW1lX2RhdGUge1xyXG4gICAgICAgIGNvbG9yOiAjNzQ3NDc0O1xyXG4gICAgICAgIGRpc3BsYXk6IGJsb2NrO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgICAgICBtYXJnaW46IDhweCAwIDA7XHJcbiAgICAgIH1cclxuICAgICAgLnJlY2VpdmVkX3dpdGhkX21zZyB7IHdpZHRoOiA1NyU7fVxyXG4gICAgICAubWVzZ3Mge1xyXG4gICAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICAgIHBhZGRpbmc6IDMwcHggMTVweCAwIDI1cHg7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5zZW50X21zZyBwIHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAjMzMzOTg2IG5vbmUgcmVwZWF0IHNjcm9sbCAwIDA7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogM3B4O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICBtYXJnaW46IDA7IGNvbG9yOiNmZmY7XHJcbiAgICAgICAgcGFkZGluZzogNXB4IDEwcHggNXB4IDEycHg7XHJcbiAgICAgICAgd2lkdGg6MTAwJTtcclxuICAgICAgfVxyXG4gICAgICAub3V0Z29pbmdfbXNneyBvdmVyZmxvdzpoaWRkZW47IG1hcmdpbjoyNnB4IDAgMjZweDt9XHJcbiAgICAgIC5zZW50X21zZyB7XHJcbiAgICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgICAgIHdpZHRoOiA0NiU7XHJcbiAgICAgIH1cclxuICAgICAgLmlucHV0X21zZ193cml0ZSBpbnB1dCB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogcmdiYSgwLCAwLCAwLCAwKSBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xyXG4gICAgICAgIGJvcmRlcjogbWVkaXVtIG5vbmU7XHJcbiAgICAgICAgY29sb3I6ICM0YzRjNGM7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgIG1pbi1oZWlnaHQ6IDQ4cHg7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC50eXBlX21zZyB7Ym9yZGVyLXRvcDogMXB4IHNvbGlkICNjNGM0YzQ7cG9zaXRpb246IHJlbGF0aXZlO31cclxuICAgICAgLm1zZ19zZW5kX2J0biB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogIzA1NzI4ZiBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xyXG4gICAgICAgIGJvcmRlcjogbWVkaXVtIG5vbmU7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgIGNvbG9yOiAjZmZmO1xyXG4gICAgICAgIGN1cnNvcjogcG9pbnRlcjtcclxuICAgICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgICAgaGVpZ2h0OiAzM3B4O1xyXG4gICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICByaWdodDogMDtcclxuICAgICAgICB0b3A6IDExcHg7XHJcbiAgICAgICAgd2lkdGg6IDMzcHg7XHJcbiAgICAgIH1cclxuICAgICAgLm1lc3NhZ2luZyB7IHBhZGRpbmc6IDB2aDtcclxuICAgICAgaGVpZ2h0OiA4MCU7XHJcbiAgICAgIH1cclxuICAgICAgLm1zZ19oaXN0b3J5IHtcclxuICAgICAgICBoZWlnaHQ6IDEwMCU7XHJcbiAgICAgICAgb3ZlcmZsb3cteTogYXV0bztcclxuICAgICAgfVxyXG59Il19 */"

/***/ }),

/***/ "./src/app/message3/message2.page.ts":
/*!*******************************************!*\
  !*** ./src/app/message3/message2.page.ts ***!
  \*******************************************/
/*! exports provided: Message2Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Message2Page", function() { return Message2Page; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_3__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var Message2Page = /** @class */ (function () {
    function Message2Page(modalCtrl, actionSheetController, navCtrl) {
        var _this = this;
        this.modalCtrl = modalCtrl;
        this.actionSheetController = actionSheetController;
        this.navCtrl = navCtrl;
        this.VigiK = "";
        this.Filter = 0;
        this.alive = true;
        this.messages = [];
        this.messages_Notif = [];
        this.messages_Chat = [];
        this.indexer = 1;
        this.TabDemandes = [];
        this.TabUser2 = [];
        this.remisa0 = "coucou";
        ;
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        this.initializer();
        setTimeout(function () {
            _this.contentArea.scrollToBottom(300);
        }, 100);
        setTimeout(function () {
            _this.refreshPage();
        }, 10000);
    }
    Message2Page.prototype.initializer = function () {
        this.TabUser2 = null;
        var InTabUser2 = [];
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/msg_sav/' + firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid).on("value", function (snapshot) {
            var tg = snapshot.val();
            tg.forEach(function (entry) {
                InTabUser2.push(entry);
            });
        }, function (error) {
        });
        this.TabUser2 = InTabUser2;
        InTabUser2 = null;
        var imessages = [
            { itext: '', idate: '', otext: '', odate: '', notif: 0 }
        ];
        var nmessages = [
            { itext: '', idate: '', otext: '', odate: '', notif: 0 }
        ];
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        for (var i = 0, len = this.TabUser2.length; i < len; i++) {
            if (this.TabUser2[i]['UserID'] == firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid) {
                imessages.push({ itext: '', idate: '', otext: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[i]['Message'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8), odate: this.TabUser2[i]['DateMsg'], notif: this.TabUser2[i]['Notification'] });
            }
            else {
                imessages.push({ itext: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[i]['Message'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8), idate: this.TabUser2[i]['DateMsg'], otext: '', odate: '', notif: this.TabUser2[i]['Notification'] });
                if (this.TabUser2[i]['Notification'] == 1)
                    nmessages.push({ itext: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[i]['Message'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8), idate: this.TabUser2[i]['DateMsg'], otext: '', odate: '', notif: this.TabUser2[i]['Notification'] });
            }
        }
        var car = { text: 'mdr', date: '01/02/1996' };
        this.messages = imessages;
        this.messages_Chat = imessages;
        this.messages_Notif = nmessages;
    };
    Message2Page.prototype.refreshPage = function () {
        var _this = this;
        setTimeout(function () {
            _this.cooling();
        }, 1000);
    };
    Message2Page.prototype.cooling = function () {
        var _this = this;
        if (window.location.href.indexOf("/message3") > -1) {
            this.initializer();
        }
        setTimeout(function () {
            _this.refreshPage();
        }, 100);
    };
    Message2Page.prototype.sort = function () {
    };
    Message2Page.prototype.close = function () {
        this.modalCtrl.dismiss();
    };
    Message2Page.prototype.Remisa0ftn = function () {
        this.remisa0 = "";
    };
    Message2Page.prototype.writeUserData = function () {
        var _this = this;
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/msg_sav/' + firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid).set(this.TabUser2).then(function (data) {
            // console.log("voir donn",this.TabUser2);
        }, function (error) {
            console.log(error, _this.TabUser2);
        });
        ;
    };
    Message2Page.prototype.sendMsg = function () {
        var _this = this;
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        var utc = new Date().toJSON().slice(0, 10).replace(/-/g, '/');
        if (this.Type_notif && this.Type_notif.length > 0) {
            this.TabUser2.push({ DateMsg: utc, Message: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Type_notif.trim(), VigiK.trim()).toString(), Notification: 1, UserID: firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid });
            this.writeUserData();
            this.messages.push({ itext: '', idate: '', otext: this.Type_notif, odate: utc, notif: 1 });
            this.Type_notif = "";
            setTimeout(function () {
                _this.contentArea.scrollToBottom(300);
            }, 400);
        }
        else if (!this.Msg2Send || this.Msg2Send.length < 1)
            return;
        this.TabUser2.push({ DateMsg: utc, Message: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Msg2Send.trim(), VigiK.trim()).toString(), Notification: 0, UserID: firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid });
        this.writeUserData();
        this.messages.push({ itext: '', idate: '', otext: this.Msg2Send, odate: utc, notif: 0 });
        this.Msg2Send = "";
        console.log(this.Msg2Send);
        setTimeout(function () {
            _this.contentArea.scrollToBottom(300);
        }, 400);
    };
    Message2Page.prototype.Joindre = function () {
        return __awaiter(this, void 0, void 0, function () {
            var actionSheet;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.actionSheetController.create({
                            header: 'Joindre un élément',
                            buttons: [{
                                    text: 'Parcourir',
                                    role: 'add',
                                    icon: 'add',
                                    handler: function () {
                                        console.log('Add clicked');
                                    }
                                },
                                {
                                    text: 'Cancel',
                                    icon: 'close',
                                    role: 'cancel',
                                    handler: function () {
                                        console.log('Cancel clicked');
                                    }
                                }]
                        })];
                    case 1:
                        actionSheet = _a.sent();
                        return [4 /*yield*/, actionSheet.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    Message2Page.prototype.sorti = function () {
        this.contentArea.scrollToBottom(300); //300ms animation speed
    };
    Message2Page.prototype.ngOnInit = function () {
        console.log(firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid);
        // var string = "foo",
        // substring = "oo";
        // string.includes(substring)
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonContent"]),
        __metadata("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["IonContent"])
    ], Message2Page.prototype, "contentArea", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('content'),
        __metadata("design:type", Object)
    ], Message2Page.prototype, "content", void 0);
    Message2Page = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-message2',
            template: __webpack_require__(/*! ./message2.page.html */ "./src/app/message3/message2.page.html"),
            styles: [__webpack_require__(/*! ./message2.page.scss */ "./src/app/message3/message2.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ActionSheetController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"]])
    ], Message2Page);
    return Message2Page;
}());



/***/ })

}]);
//# sourceMappingURL=message3-message2-module.js.map