(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["suivi-demande-suivi-demande-module"],{

/***/ "./src/app/suivi-demande/suivi-demande.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/suivi-demande/suivi-demande.module.ts ***!
  \*******************************************************/
/*! exports provided: SuiviDemandePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuiviDemandePageModule", function() { return SuiviDemandePageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _suivi_demande_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./suivi-demande.page */ "./src/app/suivi-demande/suivi-demande.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _suivi_demande_page__WEBPACK_IMPORTED_MODULE_5__["SuiviDemandePage"]
    }
];
var SuiviDemandePageModule = /** @class */ (function () {
    function SuiviDemandePageModule() {
    }
    SuiviDemandePageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_suivi_demande_page__WEBPACK_IMPORTED_MODULE_5__["SuiviDemandePage"]]
        })
    ], SuiviDemandePageModule);
    return SuiviDemandePageModule;
}());



/***/ }),

/***/ "./src/app/suivi-demande/suivi-demande.page.html":
/*!*******************************************************!*\
  !*** ./src/app/suivi-demande/suivi-demande.page.html ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<script>\n    $(document).ready(function(){\n      $(\".searchbar-input\").on(\"keyup\", function() {\n        var value = $(this).val().toLowerCase();\n        $(\".rech\").filter(function() {\n          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)\n        });\n      });\n    });\n    </script>\n<ion-header>\n    <ion-toolbar>\n      </ion-toolbar>\n  <ion-toolbar color=\"primary\">\n    <ion-title >Demande</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n\n    \n    \n    <ion-content class=\"div\" padding>\n        \n      <ion-searchbar mode=\"ios\" [(ngModel)]=\"recherche\"\n      (ionInput)=\"onInput($event)\"></ion-searchbar>\n      <ion-grid >\n          <ion-row>\n               <ion-col class=\"prim\" size=\"2\" size-sm>\n                   Identifiant\n               </ion-col>\n               <ion-col class=\"prim\" size=\"2\" size-sm>\n                   Nom\n               </ion-col>\n               <ion-col class=\"prim\" size=\"2\" size-sm>\n                  Date de la mise à jour\n               </ion-col>\n               <ion-col class=\"prim\" size=\"2\" size-sm>\n                   Etat du colis\n               </ion-col>\n               <ion-col class=\"prim\" size=\"2\" size-sm>\n               </ion-col>\n               <ion-col class=\"prim\" size=\"2\" size-sm>\n               </ion-col>\n          </ion-row>\n \n \n          <ion-row class=\"rech\" *ngFor=\"let s of filtreur\">\n             <ion-col size=\"2\" size-sm>\n                 <ion-input [class]=\"s.id\" disabled=\"{{inputDisabled}}\">{{s.id}}</ion-input>\n             </ion-col>\n             <ion-col size=\"2\" size-sm>\n                 <ion-input [class]=\"s.id\" disabled=\"{{inputDisabled}}\">{{s.name}}</ion-input> \n             </ion-col>\n             <ion-col size=\"2\" size-sm>\n                 <ion-input [class]=\"s.id\" disabled=\"{{inputDisabled}}\">{{s.date}}</ion-input>  \n             </ion-col>\n             <ion-col size=\"2\" size-sm>\n                 <ion-input [class]=\"s.id\" disabled=\"{{inputDisabled}}\">{{s.etat}}</ion-input>\n             </ion-col>\n             <ion-col size=\"2\" size-sm>\n                 <ion-button [class]=\"s.id\" (click)=\"Modifier()\">Modifier</ion-button>\n             </ion-col>\n             <ion-col size=\"2\" size-sm>\n                 <ion-button [color]=\"s.color\">Chat</ion-button>\n             </ion-col>\n          </ion-row>\n       \n       <ion-button>ajouter</ion-button>\n      </ion-grid>\n \n    \n </ion-content>\n"

/***/ }),

/***/ "./src/app/suivi-demande/suivi-demande.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/suivi-demande/suivi-demande.page.scss ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ion-row, :host ion-col {\n  border: 1px solid black; }\n\n:host ion-row {\n  min-width: 800px; }\n\n:host ion-row:nth-child(even) {\n  background-color: #dddddd; }\n\n:host ion-grid {\n  overflow-x: auto !important;\n  overflow-y: auto !important; }\n\n:host ion-grid *::-webkit-scrollbar {\n    display: inline-block; }\n\n:host .prim {\n  color: white;\n  font-weight: bold;\n  background-color: #333986 !important; }\n\n:host .broown {\n  color: #A0522D; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VpdmktZGVtYW5kZS9DOlxcVXNlcnNcXElyaXMgR2VyYWxkb1xcRG9jdW1lbnRzXFxPdXRhbG1hZmluXFxPdXRhbG1hL3NyY1xcYXBwXFxzdWl2aS1kZW1hbmRlXFxzdWl2aS1kZW1hbmRlLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVRLHVCQUF1QixFQUFBOztBQUYvQjtFQUtRLGdCQUFnQixFQUFBOztBQUx4QjtFQVFRLHlCQUF5QixFQUFBOztBQVJqQztFQVlRLDJCQUEyQjtFQUMzQiwyQkFBMkIsRUFBQTs7QUFibkM7SUFnQlkscUJBQXFCLEVBQUE7O0FBaEJqQztFQXNCUSxZQUFXO0VBQ1gsaUJBQWlCO0VBQ2pCLG9DQUFtQyxFQUFBOztBQXhCM0M7RUEyQlksY0FBYyxFQUFBIiwiZmlsZSI6InNyYy9hcHAvc3VpdmktZGVtYW5kZS9zdWl2aS1kZW1hbmRlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0e1xyXG4gICAgaW9uLXJvdywgaW9uLWNvbHtcclxuICAgICAgICBib3JkZXI6IDFweCBzb2xpZCBibGFjaztcclxuICAgIH1cclxuICAgIGlvbi1yb3d7XHJcbiAgICAgICAgbWluLXdpZHRoOiA4MDBweDtcclxuICAgIH1cclxuICAgIGlvbi1yb3c6bnRoLWNoaWxkKGV2ZW4pIHtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiAjZGRkZGRkO1xyXG4gICAgICAgIFxyXG4gICAgfVxyXG4gICAgaW9uLWdyaWR7XHJcbiAgICAgICAgb3ZlcmZsb3cteDogYXV0byAhaW1wb3J0YW50O1xyXG4gICAgICAgIG92ZXJmbG93LXk6IGF1dG8gIWltcG9ydGFudDsgXHJcblxyXG4gICAgICAgICo6Oi13ZWJraXQtc2Nyb2xsYmFye1xyXG4gICAgICAgICAgICBkaXNwbGF5OmlubGluZS1ibG9jayA7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBcclxuICAgIH1cclxuICAgIC5wcmlte1xyXG4gICAgICAgIGNvbG9yOndoaXRlO1xyXG4gICAgICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6ICMzMzM5ODYhaW1wb3J0YW50O1xyXG4gICAgfVxyXG4gICAgICAgIC5icm9vd257XHJcbiAgICAgICAgICAgIGNvbG9yOiAjQTA1MjJEO1xyXG4gICAgICAgIH1cclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/suivi-demande/suivi-demande.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/suivi-demande/suivi-demande.page.ts ***!
  \*****************************************************/
/*! exports provided: SuiviDemandePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuiviDemandePage", function() { return SuiviDemandePage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};

var SuiviDemandePage = /** @class */ (function () {
    function SuiviDemandePage() {
        this.recherche = "";
        this.filtreur = [];
        this.suivi = [
            {
                id: '8989',
                name: 'Pascale Rousi',
                etat: 'En agence',
                date: '20/12/2018',
                color: 'danger'
            },
            {
                id: '3455',
                name: 'Hugue Delanoé',
                etat: 'En attente',
                date: '10/02/2019',
                color: 'danger'
            },
            {
                id: '6789',
                name: 'Frederic Anioti',
                etat: 'En attente',
                date: '21/12/2018',
                color: 'primary'
            },
            {
                id: '5677',
                name: 'Maria Anioti',
                etat: 'En agence',
                date: '21/12/2018',
                color: 'primary'
            },
            {
                id: '3678',
                name: 'Jean Claude',
                etat: 'En attente',
                date: '14/01/2019',
                color: 'primary'
            },
            {
                id: '7078',
                name: 'Luc Silva',
                etat: 'En attente',
                date: '02/12/2018',
                color: 'primary'
            },
            {
                id: '9799',
                name: 'Jean Claude',
                etat: 'En attente',
                date: '12/11/2018',
                color: 'primary'
            },
            {
                id: '5063',
                name: 'Manuel Batire',
                etat: 'En agence',
                date: '17/01/2019',
                color: 'primary'
            },
        ];
    }
    SuiviDemandePage.prototype.OnInput = function (event) {
        var text = this.recherche.toLowerCase().trim();
        this.filtreur = this.suivi.filter(function (c) {
            var fc = Object.assign({}, c);
            // delete fc.createdAt; 
            return JSON.stringify(fc).toLowerCase().indexOf(text) > -1;
        });
        console.log(this.filtreur);
    };
    SuiviDemandePage.prototype.ngOnInit = function () {
    };
    SuiviDemandePage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-suivi-demande',
            template: __webpack_require__(/*! ./suivi-demande.page.html */ "./src/app/suivi-demande/suivi-demande.page.html"),
            styles: [__webpack_require__(/*! ./suivi-demande.page.scss */ "./src/app/suivi-demande/suivi-demande.page.scss")]
        }),
        __metadata("design:paramtypes", [])
    ], SuiviDemandePage);
    return SuiviDemandePage;
}());



/***/ })

}]);
//# sourceMappingURL=suivi-demande-suivi-demande-module.js.map