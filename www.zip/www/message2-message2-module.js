(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["message2-message2-module"],{

/***/ "./src/app/Modal/msg-sav-employe/msg-sav-employe.module.ts":
/*!*****************************************************************!*\
  !*** ./src/app/Modal/msg-sav-employe/msg-sav-employe.module.ts ***!
  \*****************************************************************/
/*! exports provided: MsgSavEmployePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MsgSavEmployePageModule", function() { return MsgSavEmployePageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _msg_sav_employe_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./msg-sav-employe.page */ "./src/app/Modal/msg-sav-employe/msg-sav-employe.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var MsgSavEmployePageModule = /** @class */ (function () {
    function MsgSavEmployePageModule() {
    }
    MsgSavEmployePageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
            ],
            declarations: [_msg_sav_employe_page__WEBPACK_IMPORTED_MODULE_4__["MsgSavEmployePage"]],
            entryComponents: [
                _msg_sav_employe_page__WEBPACK_IMPORTED_MODULE_4__["MsgSavEmployePage"]
            ]
        })
    ], MsgSavEmployePageModule);
    return MsgSavEmployePageModule;
}());



/***/ }),

/***/ "./src/app/Modal/msg-sav-employe/msg-sav-employe.page.html":
/*!*****************************************************************!*\
  !*** ./src/app/Modal/msg-sav-employe/msg-sav-employe.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar color=\"primary\">\n        <ion-buttons slot=\"start\">\n            <ion-button (click)=\"close()\">\n              <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n            </ion-button>\n          </ion-buttons>\n      <ion-title >Chat #{{i}}\n      </ion-title>\n    </ion-toolbar>\n  </ion-header>\n  <ion-content padding>\n  \n        \n        <div class=\"mesgs\">\n          <div class=\"msg_history\" >\n            <div *ngFor=\"let message of messages\">\n              \n            <div *ngIf=\"message.itext\">\n              <div class=\"incoming_msg\" >\n                <div class=\"incoming_msg_img\"> <img [src]=\"'assets/img/noavatar.png'\" /> </div>\n                <div class=\"received_msg\">\n                  <div class=\"received_withd_msg\">\n                    <p>{{message.itext}}</p>\n                    <span class=\"time_date\">{{message.idate}}</span></div>\n                    <br>\n                </div>\n              </div>\n            </div>               \n          <div *ngIf=\"message.otext\">\n            <div class=\"outgoing_msg\">\n              <div class=\"sent_msg\">\n                <p>{{message.otext}}</p>\n                <span class=\"time_date\">{{message.odate}}</span> </div>\n            </div>\n          </div>\n        </div>\n  \n          </div>\n  \n  \n    </div>\n  \n  </ion-content>\n  <ion-footer>\n      <ion-toolbar>\n          <ion-buttons slot=\"start\">\n        </ion-buttons>\n        <ion-textarea id=\"IMsg2Send\" class=\"message-input\" placeholder=\"Tapez votre message\" rows=\"1\" autocapitalize=\"off\" [(ngModel)]=\"Msg2Send\"></ion-textarea>\n        <ion-buttons slot=\"end\">\n          <ion-button color=\"primary\" (click)=\"sendMsg();\">\n            <ion-icon slot=\"icon-only\" name=\"md-send\"></ion-icon>\n          </ion-button>\n        </ion-buttons>\n      </ion-toolbar>\n    </ion-footer>\n"

/***/ }),

/***/ "./src/app/Modal/msg-sav-employe/msg-sav-employe.page.scss":
/*!*****************************************************************!*\
  !*** ./src/app/Modal/msg-sav-employe/msg-sav-employe.page.scss ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .container {\n  max-width: 1170px;\n  margin: auto; }\n\n:host img {\n  max-width: 100%; }\n\n:host .inbox_people {\n  background: #f8f8f8 none repeat scroll 0 0;\n  float: left;\n  overflow: hidden;\n  width: 40%;\n  border-right: 1px solid #c4c4c4; }\n\n:host .inbox_msg {\n  border: 1px solid #c4c4c4;\n  clear: both;\n  overflow: hidden; }\n\n:host .top_spac {\n  margin: 20px 0 0; }\n\n:host .recent_heading {\n  float: left;\n  width: 40%; }\n\n:host .srch_bar {\n  display: inline-block;\n  text-align: right;\n  width: 60%; }\n\n:host .headind_srch {\n  padding: 10px 29px 10px 20px;\n  overflow: hidden;\n  border-bottom: 1px solid #c4c4c4; }\n\n:host .recent_heading h4 {\n  color: #05728f;\n  font-size: 21px;\n  margin: auto; }\n\n:host .srch_bar input {\n  border: 1px solid #cdcdcd;\n  border-width: 0 0 1px 0;\n  width: 80%;\n  padding: 2px 0 4px 6px;\n  background: none; }\n\n:host .srch_bar .input-group-addon button {\n  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;\n  border: medium none;\n  padding: 0;\n  color: #707070;\n  font-size: 18px; }\n\n:host .srch_bar .input-group-addon {\n  margin: 0 0 0 -27px; }\n\n:host .chat_ib h5 {\n  font-size: 15px;\n  color: #464646;\n  margin: 0 0 8px 0; }\n\n:host .chat_ib h5 span {\n  font-size: 13px;\n  float: right; }\n\n:host .chat_ib p {\n  font-size: 14px;\n  color: #989898;\n  margin: auto; }\n\n:host .chat_img {\n  float: left;\n  width: 11%; }\n\n:host .chat_ib {\n  float: left;\n  padding: 0 0 0 15px;\n  width: 88%; }\n\n:host .chat_people {\n  overflow: hidden;\n  clear: both; }\n\n:host .chat_list {\n  border-bottom: 1px solid #c4c4c4;\n  margin: 0;\n  padding: 18px 16px 10px; }\n\n:host .inbox_chat {\n  height: 550px;\n  overflow-y: scroll; }\n\n:host .active_chat {\n  background: #ebebeb; }\n\n:host .incoming_msg_img {\n  display: inline-block;\n  width: 6%; }\n\n:host .received_msg {\n  display: inline-block;\n  padding: 0 0 0 10px;\n  vertical-align: top;\n  width: 92%; }\n\n:host .received_withd_msg p {\n  background: #ebebeb none repeat scroll 0 0;\n  border-radius: 3px;\n  color: #646464;\n  font-size: 14px;\n  margin: 0;\n  padding: 5px 10px 5px 12px;\n  width: 100%; }\n\n:host .time_date {\n  color: #747474;\n  display: block;\n  font-size: 12px;\n  margin: 8px 0 0; }\n\n:host .received_withd_msg {\n  width: 57%; }\n\n:host .mesgs {\n  float: left;\n  padding: 30px 15px 0 25px;\n  width: 100%; }\n\n:host .sent_msg p {\n  background: #333986 none repeat scroll 0 0;\n  border-radius: 3px;\n  font-size: 14px;\n  margin: 0;\n  color: #fff;\n  padding: 5px 10px 5px 12px;\n  width: 100%; }\n\n:host .outgoing_msg {\n  overflow: hidden;\n  margin: 26px 0 26px; }\n\n:host .sent_msg {\n  float: right;\n  width: 46%; }\n\n:host .input_msg_write input {\n  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;\n  border: medium none;\n  color: #4c4c4c;\n  font-size: 15px;\n  min-height: 48px;\n  width: 100%; }\n\n:host .type_msg {\n  border-top: 1px solid #c4c4c4;\n  position: relative; }\n\n:host .msg_send_btn {\n  background: #05728f none repeat scroll 0 0;\n  border: medium none;\n  border-radius: 50%;\n  color: #fff;\n  cursor: pointer;\n  font-size: 17px;\n  height: 33px;\n  position: absolute;\n  right: 0;\n  top: 11px;\n  width: 33px; }\n\n:host .messaging {\n  padding: 0vh;\n  height: 80%; }\n\n:host .msg_history {\n  height: 100%;\n  overflow-y: auto; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvTW9kYWwvbXNnLXNhdi1lbXBsb3llL0M6XFxVc2Vyc1xcSXJpcyBHZXJhbGRvXFxEb2N1bWVudHNcXE91dGFsbWFmaW5cXE91dGFsbWEvc3JjXFxhcHBcXE1vZGFsXFxtc2ctc2F2LWVtcGxveWVcXG1zZy1zYXYtZW1wbG95ZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0E7RUFDZSxpQkFBZ0I7RUFBRSxZQUFXLEVBQUE7O0FBRDVDO0VBRVMsZUFBYyxFQUFBOztBQUZ2QjtFQUlNLDBDQUEwQztFQUMxQyxXQUFXO0VBQ1gsZ0JBQWdCO0VBQ2hCLFVBQVU7RUFBRSwrQkFBOEIsRUFBQTs7QUFQaEQ7RUFVTSx5QkFBeUI7RUFDekIsV0FBVztFQUNYLGdCQUFnQixFQUFBOztBQVp0QjtFQWNlLGdCQUFnQixFQUFBOztBQWQvQjtFQWlCcUIsV0FBVztFQUFFLFVBQVMsRUFBQTs7QUFqQjNDO0VBbUJNLHFCQUFxQjtFQUNyQixpQkFBaUI7RUFDakIsVUFBVSxFQUFBOztBQXJCaEI7RUF1Qm1CLDRCQUEyQjtFQUFFLGdCQUFlO0VBQUUsZ0NBQStCLEVBQUE7O0FBdkJoRztFQTBCTSxjQUFjO0VBQ2QsZUFBZTtFQUNmLFlBQVksRUFBQTs7QUE1QmxCO0VBOEJxQix5QkFBd0I7RUFBRSx1QkFBc0I7RUFBRSxVQUFTO0VBQUUsc0JBQXFCO0VBQUUsZ0JBQWUsRUFBQTs7QUE5QnhIO0VBZ0NNLG1EQUFtRDtFQUNuRCxtQkFBbUI7RUFDbkIsVUFBVTtFQUNWLGNBQWM7RUFDZCxlQUFlLEVBQUE7O0FBcENyQjtFQXNDbUMsbUJBQW1CLEVBQUE7O0FBdEN0RDtFQXdDaUIsZUFBYztFQUFFLGNBQWE7RUFBRSxpQkFBZ0IsRUFBQTs7QUF4Q2hFO0VBeUNzQixlQUFjO0VBQUUsWUFBVyxFQUFBOztBQXpDakQ7RUEwQ2dCLGVBQWM7RUFBRSxjQUFhO0VBQUUsWUFBVyxFQUFBOztBQTFDMUQ7RUE0Q00sV0FBVztFQUNYLFVBQVUsRUFBQTs7QUE3Q2hCO0VBZ0RNLFdBQVc7RUFDWCxtQkFBbUI7RUFDbkIsVUFBVSxFQUFBOztBQWxEaEI7RUFxRGtCLGdCQUFlO0VBQUUsV0FBVSxFQUFBOztBQXJEN0M7RUF1RE0sZ0NBQWdDO0VBQ2hDLFNBQVM7RUFDVCx1QkFBdUIsRUFBQTs7QUF6RDdCO0VBMkRrQixhQUFhO0VBQUUsa0JBQWtCLEVBQUE7O0FBM0RuRDtFQTZEa0IsbUJBQWtCLEVBQUE7O0FBN0RwQztFQWdFTSxxQkFBcUI7RUFDckIsU0FBUyxFQUFBOztBQWpFZjtFQW9FTSxxQkFBcUI7RUFDckIsbUJBQW1CO0VBQ25CLG1CQUFtQjtFQUNuQixVQUFVLEVBQUE7O0FBdkVoQjtFQTBFTSwwQ0FBMEM7RUFDMUMsa0JBQWtCO0VBQ2xCLGNBQWM7RUFDZCxlQUFlO0VBQ2YsU0FBUztFQUNULDBCQUEwQjtFQUMxQixXQUFXLEVBQUE7O0FBaEZqQjtFQW1GTSxjQUFjO0VBQ2QsY0FBYztFQUNkLGVBQWU7RUFDZixlQUFlLEVBQUE7O0FBdEZyQjtFQXdGMEIsVUFBVSxFQUFBOztBQXhGcEM7RUEwRk0sV0FBVztFQUNYLHlCQUF5QjtFQUN6QixXQUFXLEVBQUE7O0FBNUZqQjtFQWdHTSwwQ0FBMEM7RUFDMUMsa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixTQUFTO0VBQUUsV0FBVTtFQUNyQiwwQkFBMEI7RUFDMUIsV0FBVSxFQUFBOztBQXJHaEI7RUF1R21CLGdCQUFlO0VBQUUsbUJBQWtCLEVBQUE7O0FBdkd0RDtFQXlHTSxZQUFZO0VBQ1osVUFBVSxFQUFBOztBQTFHaEI7RUE2R00sbURBQW1EO0VBQ25ELG1CQUFtQjtFQUNuQixjQUFjO0VBQ2QsZUFBZTtFQUNmLGdCQUFnQjtFQUNoQixXQUFXLEVBQUE7O0FBbEhqQjtFQXFIZSw2QkFBNkI7RUFBQyxrQkFBa0IsRUFBQTs7QUFySC9EO0VBdUhNLDBDQUEwQztFQUMxQyxtQkFBbUI7RUFDbkIsa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxlQUFlO0VBQ2YsZUFBZTtFQUNmLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsUUFBUTtFQUNSLFNBQVM7RUFDVCxXQUFXLEVBQUE7O0FBaklqQjtFQW1JaUIsWUFBWTtFQUN6QixXQUFXLEVBQUE7O0FBcElmO0VBdUlNLFlBQVk7RUFDWixnQkFBZ0IsRUFBQSIsImZpbGUiOiJzcmMvYXBwL01vZGFsL21zZy1zYXYtZW1wbG95ZS9tc2ctc2F2LWVtcGxveWUucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXHJcbjpob3N0e1xyXG4gICAgLmNvbnRhaW5lcnttYXgtd2lkdGg6MTE3MHB4OyBtYXJnaW46YXV0bzt9XHJcbiAgICBpbWd7IG1heC13aWR0aDoxMDAlO31cclxuICAgIC5pbmJveF9wZW9wbGUge1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjZjhmOGY4IG5vbmUgcmVwZWF0IHNjcm9sbCAwIDA7XHJcbiAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICBvdmVyZmxvdzogaGlkZGVuO1xyXG4gICAgICB3aWR0aDogNDAlOyBib3JkZXItcmlnaHQ6MXB4IHNvbGlkICNjNGM0YzQ7XHJcbiAgICB9XHJcbiAgICAuaW5ib3hfbXNnIHtcclxuICAgICAgYm9yZGVyOiAxcHggc29saWQgI2M0YzRjNDtcclxuICAgICAgY2xlYXI6IGJvdGg7XHJcbiAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICB9XHJcbiAgICAudG9wX3NwYWN7IG1hcmdpbjogMjBweCAwIDA7fVxyXG5cclxuXHJcbiAgICAucmVjZW50X2hlYWRpbmcge2Zsb2F0OiBsZWZ0OyB3aWR0aDo0MCU7fVxyXG4gICAgLnNyY2hfYmFyIHtcclxuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICB0ZXh0LWFsaWduOiByaWdodDtcclxuICAgICAgd2lkdGg6IDYwJTtcclxuICAgIH1cclxuICAgIC5oZWFkaW5kX3NyY2h7IHBhZGRpbmc6MTBweCAyOXB4IDEwcHggMjBweDsgb3ZlcmZsb3c6aGlkZGVuOyBib3JkZXItYm90dG9tOjFweCBzb2xpZCAjYzRjNGM0O31cclxuXHJcbiAgICAucmVjZW50X2hlYWRpbmcgaDQge1xyXG4gICAgICBjb2xvcjogIzA1NzI4ZjtcclxuICAgICAgZm9udC1zaXplOiAyMXB4O1xyXG4gICAgICBtYXJnaW46IGF1dG87XHJcbiAgICB9XHJcbiAgICAuc3JjaF9iYXIgaW5wdXR7IGJvcmRlcjoxcHggc29saWQgI2NkY2RjZDsgYm9yZGVyLXdpZHRoOjAgMCAxcHggMDsgd2lkdGg6ODAlOyBwYWRkaW5nOjJweCAwIDRweCA2cHg7IGJhY2tncm91bmQ6bm9uZTt9XHJcbiAgICAuc3JjaF9iYXIgLmlucHV0LWdyb3VwLWFkZG9uIGJ1dHRvbiB7XHJcbiAgICAgIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMCkgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcclxuICAgICAgYm9yZGVyOiBtZWRpdW0gbm9uZTtcclxuICAgICAgcGFkZGluZzogMDtcclxuICAgICAgY29sb3I6ICM3MDcwNzA7XHJcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgIH1cclxuICAgIC5zcmNoX2JhciAuaW5wdXQtZ3JvdXAtYWRkb24geyBtYXJnaW46IDAgMCAwIC0yN3B4O31cclxuXHJcbiAgICAuY2hhdF9pYiBoNXsgZm9udC1zaXplOjE1cHg7IGNvbG9yOiM0NjQ2NDY7IG1hcmdpbjowIDAgOHB4IDA7fVxyXG4gICAgLmNoYXRfaWIgaDUgc3BhbnsgZm9udC1zaXplOjEzcHg7IGZsb2F0OnJpZ2h0O31cclxuICAgIC5jaGF0X2liIHB7IGZvbnQtc2l6ZToxNHB4OyBjb2xvcjojOTg5ODk4OyBtYXJnaW46YXV0b31cclxuICAgIC5jaGF0X2ltZyB7XHJcbiAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICB3aWR0aDogMTElO1xyXG4gICAgfVxyXG4gICAgLmNoYXRfaWIge1xyXG4gICAgICBmbG9hdDogbGVmdDtcclxuICAgICAgcGFkZGluZzogMCAwIDAgMTVweDtcclxuICAgICAgd2lkdGg6IDg4JTtcclxuICAgIH1cclxuXHJcbiAgICAuY2hhdF9wZW9wbGV7IG92ZXJmbG93OmhpZGRlbjsgY2xlYXI6Ym90aDt9XHJcbiAgICAuY2hhdF9saXN0IHtcclxuICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjNGM0YzQ7XHJcbiAgICAgIG1hcmdpbjogMDtcclxuICAgICAgcGFkZGluZzogMThweCAxNnB4IDEwcHg7XHJcbiAgICB9XHJcbiAgICAuaW5ib3hfY2hhdCB7IGhlaWdodDogNTUwcHg7IG92ZXJmbG93LXk6IHNjcm9sbDt9XHJcblxyXG4gICAgLmFjdGl2ZV9jaGF0eyBiYWNrZ3JvdW5kOiNlYmViZWI7fVxyXG5cclxuICAgIC5pbmNvbWluZ19tc2dfaW1nIHtcclxuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICB3aWR0aDogNiU7XHJcbiAgICB9XHJcbiAgICAucmVjZWl2ZWRfbXNnIHtcclxuICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICBwYWRkaW5nOiAwIDAgMCAxMHB4O1xyXG4gICAgICB2ZXJ0aWNhbC1hbGlnbjogdG9wO1xyXG4gICAgICB3aWR0aDogOTIlO1xyXG4gICAgfVxyXG4gICAgLnJlY2VpdmVkX3dpdGhkX21zZyBwIHtcclxuICAgICAgYmFja2dyb3VuZDogI2ViZWJlYiBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAzcHg7XHJcbiAgICAgIGNvbG9yOiAjNjQ2NDY0O1xyXG4gICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgIG1hcmdpbjogMDtcclxuICAgICAgcGFkZGluZzogNXB4IDEwcHggNXB4IDEycHg7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgfVxyXG4gICAgLnRpbWVfZGF0ZSB7XHJcbiAgICAgIGNvbG9yOiAjNzQ3NDc0O1xyXG4gICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICBtYXJnaW46IDhweCAwIDA7XHJcbiAgICB9XHJcbiAgICAucmVjZWl2ZWRfd2l0aGRfbXNnIHsgd2lkdGg6IDU3JTt9XHJcbiAgICAubWVzZ3Mge1xyXG4gICAgICBmbG9hdDogbGVmdDtcclxuICAgICAgcGFkZGluZzogMzBweCAxNXB4IDAgMjVweDtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICB9XHJcblxyXG4gICAgLnNlbnRfbXNnIHAge1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjMzMzOTg2IG5vbmUgcmVwZWF0IHNjcm9sbCAwIDA7XHJcbiAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcclxuICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICBtYXJnaW46IDA7IGNvbG9yOiNmZmY7XHJcbiAgICAgIHBhZGRpbmc6IDVweCAxMHB4IDVweCAxMnB4O1xyXG4gICAgICB3aWR0aDoxMDAlO1xyXG4gICAgfVxyXG4gICAgLm91dGdvaW5nX21zZ3sgb3ZlcmZsb3c6aGlkZGVuOyBtYXJnaW46MjZweCAwIDI2cHg7fVxyXG4gICAgLnNlbnRfbXNnIHtcclxuICAgICAgZmxvYXQ6IHJpZ2h0O1xyXG4gICAgICB3aWR0aDogNDYlO1xyXG4gICAgfVxyXG4gICAgLmlucHV0X21zZ193cml0ZSBpbnB1dCB7XHJcbiAgICAgIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMCkgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcclxuICAgICAgYm9yZGVyOiBtZWRpdW0gbm9uZTtcclxuICAgICAgY29sb3I6ICM0YzRjNGM7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgbWluLWhlaWdodDogNDhweDtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICB9XHJcblxyXG4gICAgLnR5cGVfbXNnIHtib3JkZXItdG9wOiAxcHggc29saWQgI2M0YzRjNDtwb3NpdGlvbjogcmVsYXRpdmU7fVxyXG4gICAgLm1zZ19zZW5kX2J0biB7XHJcbiAgICAgIGJhY2tncm91bmQ6ICMwNTcyOGYgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcclxuICAgICAgYm9yZGVyOiBtZWRpdW0gbm9uZTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgY3Vyc29yOiBwb2ludGVyO1xyXG4gICAgICBmb250LXNpemU6IDE3cHg7XHJcbiAgICAgIGhlaWdodDogMzNweDtcclxuICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICByaWdodDogMDtcclxuICAgICAgdG9wOiAxMXB4O1xyXG4gICAgICB3aWR0aDogMzNweDtcclxuICAgIH1cclxuICAgIC5tZXNzYWdpbmcgeyBwYWRkaW5nOiAwdmg7XHJcbiAgICBoZWlnaHQ6IDgwJTtcclxuICAgIH1cclxuICAgIC5tc2dfaGlzdG9yeSB7XHJcbiAgICAgIGhlaWdodDogMTAwJTtcclxuICAgICAgb3ZlcmZsb3cteTogYXV0bztcclxuICAgIH1cclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/Modal/msg-sav-employe/msg-sav-employe.page.ts":
/*!***************************************************************!*\
  !*** ./src/app/Modal/msg-sav-employe/msg-sav-employe.page.ts ***!
  \***************************************************************/
/*! exports provided: MsgSavEmployePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MsgSavEmployePage", function() { return MsgSavEmployePage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_3__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var sv;
var MsgSavEmployePage = /** @class */ (function () {
    function MsgSavEmployePage(modalCtrl, actionSheetController, navCtrl, navPrm) {
        var _this = this;
        this.modalCtrl = modalCtrl;
        this.actionSheetController = actionSheetController;
        this.navCtrl = navCtrl;
        this.navPrm = navPrm;
        this.VigiK = "";
        this.Filter = 0;
        this.alive = true;
        this.messages = [];
        this.messages_Notif = [];
        this.messages_Chat = [];
        this.TabDemandes = [];
        this.TabUser2 = [];
        this.i = this.navPrm.get('i');
        this.suivi = this.navPrm.get('suivi');
        this.remisa0 = "coucou";
        ;
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        setTimeout(function () {
            _this.contentArea.scrollToBottom(300);
        }, 200);
        this.TabUser2 = null;
        var InTabUser2 = [];
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/msg_sav/' + this.i).on("value", function (snapshot) {
            var tg = snapshot.val();
            tg.forEach(function (entry) {
                InTabUser2.push(entry);
            });
        }, function (error) {
            console.log("Error dans VoirDonnees: " + error.code);
        });
        this.TabUser2 = InTabUser2;
        InTabUser2 = null;
        var imessages = [
            { itext: '', idate: '', otext: '', odate: '', notif: 0 }
        ];
        var nmessages = [
            { itext: '', idate: '', otext: '', odate: '', notif: 0 }
        ];
        for (var i = 0, len = this.TabUser2.length; i < len; i++) {
            if (this.TabUser2[i]['UserID'] != this.i) {
                imessages.push({ itext: '', idate: '', otext: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[i]['Message'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8), odate: this.TabUser2[i]['DateMsg'], notif: this.TabUser2[i]['Notification'] });
            }
            else {
                imessages.push({ itext: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[i]['Message'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8), idate: this.TabUser2[i]['DateMsg'], otext: '', odate: '', notif: this.TabUser2[i]['Notification'] });
                if (this.TabUser2[i]['Notification'] == 1)
                    nmessages.push({ itext: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[i]['Message'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8), idate: this.TabUser2[i]['DateMsg'], otext: '', odate: '', notif: this.TabUser2[i]['Notification'] });
            }
        }
        var car = { text: 'mdr', date: '01/02/1996' };
        this.messages = imessages;
        this.messages_Chat = imessages;
        this.messages_Notif = nmessages;
        setTimeout(function () {
            _this.contentArea.scrollToBottom(300);
        }, 200);
        this.refreshPage();
    }
    MsgSavEmployePage.prototype.refreshPage = function () {
        var _this = this;
        setTimeout(function () {
            _this.cooling();
        }, 1000);
    };
    MsgSavEmployePage.prototype.cooling = function () {
        var _this = this;
        setTimeout(function () {
            _this.TabUser2 = null;
            var InTabUser2 = [];
            firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/msg_sav/' + _this.i).on("value", function (snapshot) {
                var tg = snapshot.val();
                tg.forEach(function (entry) {
                    InTabUser2.push(entry);
                });
            }, function (error) {
            });
            _this.TabUser2 = InTabUser2;
            InTabUser2 = null;
            var imessages = [
                { itext: '', idate: '', otext: '', odate: '', notif: 0 }
            ];
            var nmessages = [
                { itext: '', idate: '', otext: '', odate: '', notif: 0 }
            ];
            var VigiK = "";
            firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
                var tg = snapshot.val();
                VigiK = tg[0]['Vigi'];
            }, function (error) {
                console.log("Error dans Cry: " + error.code);
            });
            for (var i = 0, len = _this.TabUser2.length; i < len; i++) {
                if (_this.TabUser2[i]['UserID'] != _this.i) {
                    imessages.push({ itext: '', idate: '', otext: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(_this.TabUser2[i]['Message'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8), odate: _this.TabUser2[i]['DateMsg'], notif: _this.TabUser2[i]['Notification'] });
                }
                else {
                    imessages.push({ itext: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(_this.TabUser2[i]['Message'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8), idate: _this.TabUser2[i]['DateMsg'], otext: '', odate: '', notif: _this.TabUser2[i]['Notification'] });
                    if (_this.TabUser2[i]['Notification'] == 1)
                        nmessages.push({ itext: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(_this.TabUser2[i]['Message'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8), idate: _this.TabUser2[i]['DateMsg'], otext: '', odate: '', notif: _this.TabUser2[i]['Notification'] });
                }
            }
            var car = { text: 'mdr', date: '01/02/1996' };
            _this.messages = imessages;
            _this.messages_Chat = imessages;
            _this.messages_Notif = nmessages;
            _this.refreshPage();
        }, 1000);
    };
    MsgSavEmployePage.prototype.sort = function () {
    };
    MsgSavEmployePage.prototype.close = function () {
        this.modalCtrl.dismiss();
    };
    MsgSavEmployePage.prototype.Remisa0ftn = function () {
        this.remisa0 = "";
    };
    MsgSavEmployePage.prototype.writeUserData = function () {
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/msg_sav/' + this.i).set(this.TabUser2).then(function (data) {
        }, function (error) {
        });
        ;
    };
    MsgSavEmployePage.prototype.sendMsg = function () {
        var _this = this;
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        var utc = new Date().toJSON().slice(0, 10).replace(/-/g, '/');
        if (this.Type_notif && this.Type_notif.length > 0) {
            this.TabUser2.push({ DateMsg: utc, Message: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Type_notif.trim(), VigiK.trim()).toString(), Notification: 1, UserID: firebase__WEBPACK_IMPORTED_MODULE_1__["auth"]().currentUser.uid });
            this.writeUserData();
            this.messages.push({ itext: '', idate: '', otext: this.Type_notif, odate: utc, notif: 1 });
            this.Type_notif = "";
            setTimeout(function () {
                _this.contentArea.scrollToBottom(300);
            }, 400);
        }
        else if (!this.Msg2Send || this.Msg2Send.length < 1)
            return;
        this.TabUser2.push({ DateMsg: utc, Message: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Msg2Send.trim(), VigiK.trim()).toString(), Notification: 1, UserID: firebase__WEBPACK_IMPORTED_MODULE_1__["auth"]().currentUser.uid });
        this.writeUserData();
        this.messages.push({ itext: '', idate: '', otext: this.Msg2Send, odate: utc, notif: 0 });
        this.Msg2Send = "";
        setTimeout(function () {
            _this.contentArea.scrollToBottom(300);
        }, 400);
    };
    MsgSavEmployePage.prototype.Joindre = function () {
        return __awaiter(this, void 0, void 0, function () {
            var actionSheet;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.actionSheetController.create({
                            header: 'Joindre un élément',
                            buttons: [{
                                    text: 'Parcourir',
                                    role: 'add',
                                    icon: 'add',
                                    handler: function () {
                                    }
                                },
                                {
                                    text: 'Cancel',
                                    icon: 'close',
                                    role: 'cancel',
                                    handler: function () {
                                    }
                                }]
                        })];
                    case 1:
                        actionSheet = _a.sent();
                        return [4 /*yield*/, actionSheet.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    MsgSavEmployePage.prototype.sorti = function () {
        this.contentArea.scrollToBottom(300); //300ms animation speed
    };
    MsgSavEmployePage.prototype.ngOnInit = function () {
    };
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])(_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonContent"]),
        __metadata("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["IonContent"])
    ], MsgSavEmployePage.prototype, "contentArea", void 0);
    __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ViewChild"])('content'),
        __metadata("design:type", Object)
    ], MsgSavEmployePage.prototype, "content", void 0);
    MsgSavEmployePage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-msg-sav-employe',
            template: __webpack_require__(/*! ./msg-sav-employe.page.html */ "./src/app/Modal/msg-sav-employe/msg-sav-employe.page.html"),
            styles: [__webpack_require__(/*! ./msg-sav-employe.page.scss */ "./src/app/Modal/msg-sav-employe/msg-sav-employe.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ActionSheetController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavParams"]])
    ], MsgSavEmployePage);
    return MsgSavEmployePage;
}());



/***/ }),

/***/ "./src/app/message2/message2.module.ts":
/*!*********************************************!*\
  !*** ./src/app/message2/message2.module.ts ***!
  \*********************************************/
/*! exports provided: Message2PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Message2PageModule", function() { return Message2PageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _message2_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./message2.page */ "./src/app/message2/message2.page.ts");
/* harmony import */ var _Modal_msg_sav_employe_msg_sav_employe_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Modal/msg-sav-employe/msg-sav-employe.module */ "./src/app/Modal/msg-sav-employe/msg-sav-employe.module.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var routes = [
    {
        path: '',
        component: _message2_page__WEBPACK_IMPORTED_MODULE_5__["Message2Page"]
    }
];
var Message2PageModule = /** @class */ (function () {
    function Message2PageModule() {
    }
    Message2PageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes),
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
                _Modal_msg_sav_employe_msg_sav_employe_module__WEBPACK_IMPORTED_MODULE_6__["MsgSavEmployePageModule"]
            ],
            declarations: [_message2_page__WEBPACK_IMPORTED_MODULE_5__["Message2Page"]]
        })
    ], Message2PageModule);
    return Message2PageModule;
}());



/***/ }),

/***/ "./src/app/message2/message2.page.html":
/*!*********************************************!*\
  !*** ./src/app/message2/message2.page.html ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = " <!-- <link href=\"//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css\" rel=\"stylesheet\" id=\"bootstrap-css\">\n<script src=\"//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js\"></script>\n<script src=\"//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js\"></script>\n<head>\n<link href=\"https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css\" type=\"text/css\" rel=\"stylesheet\">\n</head> -->\n  <ion-header>\n    <ion-toolbar></ion-toolbar>\n      <ion-toolbar color=\"primary\">\n        <ion-title >Chat</ion-title>\n      </ion-toolbar>\n  </ion-header>\n  <ion-content padding>\n    <ion-refresher slot=\"fixed\" (ionRefresh)=\"doRefresh($event)\">\n      <ion-refresher-content\n        pullingIcon=\"arrow-dropdown\"\n        pullingText=\"Tirer pour rafraîchir\"\n        refreshingSpinner=\"circles\"\n        refreshingText=\"Rechargement en cours...\">\n      </ion-refresher-content>\n    </ion-refresher>\n    <ion-button (click)=\"ngOnIniit()\">Actualiser la page</ion-button>\n      <ion-card>\n\n            <ion-item *ngFor=\"let m of messages\" (click)=\"goToChat(m.ID)\" class=\"activated\">\n                <div  slot=\"start\" class=\"bonbon\">\n                  <div class=\"avatar-circle\">\n                      <span class=\"initials\">{{m.Nom.charAt(0) +m.Prenom.charAt(0)}}</span>\n                    </div>&nbsp;&nbsp;&nbsp;\n                  </div>\n                  <ion-card-subtitle>\n                     {{m.Nom}} {{m.Prenom}}\n                  </ion-card-subtitle>\n                  \n                    <ion-card-subtitle color=\"{{Jcroiscstbn2(m.ID)}}\" style=\"padding: 2%\"> {{Jcroiscstbn(m.ID)}} \n                    </ion-card-subtitle>\n              </ion-item>\n        </ion-card>\n        \n  \n\n  </ion-content>"

/***/ }),

/***/ "./src/app/message2/message2.page.scss":
/*!*********************************************!*\
  !*** ./src/app/message2/message2.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .avatar-circle {\n  width: 28px;\n  height: 28px;\n  background-color: black;\n  text-align: center;\n  border-radius: 50%;\n  -webkit-border-radius: 50%;\n  -moz-border-radius: 50%;\n  margin-left: auto;\n  margin-right: auto; }\n\n:host .bonbon {\n  margin-top: 2% !important; }\n\n:host .initials {\n  position: relative;\n  top: 5px;\n  /* 25% of parent */\n  font-size: 16px;\n  /* 50% of parent */\n  line-height: 16px;\n  /* 50% of parent */\n  color: #fff;\n  font-family: \"Courier New\", monospace;\n  font-weight: bold; }\n\n:host .h1 {\n  color: #333986; }\n\n:host .container {\n  max-width: 1170px;\n  margin: auto; }\n\n:host img {\n  max-width: 100%; }\n\n:host .inbox_people {\n  background: #f8f8f8 none repeat scroll 0 0;\n  float: left;\n  overflow: hidden;\n  width: 40%;\n  border-right: 1px solid #c4c4c4; }\n\n:host .inbox_msg {\n  border: 1px solid #c4c4c4;\n  clear: both;\n  overflow: hidden; }\n\n:host .top_spac {\n  margin: 20px 0 0; }\n\n:host .recent_heading {\n  float: left;\n  width: 40%; }\n\n:host .srch_bar {\n  display: inline-block;\n  text-align: right;\n  width: 60%; }\n\n:host .headind_srch {\n  padding: 10px 29px 10px 20px;\n  overflow: hidden;\n  border-bottom: 1px solid #c4c4c4; }\n\n:host .recent_heading h4 {\n  color: #05728f;\n  font-size: 21px;\n  margin: auto; }\n\n:host .srch_bar input {\n  border: 1px solid #cdcdcd;\n  border-width: 0 0 1px 0;\n  width: 80%;\n  padding: 2px 0 4px 6px;\n  background: none; }\n\n:host .srch_bar .input-group-addon button {\n  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;\n  border: medium none;\n  padding: 0;\n  color: #707070;\n  font-size: 18px; }\n\n:host .srch_bar .input-group-addon {\n  margin: 0 0 0 -27px; }\n\n:host .chat_ib h5 {\n  font-size: 15px;\n  color: #464646;\n  margin: 0 0 8px 0; }\n\n:host .chat_ib h5 span {\n  font-size: 13px;\n  float: right; }\n\n:host .chat_ib p {\n  font-size: 14px;\n  color: #989898;\n  margin: auto; }\n\n:host .chat_img {\n  float: left;\n  width: 11%; }\n\n:host .chat_ib {\n  float: left;\n  padding: 0 0 0 15px;\n  width: 88%; }\n\n:host .chat_people {\n  overflow: hidden;\n  clear: both; }\n\n:host .chat_list {\n  border-bottom: 1px solid #c4c4c4;\n  margin: 0;\n  padding: 18px 16px 10px; }\n\n:host .inbox_chat {\n  height: 550px;\n  overflow-y: scroll; }\n\n:host .active_chat {\n  background: #ebebeb; }\n\n:host .incoming_msg_img {\n  display: inline-block;\n  width: 6%; }\n\n:host .received_msg {\n  display: inline-block;\n  padding: 0 0 0 10px;\n  vertical-align: top;\n  width: 92%; }\n\n:host .received_withd_msg p {\n  background: #ebebeb none repeat scroll 0 0;\n  border-radius: 3px;\n  color: #646464;\n  font-size: 14px;\n  margin: 0;\n  padding: 5px 10px 5px 12px;\n  width: 100%; }\n\n:host .time_date {\n  color: #747474;\n  display: block;\n  font-size: 12px;\n  margin: 8px 0 0; }\n\n:host .received_withd_msg {\n  width: 57%; }\n\n:host .mesgs {\n  float: left;\n  padding: 30px 15px 0 25px;\n  width: 100%; }\n\n:host .sent_msg p {\n  background: #333986 none repeat scroll 0 0;\n  border-radius: 3px;\n  font-size: 14px;\n  margin: 0;\n  color: #fff;\n  padding: 5px 10px 5px 12px;\n  width: 100%; }\n\n:host .outgoing_msg {\n  overflow: hidden;\n  margin: 26px 0 26px; }\n\n:host .sent_msg {\n  float: right;\n  width: 46%; }\n\n:host .input_msg_write input {\n  background: rgba(0, 0, 0, 0) none repeat scroll 0 0;\n  border: medium none;\n  color: #4c4c4c;\n  font-size: 15px;\n  min-height: 48px;\n  width: 100%; }\n\n:host .type_msg {\n  border-top: 1px solid #c4c4c4;\n  position: relative; }\n\n:host .msg_send_btn {\n  background: #05728f none repeat scroll 0 0;\n  border: medium none;\n  border-radius: 50%;\n  color: #fff;\n  cursor: pointer;\n  font-size: 17px;\n  height: 33px;\n  position: absolute;\n  right: 0;\n  top: 11px;\n  width: 33px; }\n\n:host .messaging {\n  padding: 0vh;\n  height: 80%; }\n\n:host .msg_history {\n  height: 100%;\n  overflow-y: auto; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbWVzc2FnZTIvQzpcXFVzZXJzXFxJcmlzIEdlcmFsZG9cXERvY3VtZW50c1xcT3V0YWxtYWZpblxcT3V0YWxtYS9zcmNcXGFwcFxcbWVzc2FnZTJcXG1lc3NhZ2UyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUVJLFdBQVc7RUFDWCxZQUFZO0VBQ1osdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsMEJBQTBCO0VBQzFCLHVCQUF1QjtFQUN2QixpQkFBaUI7RUFDakIsa0JBQWtCLEVBQUE7O0FBVnRCO0VBY0kseUJBQ0YsRUFBQTs7QUFmRjtFQWtCSSxrQkFBa0I7RUFDbEIsUUFBUTtFQUFFLGtCQUFBO0VBQ1YsZUFBZTtFQUFFLGtCQUFBO0VBQ2pCLGlCQUFpQjtFQUFFLGtCQUFBO0VBQ25CLFdBQVc7RUFDWCxxQ0FBcUM7RUFDckMsaUJBQWlCLEVBQUE7O0FBeEJyQjtFQTRCSSxjQUNGLEVBQUE7O0FBN0JGO0VBK0JpQixpQkFBZ0I7RUFBRSxZQUFXLEVBQUE7O0FBL0I5QztFQWdDVyxlQUFjLEVBQUE7O0FBaEN6QjtFQWtDUSwwQ0FBMEM7RUFDMUMsV0FBVztFQUNYLGdCQUFnQjtFQUNoQixVQUFVO0VBQUUsK0JBQThCLEVBQUE7O0FBckNsRDtFQXdDUSx5QkFBeUI7RUFDekIsV0FBVztFQUNYLGdCQUFnQixFQUFBOztBQTFDeEI7RUE0Q2lCLGdCQUFnQixFQUFBOztBQTVDakM7RUErQ3VCLFdBQVc7RUFBRSxVQUFTLEVBQUE7O0FBL0M3QztFQWlEUSxxQkFBcUI7RUFDckIsaUJBQWlCO0VBQ2pCLFVBQVUsRUFBQTs7QUFuRGxCO0VBcURxQiw0QkFBMkI7RUFBRSxnQkFBZTtFQUFFLGdDQUErQixFQUFBOztBQXJEbEc7RUF3RFEsY0FBYztFQUNkLGVBQWU7RUFDZixZQUFZLEVBQUE7O0FBMURwQjtFQTREdUIseUJBQXdCO0VBQUUsdUJBQXNCO0VBQUUsVUFBUztFQUFFLHNCQUFxQjtFQUFFLGdCQUFlLEVBQUE7O0FBNUQxSDtFQThEUSxtREFBbUQ7RUFDbkQsbUJBQW1CO0VBQ25CLFVBQVU7RUFDVixjQUFjO0VBQ2QsZUFBZSxFQUFBOztBQWxFdkI7RUFvRXFDLG1CQUFtQixFQUFBOztBQXBFeEQ7RUFzRW1CLGVBQWM7RUFBRSxjQUFhO0VBQUUsaUJBQWdCLEVBQUE7O0FBdEVsRTtFQXVFd0IsZUFBYztFQUFFLFlBQVcsRUFBQTs7QUF2RW5EO0VBd0VrQixlQUFjO0VBQUUsY0FBYTtFQUFFLFlBQVcsRUFBQTs7QUF4RTVEO0VBMEVRLFdBQVc7RUFDWCxVQUFVLEVBQUE7O0FBM0VsQjtFQThFUSxXQUFXO0VBQ1gsbUJBQW1CO0VBQ25CLFVBQVUsRUFBQTs7QUFoRmxCO0VBbUZvQixnQkFBZTtFQUFFLFdBQVUsRUFBQTs7QUFuRi9DO0VBcUZRLGdDQUFnQztFQUNoQyxTQUFTO0VBQ1QsdUJBQXVCLEVBQUE7O0FBdkYvQjtFQXlGb0IsYUFBYTtFQUFFLGtCQUFrQixFQUFBOztBQXpGckQ7RUEyRm9CLG1CQUFrQixFQUFBOztBQTNGdEM7RUE4RlEscUJBQXFCO0VBQ3JCLFNBQVMsRUFBQTs7QUEvRmpCO0VBa0dRLHFCQUFxQjtFQUNyQixtQkFBbUI7RUFDbkIsbUJBQW1CO0VBQ25CLFVBQVUsRUFBQTs7QUFyR2xCO0VBd0dRLDBDQUEwQztFQUMxQyxrQkFBa0I7RUFDbEIsY0FBYztFQUNkLGVBQWU7RUFDZixTQUFTO0VBQ1QsMEJBQTBCO0VBQzFCLFdBQVcsRUFBQTs7QUE5R25CO0VBaUhRLGNBQWM7RUFDZCxjQUFjO0VBQ2QsZUFBZTtFQUNmLGVBQWUsRUFBQTs7QUFwSHZCO0VBc0g0QixVQUFVLEVBQUE7O0FBdEh0QztFQXdIUSxXQUFXO0VBQ1gseUJBQXlCO0VBQ3pCLFdBQVcsRUFBQTs7QUExSG5CO0VBOEhRLDBDQUEwQztFQUMxQyxrQkFBa0I7RUFDbEIsZUFBZTtFQUNmLFNBQVM7RUFBRSxXQUFVO0VBQ3JCLDBCQUEwQjtFQUMxQixXQUFVLEVBQUE7O0FBbklsQjtFQXFJcUIsZ0JBQWU7RUFBRSxtQkFBa0IsRUFBQTs7QUFySXhEO0VBdUlRLFlBQVk7RUFDWixVQUFVLEVBQUE7O0FBeElsQjtFQTJJUSxtREFBbUQ7RUFDbkQsbUJBQW1CO0VBQ25CLGNBQWM7RUFDZCxlQUFlO0VBQ2YsZ0JBQWdCO0VBQ2hCLFdBQVcsRUFBQTs7QUFoSm5CO0VBbUppQiw2QkFBNkI7RUFBQyxrQkFBa0IsRUFBQTs7QUFuSmpFO0VBcUpRLDBDQUEwQztFQUMxQyxtQkFBbUI7RUFDbkIsa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxlQUFlO0VBQ2YsZUFBZTtFQUNmLFlBQVk7RUFDWixrQkFBa0I7RUFDbEIsUUFBUTtFQUNSLFNBQVM7RUFDVCxXQUFXLEVBQUE7O0FBL0puQjtFQWlLbUIsWUFBWTtFQUN6QixXQUFXLEVBQUE7O0FBbEtqQjtFQXFLUSxZQUFZO0VBQ1osZ0JBQWdCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9tZXNzYWdlMi9tZXNzYWdlMi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcclxuOmhvc3R7XHJcbiAgLmF2YXRhci1jaXJjbGUge1xyXG4gICAgd2lkdGg6IDI4cHg7XHJcbiAgICBoZWlnaHQ6IDI4cHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgIC13ZWJraXQtYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgLW1vei1ib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICBtYXJnaW4tbGVmdDogYXV0bztcclxuICAgIG1hcmdpbi1yaWdodDogYXV0bztcclxuICB9XHJcblxyXG4gIC5ib25ib257XHJcbiAgICBtYXJnaW4tdG9wOjIlICFpbXBvcnRhbnRcclxuICB9XHJcbiAgXHJcbiAgLmluaXRpYWxzIHtcclxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgIHRvcDogNXB4OyAvKiAyNSUgb2YgcGFyZW50ICovXHJcbiAgICBmb250LXNpemU6IDE2cHg7IC8qIDUwJSBvZiBwYXJlbnQgKi9cclxuICAgIGxpbmUtaGVpZ2h0OiAxNnB4OyAvKiA1MCUgb2YgcGFyZW50ICovXHJcbiAgICBjb2xvcjogI2ZmZjtcclxuICAgIGZvbnQtZmFtaWx5OiBcIkNvdXJpZXIgTmV3XCIsIG1vbm9zcGFjZTtcclxuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xyXG4gIH1cclxuXHJcbiAgLmgxe1xyXG4gICAgY29sb3I6ICMzMzM5ODZcclxuICB9XHJcbiAgXHJcbiAgICAgIC5jb250YWluZXJ7bWF4LXdpZHRoOjExNzBweDsgbWFyZ2luOmF1dG87fVxyXG4gICAgICBpbWd7IG1heC13aWR0aDoxMDAlO31cclxuICAgICAgLmluYm94X3Blb3BsZSB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogI2Y4ZjhmOCBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xyXG4gICAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICAgIG92ZXJmbG93OiBoaWRkZW47XHJcbiAgICAgICAgd2lkdGg6IDQwJTsgYm9yZGVyLXJpZ2h0OjFweCBzb2xpZCAjYzRjNGM0O1xyXG4gICAgICB9XHJcbiAgICAgIC5pbmJveF9tc2cge1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNjNGM0YzQ7XHJcbiAgICAgICAgY2xlYXI6IGJvdGg7XHJcbiAgICAgICAgb3ZlcmZsb3c6IGhpZGRlbjtcclxuICAgICAgfVxyXG4gICAgICAudG9wX3NwYWN7IG1hcmdpbjogMjBweCAwIDA7fVxyXG5cclxuXHJcbiAgICAgIC5yZWNlbnRfaGVhZGluZyB7ZmxvYXQ6IGxlZnQ7IHdpZHRoOjQwJTt9XHJcbiAgICAgIC5zcmNoX2JhciB7XHJcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgIHRleHQtYWxpZ246IHJpZ2h0O1xyXG4gICAgICAgIHdpZHRoOiA2MCU7XHJcbiAgICAgIH1cclxuICAgICAgLmhlYWRpbmRfc3JjaHsgcGFkZGluZzoxMHB4IDI5cHggMTBweCAyMHB4OyBvdmVyZmxvdzpoaWRkZW47IGJvcmRlci1ib3R0b206MXB4IHNvbGlkICNjNGM0YzQ7fVxyXG5cclxuICAgICAgLnJlY2VudF9oZWFkaW5nIGg0IHtcclxuICAgICAgICBjb2xvcjogIzA1NzI4ZjtcclxuICAgICAgICBmb250LXNpemU6IDIxcHg7XHJcbiAgICAgICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgICB9XHJcbiAgICAgIC5zcmNoX2JhciBpbnB1dHsgYm9yZGVyOjFweCBzb2xpZCAjY2RjZGNkOyBib3JkZXItd2lkdGg6MCAwIDFweCAwOyB3aWR0aDo4MCU7IHBhZGRpbmc6MnB4IDAgNHB4IDZweDsgYmFja2dyb3VuZDpub25lO31cclxuICAgICAgLnNyY2hfYmFyIC5pbnB1dC1ncm91cC1hZGRvbiBidXR0b24ge1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMCkgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcclxuICAgICAgICBib3JkZXI6IG1lZGl1bSBub25lO1xyXG4gICAgICAgIHBhZGRpbmc6IDA7XHJcbiAgICAgICAgY29sb3I6ICM3MDcwNzA7XHJcbiAgICAgICAgZm9udC1zaXplOiAxOHB4O1xyXG4gICAgICB9XHJcbiAgICAgIC5zcmNoX2JhciAuaW5wdXQtZ3JvdXAtYWRkb24geyBtYXJnaW46IDAgMCAwIC0yN3B4O31cclxuXHJcbiAgICAgIC5jaGF0X2liIGg1eyBmb250LXNpemU6MTVweDsgY29sb3I6IzQ2NDY0NjsgbWFyZ2luOjAgMCA4cHggMDt9XHJcbiAgICAgIC5jaGF0X2liIGg1IHNwYW57IGZvbnQtc2l6ZToxM3B4OyBmbG9hdDpyaWdodDt9XHJcbiAgICAgIC5jaGF0X2liIHB7IGZvbnQtc2l6ZToxNHB4OyBjb2xvcjojOTg5ODk4OyBtYXJnaW46YXV0b31cclxuICAgICAgLmNoYXRfaW1nIHtcclxuICAgICAgICBmbG9hdDogbGVmdDtcclxuICAgICAgICB3aWR0aDogMTElO1xyXG4gICAgICB9XHJcbiAgICAgIC5jaGF0X2liIHtcclxuICAgICAgICBmbG9hdDogbGVmdDtcclxuICAgICAgICBwYWRkaW5nOiAwIDAgMCAxNXB4O1xyXG4gICAgICAgIHdpZHRoOiA4OCU7XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC5jaGF0X3Blb3BsZXsgb3ZlcmZsb3c6aGlkZGVuOyBjbGVhcjpib3RoO31cclxuICAgICAgLmNoYXRfbGlzdCB7XHJcbiAgICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICNjNGM0YzQ7XHJcbiAgICAgICAgbWFyZ2luOiAwO1xyXG4gICAgICAgIHBhZGRpbmc6IDE4cHggMTZweCAxMHB4O1xyXG4gICAgICB9XHJcbiAgICAgIC5pbmJveF9jaGF0IHsgaGVpZ2h0OiA1NTBweDsgb3ZlcmZsb3cteTogc2Nyb2xsO31cclxuXHJcbiAgICAgIC5hY3RpdmVfY2hhdHsgYmFja2dyb3VuZDojZWJlYmViO31cclxuXHJcbiAgICAgIC5pbmNvbWluZ19tc2dfaW1nIHtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgd2lkdGg6IDYlO1xyXG4gICAgICB9XHJcbiAgICAgIC5yZWNlaXZlZF9tc2cge1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICBwYWRkaW5nOiAwIDAgMCAxMHB4O1xyXG4gICAgICAgIHZlcnRpY2FsLWFsaWduOiB0b3A7XHJcbiAgICAgICAgd2lkdGg6IDkyJTtcclxuICAgICAgfVxyXG4gICAgICAucmVjZWl2ZWRfd2l0aGRfbXNnIHAge1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICNlYmViZWIgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAzcHg7XHJcbiAgICAgICAgY29sb3I6ICM2NDY0NjQ7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNHB4O1xyXG4gICAgICAgIG1hcmdpbjogMDtcclxuICAgICAgICBwYWRkaW5nOiA1cHggMTBweCA1cHggMTJweDtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgfVxyXG4gICAgICAudGltZV9kYXRlIHtcclxuICAgICAgICBjb2xvcjogIzc0NzQ3NDtcclxuICAgICAgICBkaXNwbGF5OiBibG9jaztcclxuICAgICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICAgICAgbWFyZ2luOiA4cHggMCAwO1xyXG4gICAgICB9XHJcbiAgICAgIC5yZWNlaXZlZF93aXRoZF9tc2cgeyB3aWR0aDogNTclO31cclxuICAgICAgLm1lc2dzIHtcclxuICAgICAgICBmbG9hdDogbGVmdDtcclxuICAgICAgICBwYWRkaW5nOiAzMHB4IDE1cHggMCAyNXB4O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAuc2VudF9tc2cgcCB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogIzMzMzk4NiBub25lIHJlcGVhdCBzY3JvbGwgMCAwO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDNweDtcclxuICAgICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICAgICAgbWFyZ2luOiAwOyBjb2xvcjojZmZmO1xyXG4gICAgICAgIHBhZGRpbmc6IDVweCAxMHB4IDVweCAxMnB4O1xyXG4gICAgICAgIHdpZHRoOjEwMCU7XHJcbiAgICAgIH1cclxuICAgICAgLm91dGdvaW5nX21zZ3sgb3ZlcmZsb3c6aGlkZGVuOyBtYXJnaW46MjZweCAwIDI2cHg7fVxyXG4gICAgICAuc2VudF9tc2cge1xyXG4gICAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgICB3aWR0aDogNDYlO1xyXG4gICAgICB9XHJcbiAgICAgIC5pbnB1dF9tc2dfd3JpdGUgaW5wdXQge1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHJnYmEoMCwgMCwgMCwgMCkgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcclxuICAgICAgICBib3JkZXI6IG1lZGl1bSBub25lO1xyXG4gICAgICAgIGNvbG9yOiAjNGM0YzRjO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgICBtaW4taGVpZ2h0OiA0OHB4O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICB9XHJcblxyXG4gICAgICAudHlwZV9tc2cge2JvcmRlci10b3A6IDFweCBzb2xpZCAjYzRjNGM0O3Bvc2l0aW9uOiByZWxhdGl2ZTt9XHJcbiAgICAgIC5tc2dfc2VuZF9idG4ge1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICMwNTcyOGYgbm9uZSByZXBlYXQgc2Nyb2xsIDAgMDtcclxuICAgICAgICBib3JkZXI6IG1lZGl1bSBub25lO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICBjb2xvcjogI2ZmZjtcclxuICAgICAgICBjdXJzb3I6IHBvaW50ZXI7XHJcbiAgICAgICAgZm9udC1zaXplOiAxN3B4O1xyXG4gICAgICAgIGhlaWdodDogMzNweDtcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgcmlnaHQ6IDA7XHJcbiAgICAgICAgdG9wOiAxMXB4O1xyXG4gICAgICAgIHdpZHRoOiAzM3B4O1xyXG4gICAgICB9XHJcbiAgICAgIC5tZXNzYWdpbmcgeyBwYWRkaW5nOiAwdmg7XHJcbiAgICAgIGhlaWdodDogODAlO1xyXG4gICAgICB9XHJcbiAgICAgIC5tc2dfaGlzdG9yeSB7XHJcbiAgICAgICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgICAgIG92ZXJmbG93LXk6IGF1dG87XHJcbiAgICAgIH1cclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/message2/message2.page.ts":
/*!*******************************************!*\
  !*** ./src/app/message2/message2.page.ts ***!
  \*******************************************/
/*! exports provided: Message2Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Message2Page", function() { return Message2Page; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Modal_msg_sav_employe_msg_sav_employe_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../Modal/msg-sav-employe/msg-sav-employe.page */ "./src/app/Modal/msg-sav-employe/msg-sav-employe.page.ts");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_4__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};





var sv;
var sv2;
var message = [
    { text: 'Bonjour j\'ai une question.', date: '20 novembre 2018' },
];
var Message2Page = /** @class */ (function () {
    function Message2Page(actionSheetController, modalCtrl) {
        this.actionSheetController = actionSheetController;
        this.modalCtrl = modalCtrl;
        this.VigiK = "";
        this.messages = [
            { Message: 'Bonjour j\'ai une question.', DateMsg: '20 novembre 2018', Nom: "FIFI", Prenom: "LOULOU", Id: "", UserID: "" },
            { Message: 'Bonjour j\'ai une question.', DateMsg: '20 novembre 2018', Nom: "FIFI", Prenom: "LOULOU", Id: "", UserID: "" }
        ];
        this.messages2 = [];
        this.refreshPage();
        this.messages2 = sv;
    }
    Message2Page.prototype.refreshPage = function () {
        var _this = this;
        setTimeout(function () {
            _this.cooling();
        }, 4000);
    };
    Message2Page.prototype.cooling = function () {
        var _this = this;
        setTimeout(function () {
            _this.ngOnInit();
            _this.refreshPage();
        }, 4000);
    };
    Message2Page.prototype.Jcroiscstbn3 = function (id) {
        var m3 = this.messages2[id].length;
        // console.log(this.messages2[id],'moooon',m)
        var hihi2 = this.messages2[id][m3 - 1].Notification;
        if (hihi2 == 0) {
            hihi2 = "danger";
        }
        else {
            hihi2 = "primary";
        }
        // console.log(hihi)
        return hihi2;
    };
    Message2Page.prototype.writeMsgData = function (id, messages2) {
        var m3 = messages2[id].length;
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('msg_sav/' + id + "/" + (m3 - 1) + "/Notification").set(1).then(function (snapshot) {
        }, function (error) {
        });
        ;
    };
    Message2Page.prototype.Jcroiscstbn = function (id) {
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        if (this.messages2 != undefined) {
            if (this.messages2[id] != undefined) {
                var m2 = this.messages2[id].length;
                var hihi = crypto_js__WEBPACK_IMPORTED_MODULE_4__["AES"].decrypt(this.messages2[id][m2 - 1].Message.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_4__["enc"].Utf8);
            }
        }
        return hihi;
    };
    Message2Page.prototype.Jcroiscstbn2 = function (id) {
        if (this.messages2 != undefined) {
            if (this.messages2[id] != undefined) {
                var m2 = this.messages2[id].length;
                var hihi2 = this.messages2[id][m2 - 1].Notification;
                if (hihi2 == 0) {
                    hihi2 = "danger";
                }
                else {
                    hihi2 = "primary";
                }
            }
        }
        return hihi2;
    };
    Message2Page.prototype.readMsgData = function () {
        var _this = this;
        return new Promise(function (resolve) {
            setTimeout(function () {
                resolve('resolved');
                var InTabDemandes = [];
                firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/Gestion').on("value", function (snapshot) {
                    var sv = snapshot.val();
                }, function (error) {
                });
                _this.messages = sv;
            }, 1);
        });
    };
    Message2Page.prototype.doRefresh = function (event) {
        var _this = this;
        setTimeout(function () {
            _this.ngOnInit();
            event.target.complete();
        }, 2000);
    };
    Message2Page.prototype.readMsg2Data = function () {
        var _this = this;
        return new Promise(function (resolve) {
            setTimeout(function () {
                resolve('resolved');
                var InTabDemandes = [];
                firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/msg_sav/').on("value", function (snapshot) {
                    sv = snapshot.val();
                }, function (error) {
                });
                _this.messages2 = sv;
            }, 2000);
        });
    };
    Message2Page.prototype.goToChat = function (id) {
        return __awaiter(this, void 0, void 0, function () {
            var messages2, messages, writeMsgData, modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        messages2 = this.messages2;
                        messages = this.messages;
                        this.readMsg2Data();
                        writeMsgData = this.writeMsgData;
                        writeMsgData(id, messages2);
                        return [4 /*yield*/, this.modalCtrl.create({
                                component: _Modal_msg_sav_employe_msg_sav_employe_page__WEBPACK_IMPORTED_MODULE_3__["MsgSavEmployePage"],
                                componentProps: { 'suivi': this.messages, 'i': id }
                            })];
                    case 1:
                        modal = _a.sent();
                        modal.onWillDismiss().then(function () {
                            writeMsgData(id, messages2);
                            setTimeout(function () {
                                firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/msg_sav/').on("value", function (snapshot) {
                                    sv = snapshot.val();
                                }, function (error) {
                                });
                                messages2 = sv;
                                var m3 = messages2[id].length;
                                firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('msg_sav/' + id + "/" + (m3 - 1) + "/Notification").set(1).then(function (snapshot) {
                                }, function (error) {
                                });
                                ;
                                firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/Gestion').on("value", function (snapshot) {
                                    sv2 = snapshot.val();
                                }, function (error) {
                                });
                                messages = sv2;
                            }, 100);
                        });
                        modal.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    Message2Page.prototype.ngOnIniit = function () {
        var _this = this;
        setTimeout(function () {
            _this.readMsg2Data();
            _this.readMsgData();
        }, 100);
    };
    Message2Page.prototype.ngOnInit = function () {
        this.readMsgData();
        this.readMsg2Data();
    };
    Message2Page.prototype.getItems2 = function (ev) {
        // Reset items back to all of the items
        this.readMsgData();
        // set val to the value of the searchbar
        var val = "k";
        // if the value is an empty string don't filter the items
        if (val && val.trim() != '') {
            this.messages = this.messages.filter(function (s) {
                return (s.Id.toLowerCase().indexOf(s.UserID.toLowerCase()) > -1);
            });
        }
    };
    Message2Page.prototype.Joindre = function () {
        return __awaiter(this, void 0, void 0, function () {
            var actionSheet;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.actionSheetController.create({
                            header: 'Joindre un élément',
                            buttons: [{
                                    text: 'Parcourir',
                                    role: 'add',
                                    icon: 'add',
                                    handler: function () {
                                    }
                                },
                                {
                                    text: 'Cancel',
                                    icon: 'close',
                                    role: 'cancel',
                                    handler: function () {
                                    }
                                }]
                        })];
                    case 1:
                        actionSheet = _a.sent();
                        return [4 /*yield*/, actionSheet.present()];
                    case 2:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    Message2Page = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-message2',
            template: __webpack_require__(/*! ./message2.page.html */ "./src/app/message2/message2.page.html"),
            styles: [__webpack_require__(/*! ./message2.page.scss */ "./src/app/message2/message2.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ActionSheetController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"]])
    ], Message2Page);
    return Message2Page;
}());



/***/ })

}]);
//# sourceMappingURL=message2-message2-module.js.map