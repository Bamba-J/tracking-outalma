(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["form2-form2-module"],{

/***/ "./src/app/form2/form2.module.ts":
/*!***************************************!*\
  !*** ./src/app/form2/form2.module.ts ***!
  \***************************************/
/*! exports provided: Form2PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Form2PageModule", function() { return Form2PageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _form2_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./form2.page */ "./src/app/form2/form2.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _form2_page__WEBPACK_IMPORTED_MODULE_5__["Form2Page"]
    }
];
var Form2PageModule = /** @class */ (function () {
    function Form2PageModule() {
    }
    Form2PageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_form2_page__WEBPACK_IMPORTED_MODULE_5__["Form2Page"]]
        })
    ], Form2PageModule);
    return Form2PageModule;
}());



/***/ }),

/***/ "./src/app/form2/form2.page.html":
/*!***************************************!*\
  !*** ./src/app/form2/form2.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n      <ion-title>Achat en ligne</ion-title>\n    </ion-toolbar>\n<ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n        <ion-back-button text=\"Retour\" defaultHref=\"/tabs/tabs/forms\"></ion-back-button>\n      </ion-buttons>\n  <ion-title>Achat en ligne</ion-title>\n</ion-toolbar>\n</ion-header>\n\n<ion-content padding>   <!--onload='testload()'> -->\n\n<div class=\"encadre\">\n  <ion-item (click)=\"setColor('#Iprenom2')\">\n    <ion-label position=\"floating\">Prénom :</ion-label>\n    <ion-input id=\"Iprenom2\" required clearInput [(ngModel)]=\"Prenom2\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n  <!-- <ion-item>\n    <ion-label>lol :</ion-label>\n    <ion-input [(ngModel)]=\"dataToAdd\"></ion-input>\n  </ion-item>\n  <ion-button (click)=\"addData()\">Add data</ion-button> -->\n  \n  <ion-item (click)=\"setColor('#Inom2')\">\n      <ion-label position=\"floating\">Nom :</ion-label>\n      <ion-input id=\"Inom2\" required clearInput [(ngModel)]=\"Nom2\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n\n  <ion-item (click)=\"setColor('#Itelephone2')\">\n    <ion-label position=\"floating\">Téléphone :</ion-label>\n    <ion-input id=\"Itelephone2\" required clearInput [(ngModel)]=\"Telephone2\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n</div>\n<div class=\"encadre\">\n<ion-item>\n  <ion-label>Collez les liens des objets que vous désirez acheter :</ion-label>\n</ion-item>\n<ion-item class=\"txtliens\" (click)=\"setColor('#Iliens2')\">\n  <ion-textarea id=\"Iliens2\" required [(ngModel)]=\"Liens2\" margin=\"1vh\"></ion-textarea>\n</ion-item>\n\n<ion-item *ngIf=\"!alive\" (click)=\"setColor('#Iad_rue2')\">\n  <ion-label position=\"floating\">Livrer à l'adresse :</ion-label>\n  <ion-input id=\"Iad_rue2\" required clearInput [(ngModel)]=\"Ad_rue2\" class=\"inputer centered\"></ion-input>\n</ion-item>\n<ion-item *ngIf=\"!alive\" class=\"rd_postal\" (click)=\"setColor('#Iad_postal')\">\n    <ion-label position=\"floating\">Code postal :</ion-label>\n    <ion-input id=\"Iad_postal2\" required clearInput [(ngModel)]=\"Ad_postal2\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n  <ion-item *ngIf=\"!alive\" class=\"rd_postal\" (click)=\"setColor('#Iad_pays2')\">\n    <ion-label position=\"floating\">Pays :</ion-label>\n    <ion-input id=\"Iad_pays2\" required clearInput [(ngModel)]=\"Ad_pays2\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n</div>\n\n\n\n  \n  <br>\n  <ion-button (click)=\"checkAg2()\">\n    Enregistrer\n  </ion-button>\n</ion-content>\n\n"

/***/ }),

/***/ "./src/app/form2/form2.page.scss":
/*!***************************************!*\
  !*** ./src/app/form2/form2.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ion-input {\n  border-bottom: 1px solid darkgrey; }\n\n:host .hiden {\n  display: none; }\n\n:host .ddl {\n  min-width: 100vh !important; }\n\n:host .rd_nbr {\n  display: inline-block;\n  width: 30%; }\n\n:host .rd_name {\n  display: inline-block;\n  width: 70%; }\n\n:host .rd_postal {\n  display: inline-block;\n  width: 50%; }\n\n:host .txtliens {\n  border: 1px solid grey; }\n\n:host .encadre {\n  border: 2px solid #343582;\n  border-radius: 1em;\n  padding: 1%;\n  margin-bottom: 2%; }\n\n:host .inputer {\n  color: #525865;\n  border-radius: 4px;\n  border: 1px solid #d1d1d1;\n  box-shadow: inset 1px 2px 8px rgba(0, 0, 0, 0.07);\n  font-family: inherit;\n  font-size: 1em;\n  line-height: 1.45;\n  outline: none;\n  padding: 0.6em 1.45em 0.7em;\n  transition: .18s ease-out; }\n\n:host .inputer:hover {\n  box-shadow: inset 1px 2px 8px rgba(0, 0, 0, 0.02); }\n\n:host .inputer:focus {\n  color: #4b515d;\n  border: 1px solid #B8B6B6;\n  box-shadow: inset 1px 2px 4px rgba(0, 0, 0, 0.01), 0px 0px 8px rgba(0, 0, 0, 0.2); }\n\n:host .item-interactive, :host .item-lines-full {\n  --border-width: 0 0 0px 0;\n  --show-full-highlight: 1;\n  --show-inset-highlight: 0; }\n\n:host .item-interactive.ion-touched.ion-invalid, :host .item-interactive.item-has-focus {\n  --full-highlight-height:0px;\n  --inset-highlight-height:0px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9ybTIvQzpcXFVzZXJzXFxJcmlzIEdlcmFsZG9cXERvY3VtZW50c1xcT3V0YWxtYWZpblxcT3V0YWxtYS9zcmNcXGFwcFxcZm9ybTJcXGZvcm0yLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVRLGlDQUFrQyxFQUFBOztBQUYxQztFQU1RLGFBQWEsRUFBQTs7QUFOckI7RUFVUSwyQkFBMEIsRUFBQTs7QUFWbEM7RUFjUSxxQkFBcUI7RUFDckIsVUFBUyxFQUFBOztBQWZqQjtFQWtCUSxxQkFBcUI7RUFDckIsVUFBVSxFQUFBOztBQW5CbEI7RUFzQlEscUJBQXFCO0VBQ3JCLFVBQVUsRUFBQTs7QUF2QmxCO0VBMEJRLHNCQUF1QixFQUFBOztBQTFCL0I7RUE2QlEseUJBQXlCO0VBQ3pCLGtCQUFrQjtFQUNsQixXQUFVO0VBQ1YsaUJBQWlCLEVBQUE7O0FBaEN6QjtFQW9DUSxjQUFjO0VBQ2Qsa0JBQWtCO0VBQ2xCLHlCQUF5QjtFQUN6QixpREFBaUQ7RUFDakQsb0JBQW9CO0VBQ3BCLGNBQWM7RUFDZCxpQkFBaUI7RUFDakIsYUFBYTtFQUNiLDJCQUEyQjtFQUkzQix5QkFBeUIsRUFBQTs7QUFoRGpDO0VBbURNLGlEQUFpRCxFQUFBOztBQW5EdkQ7RUFzRE0sY0FBYztFQUNkLHlCQUF5QjtFQUN6QixpRkFBaUYsRUFBQTs7QUF4RHZGO0VBNERRLHlCQUFlO0VBQ2Ysd0JBQXNCO0VBQ3RCLHlCQUF1QixFQUFBOztBQTlEL0I7RUFpRVEsMkJBQXdCO0VBQ3hCLDRCQUF5QixFQUFBIiwiZmlsZSI6InNyYy9hcHAvZm9ybTIvZm9ybTIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiOmhvc3R7XHJcbiAgICBpb24taW5wdXQge1xyXG4gICAgICAgIGJvcmRlci1ib3R0b20gOiAxcHggc29saWQgZGFya2dyZXk7XHJcbiAgICB9XHJcblxyXG4gICAgLmhpZGVuIHtcclxuICAgICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgICB9XHJcblxyXG4gICAgLmRkbHtcclxuICAgICAgICBtaW4td2lkdGg6MTAwdmggIWltcG9ydGFudDtcclxuICAgIH1cclxuXHJcbiAgICAucmRfbmJye1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICB3aWR0aDozMCU7XHJcbiAgICB9XHJcbiAgICAucmRfbmFtZXtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgd2lkdGg6IDcwJTtcclxuICAgIH1cclxuICAgIC5yZF9wb3N0YWx7XHJcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgIHdpZHRoOiA1MCU7XHJcbiAgICB9XHJcbiAgICAudHh0bGllbnN7XHJcbiAgICAgICAgYm9yZGVyIDogMXB4IHNvbGlkIGdyZXk7XHJcbiAgICB9XHJcbiAgICAuZW5jYWRyZXtcclxuICAgICAgICBib3JkZXI6IDJweCBzb2xpZCAjMzQzNTgyO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDFlbTtcclxuICAgICAgICBwYWRkaW5nOjElO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDIlO1xyXG4gICAgfVxyXG4gICAgLmlucHV0ZXJ7XHJcbiAgICAgICAgLy8gYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICBjb2xvcjogIzUyNTg2NTtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2QxZDFkMTtcclxuICAgICAgICBib3gtc2hhZG93OiBpbnNldCAxcHggMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMDcpO1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBpbmhlcml0O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMWVtO1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxLjQ1O1xyXG4gICAgICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICAgICAgcGFkZGluZzogMC42ZW0gMS40NWVtIDAuN2VtO1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNpdGlvbjogLjE4cyBlYXNlLW91dDtcclxuICAgICAgICAtbW96LXRyYW5zaXRpb246IC4xOHMgZWFzZS1vdXQ7XHJcbiAgICAgICAgLW8tdHJhbnNpdGlvbjogLjE4cyBlYXNlLW91dDtcclxuICAgICAgICB0cmFuc2l0aW9uOiAuMThzIGVhc2Utb3V0O1xyXG4gICAgfVxyXG4gICAgLmlucHV0ZXI6aG92ZXIge1xyXG4gICAgICBib3gtc2hhZG93OiBpbnNldCAxcHggMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMDIpO1xyXG4gICAgfVxyXG4gICAgLmlucHV0ZXI6Zm9jdXMge1xyXG4gICAgICBjb2xvcjogIzRiNTE1ZDtcclxuICAgICAgYm9yZGVyOiAxcHggc29saWQgI0I4QjZCNjtcclxuICAgICAgYm94LXNoYWRvdzogaW5zZXQgMXB4IDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjAxKSwgMHB4IDBweCA4cHggcmdiYSgwLCAwLCAwLCAwLjIpO1xyXG4gICAgfVxyXG5cclxuICAgIC5pdGVtLWludGVyYWN0aXZlLCAuaXRlbS1saW5lcy1mdWxsIHtcclxuICAgICAgICAtLWJvcmRlci13aWR0aDogMCAwIDBweCAwO1xyXG4gICAgICAgIC0tc2hvdy1mdWxsLWhpZ2hsaWdodDogMTtcclxuICAgICAgICAtLXNob3ctaW5zZXQtaGlnaGxpZ2h0OiAwO1xyXG4gICAgfVxyXG4gICAgLml0ZW0taW50ZXJhY3RpdmUuaW9uLXRvdWNoZWQuaW9uLWludmFsaWQsIC5pdGVtLWludGVyYWN0aXZlLml0ZW0taGFzLWZvY3VzIHtcclxuICAgICAgICAtLWZ1bGwtaGlnaGxpZ2h0LWhlaWdodDowcHg7XHJcbiAgICAgICAgLS1pbnNldC1oaWdobGlnaHQtaGVpZ2h0OjBweDtcclxuICAgIH0gXHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/form2/form2.page.ts":
/*!*************************************!*\
  !*** ./src/app/form2/form2.page.ts ***!
  \*************************************/
/*! exports provided: Form2Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Form2Page", function() { return Form2Page; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_3__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var Form2Page = /** @class */ (function () {
    function Form2Page(toastCtrl) {
        this.toastCtrl = toastCtrl;
        this.VigiK = "";
        this.TabDemandes = [];
        this.TabUser2 = [];
        this.TabFields = [
            {
                Ad_pay_l: '',
                Ad_rue_l: '',
                Ad_pos_l: '',
                Ad_pay_e: '',
                Ad_rue_e: '',
                Ad_pos_e: '',
                Nom: '',
                Atype: 'Demande',
                Date_crea: '',
                Date_livraison: '',
                Desc_colis: '',
                Etat: 'En attente',
                Liste_envies: '',
                Num_colis: '',
                Num_com: '',
                Prenom: '',
                Site_prov: '',
                Type_demande: '2',
                Type_envoi: '',
                Telephone: '',
                i: '123456',
                icon: 'paper',
                id: '123456',
                Priorite: 'gris',
                UID: '',
            }
        ];
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        var InTabDemandes = [];
        //firebase.database().ref('/user/QLz2y3HDBKd9tGZkQ44K505dFN93').on("value", function(snapshot) {
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/user/' + firebase__WEBPACK_IMPORTED_MODULE_1__["auth"]().currentUser.uid).on("value", function (snapshot) {
            // firebase.database().ref('/form').on("value", function(snapshot) {
            var tg = snapshot.val();
            tg.forEach(function (entry) {
                console.log("ent :" + entry.displayName);
                InTabDemandes.push(entry);
            });
        }, function (error) {
            console.log("Error dans VoirDonnees: " + error.code);
        });
        this.TabDemandes = InTabDemandes;
        console.log("voir tabDD ", this.TabDemandes);
        //this.Nom2 = this.TabDemandes[0]['displayName'];
        this.Telephone2 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['phoneNumber'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Nom2 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Nom'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Prenom2 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Prenom'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_rue2 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Ad_rue_l'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_postal2 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Ad_pos_l'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_pays2 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Ad_pay_l'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        var InTabUser2 = [];
        this.TabUser2 = InTabUser2;
    }
    Form2Page.prototype.ngOnInit = function () {
    };
    Form2Page.prototype.checkAg2 = function () {
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        var utc = new Date().toJSON().slice(0, 10).replace(/-/g, '-');
        // this.Nom2 = this.TabDemandes[0]['displayName'];
        // this.Telephone2 = this.TabDemandes[0]['phoneNumber'];
        var elmpre2 = document.querySelector("#Iprenom2");
        var elmnom2 = document.querySelector("#Inom2");
        var elmtel2 = document.querySelector("#Itelephone2");
        var elmlie2 = document.querySelector("#Iliens2");
        var elmrue2 = document.querySelector("#Iad_rue2");
        var elmpos2 = document.querySelector("#Iad_postal2");
        var elmpay2 = document.querySelector("#Iad_pays2");
        this.TabFields[0]['UID'] = firebase__WEBPACK_IMPORTED_MODULE_1__["auth"]().currentUser.uid;
        this.TabFields[0]['Date_crea'] = utc;
        if (!this.Prenom2 || this.Prenom2.length < 1) {
            elmpre2.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Prenom'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Prenom2.trim(), VigiK.trim()).toString();
            elmpre2.style.borderColor = 'green';
        }
        if (!this.Nom2 || this.Nom2.length < 1) {
            elmnom2.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Nom'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Nom2.trim(), VigiK.trim()).toString();
            elmnom2.style.borderColor = 'green';
        }
        if (!this.Telephone2 || this.Telephone2.length < 10) {
            elmtel2.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Telephone'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Telephone2.trim(), VigiK.trim()).toString();
            elmtel2.style.borderColor = 'green';
        }
        if (!this.Liens2 || this.Liens2.length < 2) {
            elmlie2.style.background = 'rgba(255,0,0,0.2)';
            return;
        }
        else {
            this.TabFields[0]['Liste_envies'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Liens2.trim(), VigiK.trim()).toString();
            elmlie2.style.background = 'white';
        }
        if (!this.Ad_rue2 || this.Ad_rue2.length < 3) {
            elmrue2.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_rue_l'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_rue2.trim(), VigiK.trim()).toString();
            elmrue2.style.borderColor = 'green';
        }
        if (!this.Ad_postal2 || this.Ad_postal2.length < 3) {
            elmpos2.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_postal_l'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_postal2.trim(), VigiK.trim()).toString();
            elmpos2.style.borderColor = 'green';
        }
        if (!this.Ad_pays2 || this.Ad_pays2.length < 2) {
            elmpay2.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_pay_l'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_pays2.trim(), VigiK.trim()).toString();
            elmpay2.style.borderColor = 'green';
        }
        this.writeUserData();
        this.presentToastBravo();
    };
    Form2Page.prototype.presentToastBravo = function () {
        return __awaiter(this, void 0, void 0, function () {
            var tooast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Votre demande a bien été enregistrée.',
                            duration: 3000,
                            position: 'middle',
                            color: 'success'
                        })];
                    case 1:
                        tooast = _a.sent();
                        tooast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    Form2Page.prototype.writeUserData = function () {
        var _this = this;
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        var lena = 0;
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/suivi_details').on("value", function (snapshot) {
            var tg = snapshot.val();
            lena = tg.length;
        }, function (error) {
            console.log("Error dans VoirDonnees: " + error.code);
        });
        this.TabFields[0]['i'] = lena.toString();
        this.TabFields[0]['id'] = lena.toString();
        console.log("TABFIELD" + this.TabFields[0]['i']);
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('suivi_details/' + lena).set(this.TabFields[0]).then(function (data) {
            // console.log('data :',data);
            console.log("voir donn", _this.TabUser2);
        }, function (error) {
            console.log(error, _this.TabUser2);
        });
        var utc = new Date().toJSON().slice(0, 10).replace(/-/g, '/');
        var TabFirstMsg = [];
        TabFirstMsg.push({ DateMsg: utc, Message: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt('Votre demande est en cours de traitement'.trim(), VigiK.trim()).toString(), Notification: 1, UserID: 'Compute' });
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/msg_suivi/' + (lena - 1)).set(TabFirstMsg).then(function (data) {
        }, function (error) {
            console.log(error, TabFirstMsg);
        });
    };
    Form2Page.prototype.setColor = function (idlbl) {
        var id4elem = document.querySelector(idlbl);
        if (idlbl == "#Iliens2")
            id4elem.style.backgroundColor = "";
        else
            id4elem.style.borderColor = '#FFFFFF';
    };
    Form2Page = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-form2',
            template: __webpack_require__(/*! ./form2.page.html */ "./src/app/form2/form2.page.html"),
            styles: [__webpack_require__(/*! ./form2.page.scss */ "./src/app/form2/form2.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
    ], Form2Page);
    return Form2Page;
}());



/***/ })

}]);
//# sourceMappingURL=form2-form2-module.js.map