(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["form1-form1-module"],{

/***/ "./src/app/form1/form1.module.ts":
/*!***************************************!*\
  !*** ./src/app/form1/form1.module.ts ***!
  \***************************************/
/*! exports provided: Form1PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Form1PageModule", function() { return Form1PageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _form1_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./form1.page */ "./src/app/form1/form1.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _form1_page__WEBPACK_IMPORTED_MODULE_5__["Form1Page"]
    }
];
var Form1PageModule = /** @class */ (function () {
    function Form1PageModule() {
    }
    Form1PageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_form1_page__WEBPACK_IMPORTED_MODULE_5__["Form1Page"]]
        })
    ], Form1PageModule);
    return Form1PageModule;
}());



/***/ }),

/***/ "./src/app/form1/form1.page.html":
/*!***************************************!*\
  !*** ./src/app/form1/form1.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-title>Réexpédition</ion-title>\n      </ion-toolbar>\n  <ion-toolbar color=\"primary\">\n      <ion-buttons slot=\"start\">\n          <ion-back-button text=\"Retour\" defaultHref=\"/tabs/tabs/forms\"></ion-back-button>\n        </ion-buttons>\n    <ion-title>Réexpédition</ion-title>\n  </ion-toolbar>\n  <script>\n  </script>\n</ion-header>\n\n<ion-content padding>\n\n<div class=\"encadre\">\n  <ion-item (click)=\"setColor('#Iprenom')\" style=\"background-color:red !important;\">\n    <ion-label position=\"floating\">Prénom :</ion-label>\n    <ion-input id=\"Iprenom\" clearInput [(ngModel)]=\"Prenom\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n  <ion-item (click)=\"setColor('#Inom')\">\n      <ion-label position=\"floating\">Nom :</ion-label>\n      <ion-input id=\"Inom\" clearInput [(ngModel)]=\"Nom\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n\n  <ion-item (click)=\"setColor('#Itelephone')\">\n    <ion-label position=\"floating\">Téléphone :</ion-label>\n    <ion-input id=\"Itelephone\" clearInput [(ngModel)]=\"Telephone\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n</div>\n<div class=\"encadre\">\n  <ion-item class=\"rd_postal\" (click)=\"setColor('#Inum_colis')\">\n      <ion-label position=\"floating\">Numéro de colis :</ion-label>\n      <ion-input id=\"Inum_colis\" clearInput [(ngModel)]=\"Num_colis\" class=\"inputer centered\"></ion-input>\n    </ion-item>  \n    <ion-item class=\"rd_postal\" (click)=\"setColor('#Inum_com')\">\n      <ion-label position=\"floating\">Numéro de commande :</ion-label>\n      <ion-input  id=\"Inum_com\" clearInput [(ngModel)]=\"Num_commande\" class=\"inputer centered\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label >Description du colis :</ion-label>\n    </ion-item>\n    <ion-item class=\"txtliens\" (click)=\"setColor('#Idesc_colis')\">\n      <ion-textarea id=\"Idesc_colis\" [(ngModel)]=\"Desc_colis\" margin=\"1vh\" placeholder=\"Veuillez entrer les informations de poids, de volume, et le type d'articles à envoyer afin d'établir un devis.\"></ion-textarea>\n    </ion-item>\n    <ion-item  (click)=\"setColor('#Iad_website')\">\n      <ion-label position=\"floating\">Site de provenance de la commande :</ion-label>\n      <ion-input id=\"Iad_website\" clearInput [(ngModel)]=\"Ad_website\" class=\"inputer centered\"></ion-input>\n    </ion-item>\n    \n    <ion-item >\n      <ion-label >Date de livraison en agence :</ion-label>\n    </ion-item>\n    <ion-item (click)=\"setColor('#Idate_liv')\" class=\"rd_postal\">\n      <ion-input id=\"Idate_liv\" [(ngModel)]=\"Date_livraison\"  type=\"date\" clearInput></ion-input>\n      <!-- <ion-datetime id=\"Idate_liv\" [(ngModel)]=\"Date_livraison\" display-format=\"DD/MM/YYYY\" picker-format=\"D MMMM YYYY\" cancelText=\"\" doneText=\"Ok\"></ion-datetime> -->\n    </ion-item>\n  </div>\n  <div class=\"encadre\">\n    <ion-item name=\"sendtype\" (click)=\"setColor('#Itype_envoi')\">\n      <ion-label position=\"floating\" class=\"rd_nbr\">Type d'envoi :</ion-label>\n      <ion-select  id=\"Itype_envoi\" interface=\"popover\" [(ngModel)]=\"Type_envoi\" value=\"Avion\" placeholder=\"\" class=\"ddl rd_name\" min-width=\"100vh\"  okText=\"Ok\" cancelText=\"Annuler\">\n         <ion-select-option class=\"ddl\" value=\"Bateau\">Envoi par bateau</ion-select-option>\n         <ion-select-option class=\"ddl\" value=\"Avion\">Envoi par avion</ion-select-option>\n     </ion-select>\n    </ion-item>\n    \n  <ion-item *ngIf=\"!alive\" class=\"\" (click)=\"setColor('#Iad_rue')\">\n    <ion-label position=\"floating\">Livrer à l'adresse :</ion-label>\n    <ion-input  id=\"Iad_rue\" clearInput [(ngModel)]=\"Ad_rue\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n  <ion-item *ngIf=\"!alive\" class=\"rd_postal\" (click)=\"setColor('#Iad_postal')\">\n      <ion-label position=\"floating\">Code postal :</ion-label>\n      <ion-input id=\"Iad_postal\" clearInput [(ngModel)]=\"Ad_postal\" class=\"inputer centered\"></ion-input>\n    </ion-item>\n    <ion-item *ngIf=\"!alive\" class=\"rd_postal\" (click)=\"setColor('#Iad_pays')\">\n      <ion-label position=\"floating\">Pays :</ion-label>\n      <ion-input id=\"Iad_pays\" clearInput [(ngModel)]=\"Ad_pays\" class=\"inputer centered\"></ion-input>\n    </ion-item>\n    </div>\n\n    <br>\n    <!-- OBLIGATOIRE (descritpion du colis, adresse renseignée sur le site, site de provenance, type d'envoi (par avion/ bateau), adresse de livraison finale)\n    FACULTATIF (numéro de colis, numéro de commande, date de livraison estimée) -->  \n    <ion-button (click)=\"checkAg()\">\n      Enregistrer\n    </ion-button>\n</ion-content>\n\n"

/***/ }),

/***/ "./src/app/form1/form1.page.scss":
/*!***************************************!*\
  !*** ./src/app/form1/form1.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ion-input {\n  border-bottom: 1px solid darkgrey; }\n\n:host .hiden {\n  display: none; }\n\n:host .ddl {\n  min-width: 100vh !important; }\n\n:host .rd_nbr {\n  display: inline-block;\n  width: 30%; }\n\n:host .rd_name {\n  display: inline-block;\n  width: 70%; }\n\n:host .rd_postal {\n  display: inline-block;\n  width: 50%; }\n\n:host .rd_date {\n  display: inline-block;\n  width: 30%; }\n\n:host .encadre {\n  border: 2px solid #343582;\n  border-radius: 1em;\n  padding: 1%;\n  margin-bottom: 2%; }\n\n:host .inputer {\n  color: #525865;\n  border-radius: 4px;\n  border: 1px solid #d1d1d1;\n  box-shadow: inset 1px 2px 8px rgba(0, 0, 0, 0.07);\n  font-family: inherit;\n  font-size: 1em;\n  line-height: 1.45;\n  outline: none;\n  padding: 0.6em 1.45em 0.7em;\n  transition: .18s ease-out; }\n\n:host .inputer:hover {\n  box-shadow: inset 1px 2px 8px rgba(0, 0, 0, 0.02); }\n\n:host .inputer:focus {\n  color: #4b515d;\n  border: 1px solid #B8B6B6;\n  box-shadow: inset 1px 2px 4px rgba(0, 0, 0, 0.01), 0px 0px 8px rgba(0, 0, 0, 0.2); }\n\n:host .item-interactive, :host .item-lines-full {\n  --border-width: 0 0 0px 0;\n  --show-full-highlight: 1;\n  --show-inset-highlight: 0; }\n\n:host .item-interactive.ion-touched.ion-invalid, :host .item-interactive.item-has-focus {\n  --full-highlight-height:0px;\n  --inset-highlight-height:0px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9ybTEvQzpcXFVzZXJzXFxJcmlzIEdlcmFsZG9cXERvY3VtZW50c1xcT3V0YWxtYWZpblxcT3V0YWxtYS9zcmNcXGFwcFxcZm9ybTFcXGZvcm0xLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVRLGlDQUFrQyxFQUFBOztBQUYxQztFQU1RLGFBQWEsRUFBQTs7QUFOckI7RUFVUSwyQkFBMEIsRUFBQTs7QUFWbEM7RUFjUSxxQkFBcUI7RUFDckIsVUFBUyxFQUFBOztBQWZqQjtFQWtCUSxxQkFBcUI7RUFDckIsVUFBVSxFQUFBOztBQW5CbEI7RUFzQlEscUJBQXFCO0VBQ3JCLFVBQVUsRUFBQTs7QUF2QmxCO0VBMEJRLHFCQUFxQjtFQUNyQixVQUFVLEVBQUE7O0FBM0JsQjtFQThCUSx5QkFBeUI7RUFDekIsa0JBQWtCO0VBQ2xCLFdBQVU7RUFDVixpQkFBaUIsRUFBQTs7QUFqQ3pCO0VBcUNRLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIseUJBQXlCO0VBQ3pCLGlEQUFpRDtFQUNqRCxvQkFBb0I7RUFDcEIsY0FBYztFQUNkLGlCQUFpQjtFQUNqQixhQUFhO0VBQ2IsMkJBQTJCO0VBSTNCLHlCQUF5QixFQUFBOztBQWpEakM7RUFvRE0saURBQWlELEVBQUE7O0FBcER2RDtFQXVETSxjQUFjO0VBQ2QseUJBQXlCO0VBQ3pCLGlGQUFpRixFQUFBOztBQXpEdkY7RUE2RFEseUJBQWU7RUFDZix3QkFBc0I7RUFDdEIseUJBQXVCLEVBQUE7O0FBL0QvQjtFQWtFUSwyQkFBd0I7RUFDeEIsNEJBQXlCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9mb3JtMS9mb3JtMS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdHtcclxuICAgIGlvbi1pbnB1dCB7XHJcbiAgICAgICAgYm9yZGVyLWJvdHRvbSA6IDFweCBzb2xpZCBkYXJrZ3JleTtcclxuICAgIH1cclxuXHJcbiAgICAuaGlkZW4ge1xyXG4gICAgICAgIGRpc3BsYXk6IG5vbmU7XHJcbiAgICAgIH1cclxuXHJcbiAgICAuZGRse1xyXG4gICAgICAgIG1pbi13aWR0aDoxMDB2aCAhaW1wb3J0YW50O1xyXG4gICAgfVxyXG5cclxuICAgIC5yZF9uYnJ7XHJcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgIHdpZHRoOjMwJTtcclxuICAgIH1cclxuICAgIC5yZF9uYW1le1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICB3aWR0aDogNzAlO1xyXG4gICAgfVxyXG4gICAgLnJkX3Bvc3RhbHtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgd2lkdGg6IDUwJTtcclxuICAgIH1cclxuICAgIC5yZF9kYXRle1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICB3aWR0aDogMzAlO1xyXG4gICAgfVxyXG4gICAgLmVuY2FkcmV7XHJcbiAgICAgICAgYm9yZGVyOiAycHggc29saWQgIzM0MzU4MjtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxZW07XHJcbiAgICAgICAgcGFkZGluZzoxJTtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAyJTtcclxuICAgIH1cclxuICAgIC5pbnB1dGVye1xyXG4gICAgICAgIC8vIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgICAgY29sb3I6ICM1MjU4NjU7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNkMWQxZDE7XHJcbiAgICAgICAgYm94LXNoYWRvdzogaW5zZXQgMXB4IDJweCA4cHggcmdiYSgwLCAwLCAwLCAwLjA3KTtcclxuICAgICAgICBmb250LWZhbWlseTogaW5oZXJpdDtcclxuICAgICAgICBmb250LXNpemU6IDFlbTtcclxuICAgICAgICBsaW5lLWhlaWdodDogMS40NTtcclxuICAgICAgICBvdXRsaW5lOiBub25lO1xyXG4gICAgICAgIHBhZGRpbmc6IDAuNmVtIDEuNDVlbSAwLjdlbTtcclxuICAgICAgICAtd2Via2l0LXRyYW5zaXRpb246IC4xOHMgZWFzZS1vdXQ7XHJcbiAgICAgICAgLW1vei10cmFuc2l0aW9uOiAuMThzIGVhc2Utb3V0O1xyXG4gICAgICAgIC1vLXRyYW5zaXRpb246IC4xOHMgZWFzZS1vdXQ7XHJcbiAgICAgICAgdHJhbnNpdGlvbjogLjE4cyBlYXNlLW91dDtcclxuICAgIH1cclxuICAgIC5pbnB1dGVyOmhvdmVyIHtcclxuICAgICAgYm94LXNoYWRvdzogaW5zZXQgMXB4IDJweCA4cHggcmdiYSgwLCAwLCAwLCAwLjAyKTtcclxuICAgIH1cclxuICAgIC5pbnB1dGVyOmZvY3VzIHtcclxuICAgICAgY29sb3I6ICM0YjUxNWQ7XHJcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNCOEI2QjY7XHJcbiAgICAgIGJveC1zaGFkb3c6IGluc2V0IDFweCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4wMSksIDBweCAwcHggOHB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuICAgIH1cclxuXHJcbiAgICAuaXRlbS1pbnRlcmFjdGl2ZSwgLml0ZW0tbGluZXMtZnVsbCB7XHJcbiAgICAgICAgLS1ib3JkZXItd2lkdGg6IDAgMCAwcHggMDtcclxuICAgICAgICAtLXNob3ctZnVsbC1oaWdobGlnaHQ6IDE7XHJcbiAgICAgICAgLS1zaG93LWluc2V0LWhpZ2hsaWdodDogMDtcclxuICAgIH1cclxuICAgIC5pdGVtLWludGVyYWN0aXZlLmlvbi10b3VjaGVkLmlvbi1pbnZhbGlkLCAuaXRlbS1pbnRlcmFjdGl2ZS5pdGVtLWhhcy1mb2N1cyB7XHJcbiAgICAgICAgLS1mdWxsLWhpZ2hsaWdodC1oZWlnaHQ6MHB4O1xyXG4gICAgICAgIC0taW5zZXQtaGlnaGxpZ2h0LWhlaWdodDowcHg7XHJcbiAgICB9XHJcbiAgICBcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/form1/form1.page.ts":
/*!*************************************!*\
  !*** ./src/app/form1/form1.page.ts ***!
  \*************************************/
/*! exports provided: Form1Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Form1Page", function() { return Form1Page; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_3__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var Form1Page = /** @class */ (function () {
    function Form1Page(modalCtrl, toastCtrl) {
        this.modalCtrl = modalCtrl;
        this.toastCtrl = toastCtrl;
        this.VigiK = "";
        this.Emp = 0;
        this.Lena = 0;
        this.title = 'form1';
        this.TabDemandes = [];
        this.TabUser2 = [];
        this.TabFields = [
            {
                Ad_pay_l: '',
                Ad_rue_l: '',
                Ad_pos_l: '',
                Ad_pay_e: '',
                Ad_rue_e: '',
                Ad_pos_e: '',
                Nom: '',
                Atype: 'Demande',
                Date_crea: '',
                Date_livraison: '',
                Desc_colis: '',
                Etat: 'En attente',
                Liste_envies: '',
                Num_colis: '',
                Num_com: '',
                Prenom: '',
                Site_prov: '',
                Type_demande: '1',
                Type_envoi: '',
                Telephone: '',
                i: '123456',
                icon: 'paper',
                id: '123456',
                Priorite: 'gris',
                UID: '',
            }
        ];
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        console.log("I was called1");
        var InTabDemandes = [];
        //firebase.database().ref('/user/QLz2y3HDBKd9tGZkQ44K505dFN93').on("value", function(snapshot) {
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/user/' + firebase__WEBPACK_IMPORTED_MODULE_1__["auth"]().currentUser.uid).on("value", function (snapshot) {
            // firebase.database().ref('/form').on("value", function(snapshot) {
            var tg = snapshot.val();
            tg.forEach(function (entry) {
                console.log("ent :" + entry.displayName);
                InTabDemandes.push(entry);
            });
        }, function (error) {
            console.log("Error dans VoirDonnees: " + error.code);
        });
        this.TabDemandes = InTabDemandes;
        console.log("voir tabDD ", this.TabDemandes);
        //this.Nom2 = this.TabDemandes[0]['displayName'];
        var InTabUser2 = [];
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/user/' + firebase__WEBPACK_IMPORTED_MODULE_1__["auth"]().currentUser.uid).on("value", function (snapshot) {
            // firebase.database().ref('/forms').on("value", function(snapshot) {
            var tg = snapshot.val();
            tg.forEach(function (entry) {
                InTabUser2.push(entry);
            });
        }, function (error) {
            console.log("Error dans VoirDonnees: " + error.code);
        });
        this.TabUser2 = InTabUser2;
        console.log("voir tabDD ", this.TabUser2);
        console.log("voir tab YE ", this.TabUser2[0]['Ad_rue_e']);
        //console.log("voir tab Nom ", this.TabUser2[0]['Anom']);
        console.log("voir tab Prenom ", this.TabUser2[0]['Prenom']);
        console.log("voir tab Prenom ", this.TabUser2[0]['phoneNumber']);
        // this.Nom = this.TabUser2[0]['Nom'];
        // this.Prenom = this.TabUser2[0]['Prenom'];
        // this.Ad_rue = this.TabUser2[0]['Ad_rue_l'];
        // this.Ad_postal = this.TabUser2[0]['Ad_pos_l'];
        // this.Ad_pays = this.TabUser2[0]['Ad_pay_l'];
        //  this.Telephone = this.TabDemandes[0]['phoneNumber'];
        this.Nom = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[0]['Nom'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Prenom = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[0]['Prenom'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_rue = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[0]['Ad_rue_l'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_postal = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[0]['Ad_pos_l'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_pays = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[0]['Ad_pay_l'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Telephone = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[0]['phoneNumber'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        //this.Telephone = this.TabUser2[0]['phoneNumber'];
        if ((crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabUser2[0]['email'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8)).includes('outalma.com') == true)
            this.Emp = 1;
    }
    Form1Page.prototype.convertText = function (conversion) {
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        if (conversion == "encrypt") {
            this.conversionEncryptOutput = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.plainText.trim(), VigiK.trim()).toString();
        }
        else {
            this.conversionDecryptOutput = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.encryptText.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        }
    };
    Form1Page.prototype.getURLParameter = function (name) {
        return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search) || [null, ''])[1].replace(/\+/g, '%20')) || null;
    };
    Form1Page.prototype.setColor = function (idlbl) {
        var id4elem = document.querySelector(idlbl);
        if (idlbl == "#Idesc_colis")
            id4elem.style.backgroundColor = "";
        else
            id4elem.style.borderColor = '#FFFFFF';
    };
    Form1Page.prototype.ngOnInit = function () {
        // alert('access');
        //    var c = url.searchParams.get("c");
        // var myvar = this.getURLParameter('a');
        // if (myvar != null)
        //   alert(myvar);
    };
    Form1Page.prototype.checkAg = function () {
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        //this.goToMsg();
        var utc = new Date().toJSON().slice(0, 10).replace(/-/g, '-');
        // firebase.database().ref('/suivi_details/1').on("value", function(snapshot) {
        //     var tg = snapshot.val();
        //       console.log("LENTRY: " + tg[0]);
        //  },
        //   function (error) {
        //     console.log("Error dans VoirDonnees: " + error.code);
        //  }
        //  )
        // window.open("http://localhost:8100/tabs/tabs/form1?a=tgland");
        var elmpre = document.querySelector("#Iprenom");
        var elmnom = document.querySelector("#Inom");
        var elmtel = document.querySelector("#Itelephone");
        var elmdes = document.querySelector("#Idesc_colis");
        var elmweb = document.querySelector("#Iad_website");
        var elmtyp = document.querySelector("#Itype_envoi");
        var elmrue = document.querySelector("#Iad_rue");
        var elmpos = document.querySelector("#Iad_postal");
        var elmpay = document.querySelector("#Iad_pays");
        if (this.Num_colis && this.Num_colis.length > 0)
            this.TabFields[0]['Num_colis'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Num_colis.trim(), VigiK.trim()).toString();
        if (this.Num_commande && this.Num_commande.length > 0)
            this.TabFields[0]['Num_com'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Num_commande.trim(), VigiK.trim()).toString();
        if (this.Desc_colis && this.Desc_colis.length > 0)
            this.TabFields[0]['Desc_colis'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Desc_colis.trim(), VigiK.trim()).toString();
        if (this.Type_envoi && this.Type_envoi.length > 0)
            this.TabFields[0]['Type_envoi'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Type_envoi.trim(), VigiK.trim()).toString();
        else
            this.TabFields[0]['Type_envoi'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt('Avion'.trim(), VigiK.trim()).toString();
        if (this.Date_livraison && this.Date_livraison.length > 0)
            this.TabFields[0]['Date_livraison'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Date_livraison.trim(), VigiK.trim()).toString();
        this.TabFields[0]['Date_crea'] = utc;
        //OBLIGATOIRES :
        if (!this.Prenom || this.Prenom.length < 1) {
            elmpre.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Prenom'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Prenom.trim(), VigiK.trim()).toString();
            elmpre.style.borderColor = 'green';
        }
        if (!this.Nom || this.Nom.length < 1) {
            elmnom.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Nom'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Nom.trim(), VigiK.trim()).toString();
            elmnom.style.borderColor = 'green';
        }
        if (!this.Telephone || this.Telephone.length < 10) {
            elmtel.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Telephone'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Telephone.trim(), VigiK.trim()).toString();
            elmtel.style.borderColor = 'green';
        }
        if (!this.Desc_colis || this.Desc_colis.length < 4) {
            elmdes.style.background = 'rgba(255, 0, 0, 0.2)';
            return;
        }
        else {
            this.TabFields[0]['Desc_colis'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Desc_colis.trim(), VigiK.trim()).toString();
            elmdes.style.background = 'white';
        }
        if (!this.Ad_website || this.Ad_website.length < 4) {
            elmweb.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Site_prov'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_website.trim(), VigiK.trim()).toString();
            elmweb.style.borderColor = 'green';
        }
        if (!this.Ad_rue || this.Ad_rue.length < 2) {
            elmrue.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_rue_l'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_rue.trim(), VigiK.trim()).toString();
            elmrue.style.borderColor = 'green';
        }
        if (!this.Ad_postal || this.Ad_postal.length < 2) {
            elmpos.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_pos_l'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_postal.trim(), VigiK.trim()).toString();
            elmpos.style.borderColor = 'green';
        }
        if (!this.Ad_pays || this.Ad_pays.length < 2) {
            elmpay.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_pay_l'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_pays.trim(), VigiK.trim()).toString();
            elmpay.style.borderColor = 'green';
        }
        this.TabFields[0]['Liste_envies'] = "";
        if (this.Emp == 0) {
            this.TabFields[0]['UID'] = firebase__WEBPACK_IMPORTED_MODULE_1__["auth"]().currentUser.uid;
        }
        // else
        // {
        //   // firebase.database.getInstance().getReference().child("Contact");
        //   // dbRef= cont.child(user.getUid());
        //   // dbRef=cont.child("name").setValue(name);
        //   var InTabUser = [];
        //   firebase.database().ref('/user').on("value", function(snapshot) {
        //       var tg = snapshot.val();
        //       tg.forEach(function(entry) {
        //         InTabUser.push(entry);
        //     });
        //    },
        //     function (error) {
        //       console.log("Error dans VoirDonnees: " + error.code);
        //    }
        //    )
        //    for (var i=0, len=InTabUser.length; i<len; i++) {
        //       console.log(InTabUser[i]['phoneNumber']);
        //    }
        // }
        this.writeUserData();
        this.presentToastBravo();
    };
    Form1Page.prototype.presentToastBravo = function () {
        return __awaiter(this, void 0, void 0, function () {
            var tooast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Votre demande a bien été enregistrée.',
                            duration: 3000,
                            position: 'middle',
                            color: 'success'
                        })];
                    case 1:
                        tooast = _a.sent();
                        tooast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    Form1Page.prototype.writeUserData = function () {
        var _this = this;
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        var lena = 0;
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/suivi_details').on("value", function (snapshot) {
            var tg = snapshot.val();
            lena = tg.length;
        }, function (error) {
            console.log("Error dans VoirDonnees: " + error.code);
        });
        this.TabFields[0]['i'] = lena.toString();
        this.TabFields[0]['id'] = lena.toString();
        console.log("TABFIELD" + this.TabFields[0]['i']);
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('suivi_details/' + lena).set(this.TabFields[0]).then(function (data) {
            console.log("voir donn", _this.TabUser2);
        }, function (error) {
            console.log(error, _this.TabUser2);
        });
        var utc = new Date().toJSON().slice(0, 10).replace(/-/g, '/');
        var TabFirstMsg = [];
        TabFirstMsg.push({ DateMsg: utc, Message: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt('Votre demande est en cours de traitement'.trim(), VigiK.trim()).toString(), Notification: 1, UserID: 'Compute' });
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/msg_suivi/' + (lena - 1)).set(TabFirstMsg).then(function (data) {
        }, function (error) {
            console.log(error, TabFirstMsg);
        });
    };
    Form1Page = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-form1',
            template: __webpack_require__(/*! ./form1.page.html */ "./src/app/form1/form1.page.html"),
            styles: [__webpack_require__(/*! ./form1.page.scss */ "./src/app/form1/form1.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
    ], Form1Page);
    return Form1Page;
}());



/***/ })

}]);
//# sourceMappingURL=form1-form1-module.js.map