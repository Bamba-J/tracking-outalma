(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$":
/*!*********************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/es5/build lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ namespace object ***!
  \*********************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./0owmtgfs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0owmtgfs.entry.js",
		"common",
		58
	],
	"./0owmtgfs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0owmtgfs.sc.entry.js",
		"common",
		59
	],
	"./0utrggve.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0utrggve.entry.js",
		"common",
		60
	],
	"./0utrggve.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/0utrggve.sc.entry.js",
		"common",
		61
	],
	"./3hf0d5sl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hf0d5sl.entry.js",
		"common",
		62
	],
	"./3hf0d5sl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/3hf0d5sl.sc.entry.js",
		"common",
		63
	],
	"./47ctf96j.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/47ctf96j.entry.js",
		0,
		"common",
		132
	],
	"./47ctf96j.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/47ctf96j.sc.entry.js",
		0,
		"common",
		133
	],
	"./4jebvdzz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4jebvdzz.entry.js",
		"common",
		10
	],
	"./4jebvdzz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4jebvdzz.sc.entry.js",
		"common",
		11
	],
	"./4m739wpj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4m739wpj.entry.js",
		"common",
		64
	],
	"./4m739wpj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4m739wpj.sc.entry.js",
		"common",
		65
	],
	"./4ovfvgj2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4ovfvgj2.entry.js",
		0,
		"common",
		134
	],
	"./4ovfvgj2.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4ovfvgj2.sc.entry.js",
		0,
		"common",
		135
	],
	"./4tejeecb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4tejeecb.entry.js",
		"common",
		66
	],
	"./4tejeecb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/4tejeecb.sc.entry.js",
		"common",
		67
	],
	"./5ccusvgf.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ccusvgf.entry.js",
		"common",
		68
	],
	"./5ccusvgf.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ccusvgf.sc.entry.js",
		"common",
		69
	],
	"./5ey3bs99.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ey3bs99.entry.js",
		"common",
		12
	],
	"./5ey3bs99.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/5ey3bs99.sc.entry.js",
		"common",
		13
	],
	"./6f4biktp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6f4biktp.entry.js",
		"common",
		70
	],
	"./6f4biktp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/6f4biktp.sc.entry.js",
		"common",
		71
	],
	"./8ldpeqpe.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8ldpeqpe.entry.js",
		"common",
		14
	],
	"./8ldpeqpe.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8ldpeqpe.sc.entry.js",
		"common",
		15
	],
	"./8q1e6dus.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8q1e6dus.entry.js",
		"common",
		16
	],
	"./8q1e6dus.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/8q1e6dus.sc.entry.js",
		"common",
		17
	],
	"./96olk0dp.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/96olk0dp.entry.js",
		136
	],
	"./96olk0dp.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/96olk0dp.sc.entry.js",
		137
	],
	"./9rhd7ueu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9rhd7ueu.entry.js",
		0,
		"common",
		138
	],
	"./9rhd7ueu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9rhd7ueu.sc.entry.js",
		0,
		"common",
		139
	],
	"./9ynbzp83.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9ynbzp83.entry.js",
		"common",
		18
	],
	"./9ynbzp83.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/9ynbzp83.sc.entry.js",
		"common",
		19
	],
	"./afjpklm4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/afjpklm4.entry.js",
		"common",
		72
	],
	"./afjpklm4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/afjpklm4.sc.entry.js",
		"common",
		73
	],
	"./bhtvuxzz.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bhtvuxzz.entry.js",
		0,
		"common",
		140
	],
	"./bhtvuxzz.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/bhtvuxzz.sc.entry.js",
		0,
		"common",
		141
	],
	"./c2kiol1t.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c2kiol1t.entry.js",
		"common",
		20
	],
	"./c2kiol1t.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/c2kiol1t.sc.entry.js",
		"common",
		21
	],
	"./ch8upsxn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ch8upsxn.entry.js",
		0,
		"common",
		114
	],
	"./ch8upsxn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ch8upsxn.sc.entry.js",
		0,
		"common",
		115
	],
	"./coytbtgb.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coytbtgb.entry.js",
		"common",
		78
	],
	"./coytbtgb.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/coytbtgb.sc.entry.js",
		"common",
		79
	],
	"./cuwemyof.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cuwemyof.entry.js",
		"common",
		80
	],
	"./cuwemyof.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cuwemyof.sc.entry.js",
		"common",
		81
	],
	"./cyhnsxpk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cyhnsxpk.entry.js",
		0,
		"common",
		144
	],
	"./cyhnsxpk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/cyhnsxpk.sc.entry.js",
		0,
		"common",
		145
	],
	"./dnpeoh7c.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dnpeoh7c.entry.js",
		"common",
		22
	],
	"./dnpeoh7c.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/dnpeoh7c.sc.entry.js",
		"common",
		23
	],
	"./ejzmat7r.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ejzmat7r.entry.js",
		"common",
		74
	],
	"./ejzmat7r.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ejzmat7r.sc.entry.js",
		"common",
		75
	],
	"./fcbdrndu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fcbdrndu.entry.js",
		"common",
		82
	],
	"./fcbdrndu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fcbdrndu.sc.entry.js",
		"common",
		83
	],
	"./ffukzwt6.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.entry.js",
		"common",
		122
	],
	"./ffukzwt6.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ffukzwt6.sc.entry.js",
		"common",
		123
	],
	"./fhznfhbd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fhznfhbd.entry.js",
		"common",
		24
	],
	"./fhznfhbd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fhznfhbd.sc.entry.js",
		"common",
		25
	],
	"./fiqi6app.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.entry.js",
		146
	],
	"./fiqi6app.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/fiqi6app.sc.entry.js",
		147
	],
	"./g0yheybk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g0yheybk.entry.js",
		0,
		"common",
		148
	],
	"./g0yheybk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/g0yheybk.sc.entry.js",
		0,
		"common",
		149
	],
	"./gvyg1bwh.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gvyg1bwh.entry.js",
		"common",
		26
	],
	"./gvyg1bwh.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/gvyg1bwh.sc.entry.js",
		"common",
		27
	],
	"./i9lnulrx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i9lnulrx.entry.js",
		"common",
		28
	],
	"./i9lnulrx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/i9lnulrx.sc.entry.js",
		"common",
		29
	],
	"./jdcptvrs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jdcptvrs.entry.js",
		"common",
		84
	],
	"./jdcptvrs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jdcptvrs.sc.entry.js",
		"common",
		85
	],
	"./jpkvsu5y.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.entry.js",
		"common",
		124
	],
	"./jpkvsu5y.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jpkvsu5y.sc.entry.js",
		"common",
		125
	],
	"./jtkjzkgg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jtkjzkgg.entry.js",
		"common",
		30
	],
	"./jtkjzkgg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jtkjzkgg.sc.entry.js",
		"common",
		31
	],
	"./jwqvpjte.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jwqvpjte.entry.js",
		"common",
		86
	],
	"./jwqvpjte.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jwqvpjte.sc.entry.js",
		"common",
		87
	],
	"./jyrjuxdj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyrjuxdj.entry.js",
		"common",
		32
	],
	"./jyrjuxdj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jyrjuxdj.sc.entry.js",
		"common",
		33
	],
	"./jzmfoyaa.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzmfoyaa.entry.js",
		"common",
		34
	],
	"./jzmfoyaa.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/jzmfoyaa.sc.entry.js",
		"common",
		35
	],
	"./k1gbeuol.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k1gbeuol.entry.js",
		"common",
		126
	],
	"./k1gbeuol.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/k1gbeuol.sc.entry.js",
		"common",
		127
	],
	"./lqvrsauo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lqvrsauo.entry.js",
		"common",
		88
	],
	"./lqvrsauo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/lqvrsauo.sc.entry.js",
		"common",
		89
	],
	"./ly8zbpmk.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ly8zbpmk.entry.js",
		"common",
		36
	],
	"./ly8zbpmk.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ly8zbpmk.sc.entry.js",
		"common",
		37
	],
	"./mny78lhg.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mny78lhg.entry.js",
		0,
		"common",
		150
	],
	"./mny78lhg.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/mny78lhg.sc.entry.js",
		0,
		"common",
		151
	],
	"./n361sgpa.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n361sgpa.entry.js",
		"common",
		38
	],
	"./n361sgpa.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/n361sgpa.sc.entry.js",
		"common",
		39
	],
	"./nr6wcehx.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nr6wcehx.entry.js",
		"common",
		40
	],
	"./nr6wcehx.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nr6wcehx.sc.entry.js",
		"common",
		41
	],
	"./ntxo2f3d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ntxo2f3d.entry.js",
		"common",
		42
	],
	"./ntxo2f3d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ntxo2f3d.sc.entry.js",
		"common",
		43
	],
	"./nxacca4l.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxacca4l.entry.js",
		0,
		"common",
		152
	],
	"./nxacca4l.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxacca4l.sc.entry.js",
		0,
		"common",
		153
	],
	"./nxghvzhm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxghvzhm.entry.js",
		"common",
		44
	],
	"./nxghvzhm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/nxghvzhm.sc.entry.js",
		"common",
		45
	],
	"./oboc8zd4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oboc8zd4.entry.js",
		"common",
		90
	],
	"./oboc8zd4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/oboc8zd4.sc.entry.js",
		"common",
		91
	],
	"./odqmlmdd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/odqmlmdd.entry.js",
		"common",
		46
	],
	"./odqmlmdd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/odqmlmdd.sc.entry.js",
		"common",
		47
	],
	"./psxwmesv.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/psxwmesv.entry.js",
		0,
		"common",
		154
	],
	"./psxwmesv.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/psxwmesv.sc.entry.js",
		0,
		"common",
		155
	],
	"./qtcvseqn.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qtcvseqn.entry.js",
		0,
		"common",
		156
	],
	"./qtcvseqn.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qtcvseqn.sc.entry.js",
		0,
		"common",
		157
	],
	"./qvwswew4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.entry.js",
		"common",
		116
	],
	"./qvwswew4.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/qvwswew4.sc.entry.js",
		"common",
		117
	],
	"./raunowwy.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/raunowwy.entry.js",
		"common",
		92
	],
	"./raunowwy.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/raunowwy.sc.entry.js",
		"common",
		93
	],
	"./s0ahgtia.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s0ahgtia.entry.js",
		2,
		"common",
		158
	],
	"./s0ahgtia.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/s0ahgtia.sc.entry.js",
		2,
		"common",
		159
	],
	"./sdfyvdro.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sdfyvdro.entry.js",
		"common",
		94
	],
	"./sdfyvdro.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sdfyvdro.sc.entry.js",
		"common",
		95
	],
	"./sghmhl28.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sghmhl28.entry.js",
		"common",
		48
	],
	"./sghmhl28.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sghmhl28.sc.entry.js",
		"common",
		49
	],
	"./sjcqnbtt.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sjcqnbtt.entry.js",
		"common",
		96
	],
	"./sjcqnbtt.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/sjcqnbtt.sc.entry.js",
		"common",
		97
	],
	"./t547wlk7.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.entry.js",
		"common",
		118
	],
	"./t547wlk7.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/t547wlk7.sc.entry.js",
		"common",
		119
	],
	"./ta1bgxgm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ta1bgxgm.entry.js",
		"common",
		98
	],
	"./ta1bgxgm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ta1bgxgm.sc.entry.js",
		"common",
		99
	],
	"./tui62q7d.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tui62q7d.entry.js",
		"common",
		100
	],
	"./tui62q7d.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tui62q7d.sc.entry.js",
		"common",
		101
	],
	"./tylmm2yl.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tylmm2yl.entry.js",
		"common",
		102
	],
	"./tylmm2yl.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/tylmm2yl.sc.entry.js",
		"common",
		103
	],
	"./uegz8gm3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uegz8gm3.entry.js",
		"common",
		104
	],
	"./uegz8gm3.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/uegz8gm3.sc.entry.js",
		"common",
		105
	],
	"./ugjythpm.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ugjythpm.entry.js",
		2,
		"common",
		160
	],
	"./ugjythpm.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ugjythpm.sc.entry.js",
		2,
		"common",
		161
	],
	"./unqw84tu.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/unqw84tu.entry.js",
		"common",
		128
	],
	"./unqw84tu.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/unqw84tu.sc.entry.js",
		"common",
		129
	],
	"./vjeei8vr.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vjeei8vr.entry.js",
		"common",
		76
	],
	"./vjeei8vr.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/vjeei8vr.sc.entry.js",
		"common",
		77
	],
	"./wem5ffil.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wem5ffil.entry.js",
		0,
		"common",
		162
	],
	"./wem5ffil.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wem5ffil.sc.entry.js",
		0,
		"common",
		163
	],
	"./wy4rjeqs.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wy4rjeqs.entry.js",
		0,
		"common",
		120
	],
	"./wy4rjeqs.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/wy4rjeqs.sc.entry.js",
		0,
		"common",
		121
	],
	"./xbafxwto.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xbafxwto.entry.js",
		0,
		"common",
		164
	],
	"./xbafxwto.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xbafxwto.sc.entry.js",
		0,
		"common",
		165
	],
	"./xfbndl84.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xfbndl84.entry.js",
		"common",
		50
	],
	"./xfbndl84.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xfbndl84.sc.entry.js",
		"common",
		51
	],
	"./xgnma4yj.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xgnma4yj.entry.js",
		"common",
		106
	],
	"./xgnma4yj.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xgnma4yj.sc.entry.js",
		"common",
		107
	],
	"./xrxaow8a.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xrxaow8a.entry.js",
		"common",
		108
	],
	"./xrxaow8a.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/xrxaow8a.sc.entry.js",
		"common",
		109
	],
	"./ycyyhg01.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ycyyhg01.entry.js",
		"common",
		110
	],
	"./ycyyhg01.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ycyyhg01.sc.entry.js",
		"common",
		111
	],
	"./ygh0szo0.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ygh0szo0.entry.js",
		"common",
		52
	],
	"./ygh0szo0.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/ygh0szo0.sc.entry.js",
		"common",
		53
	],
	"./z9eemkqi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9eemkqi.entry.js",
		"common",
		54
	],
	"./z9eemkqi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9eemkqi.sc.entry.js",
		"common",
		55
	],
	"./z9nt6ntd.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.entry.js",
		"common",
		130
	],
	"./z9nt6ntd.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/z9nt6ntd.sc.entry.js",
		"common",
		131
	],
	"./zktscnoo.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zktscnoo.entry.js",
		"common",
		112
	],
	"./zktscnoo.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zktscnoo.sc.entry.js",
		"common",
		113
	],
	"./zykaqnfi.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zykaqnfi.entry.js",
		"common",
		56
	],
	"./zykaqnfi.sc.entry.js": [
		"./node_modules/@ionic/core/dist/esm/es5/build/zykaqnfi.sc.entry.js",
		"common",
		57
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm/es5/build lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/$$_lazy_route_resource lazy recursive":
/*!**********************************************************!*\
  !*** ./src/$$_lazy_route_resource lazy namespace object ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"../faq/faq.module": [
		"./src/app/faq/faq.module.ts",
		"faq-faq-module"
	],
	"../form1/form1.module": [
		"./src/app/form1/form1.module.ts",
		"form1-form1-module"
	],
	"../form2/form2.module": [
		"./src/app/form2/form2.module.ts",
		"form2-form2-module"
	],
	"../form3/form3.module": [
		"./src/app/form3/form3.module.ts",
		"form3-form3-module"
	],
	"../forms/forms.module": [
		"./src/app/forms/forms.module.ts",
		"forms-forms-module"
	],
	"../message2/message2.module": [
		"./src/app/message2/message2.module.ts",
		"message2-message2-module"
	],
	"../message3/message2.module": [
		"./src/app/message3/message2.module.ts",
		"message3-message2-module"
	],
	"../suivi-demande/suivi-demande.module": [
		"./src/app/suivi-demande/suivi-demande.module.ts",
		"suivi-demande-suivi-demande-module"
	],
	"../suivi/suivi.module": [
		"./src/app/suivi/suivi.module.ts",
		"default~login-login-module~suivi-suivi-module~tab3-tab3-module~tableau-suivi-tableau-suivi-module",
		"default~suivi-suivi-module~tab3-tab3-module~tableau-suivi-tableau-suivi-module",
		"common",
		"suivi-suivi-module"
	],
	"../tab1/tab1.module": [
		"./src/app/tab1/tab1.module.ts",
		"tab1-tab1-module"
	],
	"../tab2/tab2.module": [
		"./src/app/tab2/tab2.module.ts",
		"tab2-tab2-module"
	],
	"../tab3/tab3.module": [
		"./src/app/tab3/tab3.module.ts",
		"default~login-login-module~suivi-suivi-module~tab3-tab3-module~tableau-suivi-tableau-suivi-module",
		"default~Modal-satisfaction-form-satisfaction-form-module~tab3-tab3-module~tableau-suivi-tableau-suiv~2ae3e561",
		"default~suivi-suivi-module~tab3-tab3-module~tableau-suivi-tableau-suivi-module",
		"common",
		"tab3-tab3-module"
	],
	"../tableau-suivi/tableau-suivi.module": [
		"./src/app/tableau-suivi/tableau-suivi.module.ts",
		"default~login-login-module~suivi-suivi-module~tab3-tab3-module~tableau-suivi-tableau-suivi-module",
		"default~Modal-satisfaction-form-satisfaction-form-module~tab3-tab3-module~tableau-suivi-tableau-suiv~2ae3e561",
		"default~suivi-suivi-module~tab3-tab3-module~tableau-suivi-tableau-suivi-module",
		"common",
		"tableau-suivi-tableau-suivi-module"
	],
	"./Modal/facture-pdf/facture-pdf.module": [
		"./src/app/Modal/facture-pdf/facture-pdf.module.ts",
		"Modal-facture-pdf-facture-pdf-module"
	],
	"./Modal/satisfaction-form/satisfaction-form.module": [
		"./src/app/Modal/satisfaction-form/satisfaction-form.module.ts",
		"default~Modal-satisfaction-form-satisfaction-form-module~tab3-tab3-module~tableau-suivi-tableau-suiv~2ae3e561",
		"common",
		"Modal-satisfaction-form-satisfaction-form-module"
	],
	"./login/login.module": [
		"./src/app/login/login.module.ts",
		"default~login-login-module~suivi-suivi-module~tab3-tab3-module~tableau-suivi-tableau-suivi-module",
		"common",
		"login-login-module"
	],
	"./tableau-suivi/tableau-suivi.module": [
		"./src/app/tableau-suivi/tableau-suivi.module.ts",
		"default~login-login-module~suivi-suivi-module~tab3-tab3-module~tableau-suivi-tableau-suivi-module",
		"default~Modal-satisfaction-form-satisfaction-form-module~tab3-tab3-module~tableau-suivi-tableau-suiv~2ae3e561",
		"default~suivi-suivi-module~tab3-tab3-module~tableau-suivi-tableau-suivi-module",
		"common",
		"tableau-suivi-tableau-suivi-module"
	],
	"./tabs/tabs.module": [
		"./src/app/tabs/tabs.module.ts",
		"tabs-tabs-module"
	]
};
function webpackAsyncContext(req) {
	var ids = map[req];
	if(!ids) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		var id = ids[0];
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./src/$$_lazy_route_resource lazy recursive";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./src/Services/auth.service.ts":
/*!**************************************!*\
  !*** ./src/Services/auth.service.ts ***!
  \**************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_0__);
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};

var AuthService = /** @class */ (function () {
    function AuthService() {
        var _this = this;
        this.isAuth = false;
        this.userProfile = firebase__WEBPACK_IMPORTED_MODULE_0__["auth"]().currentUser;
        firebase__WEBPACK_IMPORTED_MODULE_0__["auth"]().onAuthStateChanged(function (user) {
            if (user) {
                _this.isAuth = true;
            }
            else {
                _this.isAuth = false;
            }
        });
    }
    AuthService.prototype.signUpUser = function (email, password, userName, phoneNumber) {
        return new Promise(function (resolve, reject) {
            firebase__WEBPACK_IMPORTED_MODULE_0__["auth"]().createUserWithEmailAndPassword(email, password).then(function (user) {
                resolve(user);
                user.additionalUserInfo.username = userName;
                user.user.updateProfile({
                    displayName: userName,
                    photoURL: "https://cdnfr2.img.sputniknews.com/images/103681/99/1036819995.jpg",
                });
            }, function (error) {
                reject(error);
            });
        });
    };
    AuthService.prototype.signInUser = function (email, password) {
        return new Promise(function (resolve, reject) {
            firebase__WEBPACK_IMPORTED_MODULE_0__["auth"]().signInWithEmailAndPassword(email, password).then(function (user) {
                //   if(user.user.emailVerified){
                //   resolve(user);
                // }
                //   else{
                //     this.sendEmailVerification();
                //     window.alert("va voir tes mails connard !");
                //     return user.user.emailVerified.valueOf;
                //   }
                resolve(user);
            }, function (error) {
                reject(error);
            });
        });
    };
    AuthService.prototype.signOut = function () {
        firebase__WEBPACK_IMPORTED_MODULE_0__["auth"]().signOut();
    };
    AuthService.prototype.sendEmailVerification = function () {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, firebase__WEBPACK_IMPORTED_MODULE_0__["auth"]().currentUser.sendEmailVerification()];
                    case 1:
                        _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    return AuthService;
}());



/***/ }),

/***/ "./src/app/Modal/profil/profil.module.ts":
/*!***********************************************!*\
  !*** ./src/app/Modal/profil/profil.module.ts ***!
  \***********************************************/
/*! exports provided: ProfilPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilPageModule", function() { return ProfilPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _profil_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./profil.page */ "./src/app/Modal/profil/profil.page.ts");
/* harmony import */ var _up_password_up_password_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../up-password/up-password.module */ "./src/app/Modal/up-password/up-password.module.ts");
/* harmony import */ var _up_phone_up_phone_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../up-phone/up-phone.module */ "./src/app/Modal/up-phone/up-phone.module.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var ProfilPageModule = /** @class */ (function () {
    function ProfilPageModule() {
    }
    ProfilPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
                _up_password_up_password_module__WEBPACK_IMPORTED_MODULE_5__["UpPasswordPageModule"],
                _up_phone_up_phone_module__WEBPACK_IMPORTED_MODULE_6__["UpPhonePageModule"],
            ],
            declarations: [_profil_page__WEBPACK_IMPORTED_MODULE_4__["ProfilPage"]],
            entryComponents: [
                _profil_page__WEBPACK_IMPORTED_MODULE_4__["ProfilPage"]
            ]
        })
    ], ProfilPageModule);
    return ProfilPageModule;
}());



/***/ }),

/***/ "./src/app/Modal/profil/profil.page.html":
/*!***********************************************!*\
  !*** ./src/app/Modal/profil/profil.page.html ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Mes informations</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n    <!-- <ion-row>\n      <ion-col size=\"3\">\n        <ion-avatar class=\"md\" text-center >\n          <img [src]=\"'assets/img/noavatar.png'\" >\n        </ion-avatar>\n      </ion-col>\n      <ion-col>\n        <h5 (click)=\"NewPhoto()\"> Charger une nouvelle photo de profil</h5>\n        </ion-col>\n      </ion-row> -->\n    <form>\n    <div class=\"encadre\">\n<ion-item>\n  <ion-label position=\"floating\"  >Nom</ion-label>\n  <ion-input class=\"inputer\" (keydown)=\"ecris()\"  [(ngModel)]=\"nom\" [ngModelOptions]=\"{standalone: true}\" clearInput></ion-input>\n</ion-item>\n<ion-item>\n    <ion-label position=\"floating\" >Prénom</ion-label>\n    <ion-input class=\"inputer\"  [(ngModel)]=\"prenom\" [ngModelOptions]=\"{standalone: true}\" clearInput></ion-input>\n</ion-item>\n<ion-item>\n  <ion-label position=\"floating\" pattern=\"tel\" >Numéro de téléphone</ion-label>\n  <!-- <ion-row>\n      <ion-col size=\"7\">\n          <ion-select [interfaceOptions]=\"customPopoverOptions\" value=\"+33\" interface=\"popover\" placeholder=\"\">\n            <ion-select-option value=\"+33\">+33</ion-select-option>\n              <ion-select-option value=\"+221\">+221</ion-select-option>\n              <ion-select-option value=\"+222\">+222</ion-select-option>\n              <ion-select-option value=\"+223\">+223</ion-select-option>\n          </ion-select>\n      </ion-col>\n      <ion-col>\n            <ion-input clearInput></ion-input>\n      </ion-col>\n    </ion-row> -->\n    <ion-input class=\"inputer\" disabled inputmode=\"tel\" clearInput [(ngModel)]=\"phoneNumber\" [ngModelOptions]=\"{standalone: true}\"></ion-input>\n</ion-item>\n    <ion-item>\n      <ion-label position=\"floating\" pattern=\"email\" >E-mail</ion-label>\n      <ion-input class=\"inputer\" pattern=\"[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$\" inputmode=\"email\" clearInput [(ngModel)]=\"email\" [ngModelOptions]=\"{standalone: true}\" ></ion-input>\n  </ion-item>\n</div>\n<div class=\"encadre\">\n<ion-item >\n    <ion-label position=\"floating\">Adresse d'expédition</ion-label>\n    <ion-input class=\"inputer\"  [(ngModel)]=\"adresse\" placeholder=\"adresse\" [ngModelOptions]=\"{standalone: true}\" clearInput  ></ion-input>\n    <ion-input class=\"inputer\"  [(ngModel)]=\"code\" placeholder=\"Code postal\" [ngModelOptions]=\"{standalone: true}\" clearInput  ></ion-input>\n    <ion-input class=\"inputer\"  [(ngModel)]=\"pays\"  placeholder=\"Pays\" [ngModelOptions]=\"{standalone: true}\" clearInput  ></ion-input>\n\n</ion-item>\n\n<ion-item >\n  <ion-label position=\"floating\">Adresse de livraison</ion-label>\n  <ion-input class=\"inputer\"  [(ngModel)]=\"adresseliv\" placeholder=\"adresse\" [ngModelOptions]=\"{standalone: true}\" clearInput  ></ion-input>\n  <ion-input class=\"inputer\"  [(ngModel)]=\"codeliv\" placeholder=\"Code postal\" [ngModelOptions]=\"{standalone: true}\" clearInput  ></ion-input>\n  <ion-input class=\"inputer\"  [(ngModel)]=\"paysliv\"  placeholder=\"Pays\" [ngModelOptions]=\"{standalone: true}\" clearInput  ></ion-input>\n\n</ion-item>\n</div>\n\n<br>\n<ion-button type=\"submit\" (click)=\"Enregistrer()\" block>Enregistrer</ion-button>\n  </form>\n  <ion-button expand=\"full\" (click)=\"goToUpPhone()\" block>Mettre à jour mon numéro téléphone</ion-button>\n  <ion-button expand=\"full\" (click)=\"goToUpPassword()\" block>Modifier mon mot de passe</ion-button>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/Modal/profil/profil.page.scss":
/*!***********************************************!*\
  !*** ./src/app/Modal/profil/profil.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .encadre {\n  border: 2px solid #343582;\n  border-radius: 1em;\n  padding: 1%;\n  margin-bottom: 2%;\n  z-index: 100000000000; }\n\n:host div.item-native {\n  background: none !important;\n  background-color: none !important;\n  z-index: 10;\n  border-radius: 3em; }\n\n:host .itema {\n  background: none !important;\n  background-color: none !important;\n  border-radius: 3em; }\n\n:host .inputer {\n  color: #525865;\n  border-radius: 4px;\n  border: 1px solid #d1d1d1;\n  box-shadow: inset 1px 2px 8px rgba(0, 0, 0, 0.07);\n  font-family: inherit;\n  font-size: 1em;\n  line-height: 1.45;\n  outline: none;\n  padding: 0.6em 1.45em 0.7em;\n  transition: .18s ease-out; }\n\n:host .inputer:hover {\n  box-shadow: inset 1px 2px 8px rgba(0, 0, 0, 0.02); }\n\n:host .inputer:focus {\n  color: #4b515d;\n  border: 1px solid #B8B6B6;\n  box-shadow: inset 1px 2px 4px rgba(0, 0, 0, 0.01), 0px 0px 8px rgba(0, 0, 0, 0.2); }\n\n:host .item-interactive, :host .item-lines-full {\n  --border-width: 0 0 0px 0;\n  --show-full-highlight: 1;\n  --show-inset-highlight: 0; }\n\n:host .item-interactive.ion-touched.ion-invalid, :host .item-interactive.item-has-focus {\n  --full-highlight-height:0px;\n  --inset-highlight-height:0px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvTW9kYWwvcHJvZmlsL0M6XFxVc2Vyc1xcSXJpcyBHZXJhbGRvXFxEb2N1bWVudHNcXE91dGFsbWFmaW5cXE91dGFsbWEvc3JjXFxhcHBcXE1vZGFsXFxwcm9maWxcXHByb2ZpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFUSx5QkFBeUI7RUFDekIsa0JBQWtCO0VBQ2xCLFdBQVU7RUFDVixpQkFBaUI7RUFDakIscUJBQW9CLEVBQUE7O0FBTjVCO0VBU1EsMkJBQTJCO0VBQzNCLGlDQUFpQztFQUNqQyxXQUFXO0VBQ1gsa0JBQWtCLEVBQUE7O0FBWjFCO0VBZVEsMkJBQTJCO0VBQzNCLGlDQUFpQztFQUNqQyxrQkFBa0IsRUFBQTs7QUFqQjFCO0VBcUJRLGNBQWM7RUFDZCxrQkFBa0I7RUFDbEIseUJBQXlCO0VBQ3pCLGlEQUFpRDtFQUNqRCxvQkFBb0I7RUFDcEIsY0FBYztFQUNkLGlCQUFpQjtFQUNqQixhQUFhO0VBQ2IsMkJBQTJCO0VBSTNCLHlCQUF5QixFQUFBOztBQWpDakM7RUFvQ00saURBQWlELEVBQUE7O0FBcEN2RDtFQXVDTSxjQUFjO0VBQ2QseUJBQXlCO0VBQ3pCLGlGQUFpRixFQUFBOztBQXpDdkY7RUE2Q1EseUJBQWU7RUFDZix3QkFBc0I7RUFDdEIseUJBQXVCLEVBQUE7O0FBL0MvQjtFQWtEUSwyQkFBd0I7RUFDeEIsNEJBQXlCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9Nb2RhbC9wcm9maWwvcHJvZmlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0e1xyXG4gICAgLmVuY2FkcmV7XHJcbiAgICAgICAgYm9yZGVyOiAycHggc29saWQgIzM0MzU4MjtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxZW07XHJcbiAgICAgICAgcGFkZGluZzoxJTtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAyJTtcclxuICAgICAgICB6LWluZGV4OjEwMDAwMDAwMDAwMDtcclxuICAgIH1cclxuICAgIGRpdi5pdGVtLW5hdGl2ZSB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IG5vbmUgIWltcG9ydGFudDtcclxuICAgICAgICB6LWluZGV4OiAxMDtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAzZW07XHJcbiAgICB9XHJcbiAgICAuaXRlbWEge1xyXG4gICAgICAgIGJhY2tncm91bmQ6IG5vbmUgIWltcG9ydGFudDtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBub25lICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogM2VtO1xyXG4gICAgfVxyXG4gICAgLmlucHV0ZXJ7XHJcbiAgICAgICAgLy8gYmFja2dyb3VuZDogI2ZmZjtcclxuICAgICAgICBjb2xvcjogIzUyNTg2NTtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiA0cHg7XHJcbiAgICAgICAgYm9yZGVyOiAxcHggc29saWQgI2QxZDFkMTtcclxuICAgICAgICBib3gtc2hhZG93OiBpbnNldCAxcHggMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMDcpO1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBpbmhlcml0O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMWVtO1xyXG4gICAgICAgIGxpbmUtaGVpZ2h0OiAxLjQ1O1xyXG4gICAgICAgIG91dGxpbmU6IG5vbmU7XHJcbiAgICAgICAgcGFkZGluZzogMC42ZW0gMS40NWVtIDAuN2VtO1xyXG4gICAgICAgIC13ZWJraXQtdHJhbnNpdGlvbjogLjE4cyBlYXNlLW91dDtcclxuICAgICAgICAtbW96LXRyYW5zaXRpb246IC4xOHMgZWFzZS1vdXQ7XHJcbiAgICAgICAgLW8tdHJhbnNpdGlvbjogLjE4cyBlYXNlLW91dDtcclxuICAgICAgICB0cmFuc2l0aW9uOiAuMThzIGVhc2Utb3V0O1xyXG4gICAgfVxyXG4gICAgLmlucHV0ZXI6aG92ZXIge1xyXG4gICAgICBib3gtc2hhZG93OiBpbnNldCAxcHggMnB4IDhweCByZ2JhKDAsIDAsIDAsIDAuMDIpO1xyXG4gICAgfVxyXG4gICAgLmlucHV0ZXI6Zm9jdXMge1xyXG4gICAgICBjb2xvcjogIzRiNTE1ZDtcclxuICAgICAgYm9yZGVyOiAxcHggc29saWQgI0I4QjZCNjtcclxuICAgICAgYm94LXNoYWRvdzogaW5zZXQgMXB4IDJweCA0cHggcmdiYSgwLCAwLCAwLCAwLjAxKSwgMHB4IDBweCA4cHggcmdiYSgwLCAwLCAwLCAwLjIpO1xyXG4gICAgfVxyXG5cclxuICAgIC5pdGVtLWludGVyYWN0aXZlLCAuaXRlbS1saW5lcy1mdWxsIHtcclxuICAgICAgICAtLWJvcmRlci13aWR0aDogMCAwIDBweCAwO1xyXG4gICAgICAgIC0tc2hvdy1mdWxsLWhpZ2hsaWdodDogMTtcclxuICAgICAgICAtLXNob3ctaW5zZXQtaGlnaGxpZ2h0OiAwO1xyXG4gICAgfVxyXG4gICAgLml0ZW0taW50ZXJhY3RpdmUuaW9uLXRvdWNoZWQuaW9uLWludmFsaWQsIC5pdGVtLWludGVyYWN0aXZlLml0ZW0taGFzLWZvY3VzIHtcclxuICAgICAgICAtLWZ1bGwtaGlnaGxpZ2h0LWhlaWdodDowcHg7XHJcbiAgICAgICAgLS1pbnNldC1oaWdobGlnaHQtaGVpZ2h0OjBweDtcclxuICAgIH0gXHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/Modal/profil/profil.page.ts":
/*!*********************************************!*\
  !*** ./src/app/Modal/profil/profil.page.ts ***!
  \*********************************************/
/*! exports provided: ProfilPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilPage", function() { return ProfilPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _up_password_up_password_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../up-password/up-password.page */ "./src/app/Modal/up-password/up-password.page.ts");
/* harmony import */ var _up_phone_up_phone_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../up-phone/up-phone.page */ "./src/app/Modal/up-phone/up-phone.page.ts");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_5__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var ProfilPage = /** @class */ (function () {
    function ProfilPage(modalCtrl, actionSheetController) {
        this.modalCtrl = modalCtrl;
        this.actionSheetController = actionSheetController;
        this.VigiK = "";
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        this.Voirdonnees();
    }
    ProfilPage.prototype.ngOnInit = function () {
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        this.Voirdonnees();
        this.nom = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(this.info['0'].Nom.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8);
        this.prenom = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(this.info['0'].Prenom.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8);
        this.adresse = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(this.info['0'].Ad_rue_e.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8);
        this.adresseliv = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(this.info['0'].Ad_rue_l.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8);
        this.code = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(this.info['0'].Ad_pos_e.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8);
        this.codeliv = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(this.info['0'].Ad_pos_l.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8);
        this.pays = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(this.info['0'].Ad_pay_e.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8);
        this.paysliv = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(this.info['0'].Ad_pay_l.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8);
        this.datenaiss = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(this.info['0'].date_naiss.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8);
        this.email = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(this.info['0'].email.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8);
        this.phoneNumber = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(this.info['0'].phoneNumber.trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8);
    };
    ProfilPage.prototype.ecris = function () {
        console.log(this.info);
    };
    ProfilPage.prototype.Enregistrer = function () {
        var _this = this;
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.updateProfile({
            displayName: this.prenom + " " + this.nom,
            photoURL: this.datenaiss
        });
        var pays = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(this.pays.trim(), VigiK.trim()).toString();
        var paysliv = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(this.paysliv.trim(), VigiK.trim()).toString();
        var codeliv = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(this.codeliv.trim(), VigiK.trim()).toString();
        var code = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(this.code.trim(), VigiK.trim()).toString();
        var adresse = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(this.adresse.trim(), VigiK.trim()).toString();
        var adresseliv = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(this.adresseliv.trim(), VigiK.trim()).toString();
        var nom = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(this.nom.trim(), VigiK.trim()).toString();
        var Prenom = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(this.prenom.trim(), VigiK.trim()).toString();
        var datenaiss = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(this.datenaiss.trim(), VigiK.trim()).toString();
        var email = crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(this.email.trim(), VigiK.trim()).toString();
        if (this.email != null && this.email != "") {
            firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.updateEmail(this.email).then(function () {
                firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/user/' + firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid).set([
                    {
                        Ad_pay_e: pays,
                        Ad_pay_l: paysliv,
                        Ad_pos_e: code,
                        Ad_pos_l: codeliv,
                        Ad_rue_e: adresse,
                        Ad_rue_l: adresseliv,
                        Nom: nom,
                        Prenom: Prenom,
                        date_naiss: datenaiss,
                        désativé: false,
                        email: email,
                        emailVerified: firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.emailVerified,
                        phoneNumber: crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.phoneNumber.trim(), this.VigiK.trim()).toString(),
                    }
                ]).then(function (data) {
                }, function (error) {
                    console.log(error);
                });
                ;
            });
        }
        else {
            firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/user/' + firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid).set([
                {
                    Ad_pay_e: pays,
                    Ad_pay_l: paysliv,
                    Ad_pos_e: code,
                    Ad_pos_l: codeliv,
                    Ad_rue_e: adresse,
                    Ad_rue_l: adresseliv,
                    Nom: nom,
                    Prenom: Prenom,
                    date_naiss: datenaiss,
                    désativé: false,
                    email: email,
                    emailVerified: firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.emailVerified,
                    phoneNumber: crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].encrypt(firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.phoneNumber.trim(), this.VigiK.trim()).toString(),
                }
            ]).then(function (data) {
                console.log(_this.info);
            }, function (error) {
                console.log(error, _this.info);
            });
            ;
        }
    };
    ProfilPage.prototype.close = function () {
        this.modalCtrl.dismiss();
    };
    //   User Info
    // Pays d'expedition
    // Pays de livraison
    // Code postal expedition
    // Code postal livraison
    // Adresse expedition 
    // Adresse livraison
    // Date de naissance
    // User action
    // Sup compte
    // Modif number
    // Modif mdp
    // Modif mail
    ProfilPage.prototype.Voirdonnees = function () {
        var InTabDemandes = [];
        firebase__WEBPACK_IMPORTED_MODULE_2__["database"]().ref('/user/' + firebase__WEBPACK_IMPORTED_MODULE_2__["auth"]().currentUser.uid + "/").on("value", function (snapshot) {
            var suivibdd = snapshot.val();
            suivibdd.forEach(function (entry) {
                InTabDemandes.push(entry);
            });
        }, function (error) {
            console.log("Error dans VoirDonnees: " + error.code);
        });
        this.info = InTabDemandes;
        console.log("voir taba = ", this.info);
    };
    ProfilPage.prototype.goToUpPhone = function () {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _up_phone_up_phone_page__WEBPACK_IMPORTED_MODULE_4__["UpPhonePage"],
                            mode: "ios",
                            showBackdrop: true,
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.present();
                        console.log("jeld,");
                        return [2 /*return*/];
                }
            });
        });
    };
    ProfilPage.prototype.goToUpPassword = function () {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            mode: "ios",
                            showBackdrop: true,
                            component: _up_password_up_password_page__WEBPACK_IMPORTED_MODULE_3__["UpPasswordPage"],
                            componentProps: {
                                'phoneNumber': "this.phonehNumber.value"
                            }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.present();
                        console.log("jeld,");
                        return [2 /*return*/];
                }
            });
        });
    };
    ProfilPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-profil',
            template: __webpack_require__(/*! ./profil.page.html */ "./src/app/Modal/profil/profil.page.html"),
            styles: [__webpack_require__(/*! ./profil.page.scss */ "./src/app/Modal/profil/profil.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ActionSheetController"]])
    ], ProfilPage);
    return ProfilPage;
}());



/***/ }),

/***/ "./src/app/Modal/up-password/up-password.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/Modal/up-password/up-password.module.ts ***!
  \*********************************************************/
/*! exports provided: UpPasswordPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpPasswordPageModule", function() { return UpPasswordPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _up_password_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./up-password.page */ "./src/app/Modal/up-password/up-password.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var UpPasswordPageModule = /** @class */ (function () {
    function UpPasswordPageModule() {
    }
    UpPasswordPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
            ],
            declarations: [_up_password_page__WEBPACK_IMPORTED_MODULE_4__["UpPasswordPage"]],
            entryComponents: [
                _up_password_page__WEBPACK_IMPORTED_MODULE_4__["UpPasswordPage"]
            ]
        })
    ], UpPasswordPageModule);
    return UpPasswordPageModule;
}());



/***/ }),

/***/ "./src/app/Modal/up-password/up-password.page.html":
/*!*********************************************************!*\
  !*** ./src/app/Modal/up-password/up-password.page.html ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Modifier mon mot de passe</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content *ngIf=\"!isAuth\" padding class=\"bg\">\n  <form [formGroup]=\"authForm\" >\n    <ion-item>\n      <ion-label><ion-icon name=\"call\"></ion-icon>&nbsp;<ion-icon name=\"add\"></ion-icon></ion-label>\n      <ion-input placeholder=\"ex : 33123456789\" type=\"text\" formControlName=\"phoneNumber\" clearInput></ion-input>\n    </ion-item>\n    <!-- <ion-item>\n      <ion-label><ion-icon ios=\"ios-unlock\" md=\"md-unlock\"></ion-icon></ion-label>\n      <ion-input autocomplete=\"false\" [formControl]=\"password\" id=\"password\" type=\"{{passwordtype}}\" required placeholder=\"Password *\"></ion-input>\n      <button ion-button fill=\"clear\" class=\"eye-icon-btn\" type=\"button\" item-right (click)=\"managePassword()\">\n        <ion-icon name=\"{{passeye}}\"></ion-icon></button>\n    </ion-item>\n    <ion-item >\n      <ion-label><ion-icon ios=\"ios-unlock\" md=\"md-unlock\"></ion-icon></ion-label>\n      <ion-input autocomplete=\"false\" [formControl]=\"password2\" id=\"password2\" type=\"{{passwordtype2}}\" required placeholder=\"Confirm Password *\"></ion-input>\n      <button ion-button fill=\"clear\" class=\"eye-icon-btn\" type=\"button\" item-right (click)=\"managePassword2()\">\n        <ion-icon name=\"{{passeye2}}\"></ion-icon></button>\n    </ion-item> \n      <ion-item >\n        <ion-label><ion-icon name=\"calendar\"></ion-icon></ion-label>\n          <ion-input placeholder=\"Date de naissance\" type=\"date\" formControlName=\"Date\"  required clearInput></ion-input>\n          \n    </ion-item> -->\n  <div id=\"recaptcha-container\" ></div>\n\n  </form>\n</ion-content>\n\n<ion-toolbar color=\"primary\">\n  <ion-button expand=\"block\" type=\"submit\" (click)=\"signIn();show = !show\">Modifier mon mot de passe</ion-button>\n  \n</ion-toolbar>\n"

/***/ }),

/***/ "./src/app/Modal/up-password/up-password.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/Modal/up-password/up-password.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL01vZGFsL3VwLXBhc3N3b3JkL3VwLXBhc3N3b3JkLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/Modal/up-password/up-password.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/Modal/up-password/up-password.page.ts ***!
  \*******************************************************/
/*! exports provided: UpPasswordPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpPasswordPage", function() { return UpPasswordPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var src_Services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/Services/auth.service */ "./src/Services/auth.service.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};





var UpPasswordPage = /** @class */ (function () {
    function UpPasswordPage(modalCtrl, actionSheetController, navCtrl, toastCtrl, menuCtrl, authService, formBuilder, alertCtrl, navPrm) {
        this.modalCtrl = modalCtrl;
        this.actionSheetController = actionSheetController;
        this.navCtrl = navCtrl;
        this.toastCtrl = toastCtrl;
        this.menuCtrl = menuCtrl;
        this.authService = authService;
        this.formBuilder = formBuilder;
        this.alertCtrl = alertCtrl;
        this.navPrm = navPrm;
        this.passwordtype = 'password';
        this.passeye = 'eye';
        this.passwordtype2 = 'password';
        this.passeye2 = 'eye';
        this.date = '';
        this.vuDate = true;
        this.btnDate = false;
        this.show = false;
        var phoneNumber = this.navPrm.get('phoneNumber');
        console.log('phoneNumber: ', phoneNumber);
    }
    UpPasswordPage.prototype.ngOnInit = function () {
        firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().languageCode = 'fr';
        this.initForm();
        var phoneNumber = this.navPrm.get('phoneNumber');
        this.modalCtrl.getTop();
        console.log('phoneNumber: ', phoneNumber);
        console.log('phoneNumber: ', this.phoneNumber.value);
    };
    UpPasswordPage.prototype.close = function () {
        this.modalCtrl.dismiss({
            'phoneNumber': this.phoneNumber.value
        });
    };
    UpPasswordPage.prototype.signIn = function () {
        var _this = this;
        this.ionViewDidLoad();
        var appVerifier = this.recaptchaVerifier;
        var num = this.authForm.get('phoneNumber').value;
        var phoneNumber = '+' + num;
        var password = this.authForm.get('password').value;
        var password2 = this.authForm.get('password2').value;
        var date = this.authForm.get('Date').value;
        var MajPwd = this.MajPwd;
        var toast = this.toastCtrl;
        var erreur = this.presentToast;
        var str = phoneNumber;
        var ret = "";
        var faux = true;
        var modal = this.modalCtrl;
        var alertCtrl = this.alertCtrl;
        // var aply = this.applyShow
        var sho = this.show;
        if (this.authForm.get('phoneNumber').valid != true || num == null) {
            var err = { code: "Input erronés", message: "" };
            this.presentToast(err, toast);
        }
        else {
            for (var i = 0; i < str.length; i++) {
                if (i >= str.length - 3) {
                    ret += str.charAt(i);
                }
                else {
                    ret += "x";
                }
            }
            firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().signInWithPhoneNumber(phoneNumber, appVerifier)
                .then(function (confirmationResult) { return __awaiter(_this, void 0, void 0, function () {
                var prompt;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.alertCtrl.create({
                                header: 'Un code de confimation a été envoyé au : ' + '+' + ret,
                                inputs: [{ name: 'confirmationCode', placeholder: 'Entrez le code de confirmation' }],
                                buttons: [
                                    {
                                        text: 'ANNULER',
                                        handler: function (data) { console.log('Cancel clicked'); }
                                    },
                                    {
                                        text: 'VALIDER',
                                        handler: function (data) {
                                            confirmationResult.confirm(data.confirmationCode)
                                                .then(function (result) {
                                                return __awaiter(this, void 0, void 0, function () {
                                                    return __generator(this, function (_a) {
                                                        MajPwd(phoneNumber, password, password2, toast, date, appVerifier, erreur, faux, modal, alertCtrl);
                                                        //aply()
                                                        sho = true;
                                                        console.log(result.user);
                                                        return [2 /*return*/];
                                                    });
                                                });
                                            }).catch(function (error) {
                                                console.log(error);
                                                erreur(error, toast);
                                                appVerifier.clear();
                                            });
                                        }
                                    }
                                ]
                            })];
                        case 1:
                            prompt = _a.sent();
                            prompt.present();
                            return [2 /*return*/];
                    }
                });
            }); })
                .catch(function (error) {
                erreur(error, toast);
                console.error('SMS not sent', phoneNumber, error);
                appVerifier.clear();
            });
            console.log(this.show);
        }
    };
    UpPasswordPage.prototype.MajPwd = function (phoneNumber, password, password2, toast, date, appVerifier, erreur, faux, modal, alertCtrl) {
        return __awaiter(this, void 0, void 0, function () {
            var email, emaiil, prompt_1;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        email = firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.email;
                        emaiil = phoneNumber + "@fakemail.outalma";
                        console.log(emaiil);
                        if (!("+" + email == emaiil)) return [3 /*break*/, 2];
                        return [4 /*yield*/, alertCtrl.create({
                                header: 'Changement du mot de passe',
                                subHeader: 'Vérification de la date de naissance',
                                mode: 'ios',
                                inputs: [
                                    { name: 'date', placeholder: 'Vérification de la date de naissance', type: 'date' },
                                    { name: 'newmdp', placeholder: 'Nouveau mot de passe', type: 'password' },
                                    { name: 'newmdp2', placeholder: 'Vérification du mot de passe', type: 'password' },
                                ],
                                buttons: [
                                    {
                                        text: 'Annuler',
                                        handler: function (data) { console.log('Cancel clicked'); }
                                    },
                                    {
                                        text: 'Valider',
                                        handler: function (data) { return __awaiter(_this, void 0, void 0, function () {
                                            var dateUser, tooast, tooast;
                                            var _this = this;
                                            return __generator(this, function (_a) {
                                                switch (_a.label) {
                                                    case 0:
                                                        dateUser = firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.photoURL;
                                                        if (!(dateUser == data.date && data.newmdp == data.newmdp2)) return [3 /*break*/, 1];
                                                        firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.updatePassword(data.newmdp).then(function (result) { return __awaiter(_this, void 0, void 0, function () {
                                                            var tooast;
                                                            return __generator(this, function (_a) {
                                                                switch (_a.label) {
                                                                    case 0: return [4 /*yield*/, toast.create({
                                                                            message: 'Votre mot de passe a bien été modifié',
                                                                            duration: 5000,
                                                                            position: 'middle',
                                                                            color: 'success'
                                                                        })];
                                                                    case 1:
                                                                        tooast = _a.sent();
                                                                        tooast.present();
                                                                        modal.dismiss();
                                                                        appVerifier.clear();
                                                                        return [2 /*return*/];
                                                                }
                                                            });
                                                        }); }, function (error) { return __awaiter(_this, void 0, void 0, function () {
                                                            return __generator(this, function (_a) {
                                                                erreur(error, toast);
                                                                appVerifier.clear();
                                                                return [2 /*return*/];
                                                            });
                                                        }); });
                                                        return [3 /*break*/, 5];
                                                    case 1:
                                                        if (!(dateUser != data.date)) return [3 /*break*/, 3];
                                                        return [4 /*yield*/, toast.create({
                                                                message: 'La date de naissance est invalide.',
                                                                duration: 10000,
                                                                position: 'middle',
                                                                color: 'danger',
                                                                showCloseButton: true,
                                                                closeButtonText: 'FERMER'
                                                            })];
                                                    case 2:
                                                        tooast = _a.sent();
                                                        tooast.present();
                                                        appVerifier.clear();
                                                        return [3 /*break*/, 5];
                                                    case 3:
                                                        if (!(data.newmdp2 != data.newmdp)) return [3 /*break*/, 5];
                                                        return [4 /*yield*/, toast.create({
                                                                message: 'Les mots de passes ne sont pas les mêmes.',
                                                                duration: 10000,
                                                                position: 'middle',
                                                                color: 'danger',
                                                                showCloseButton: true,
                                                                closeButtonText: 'FERMER'
                                                            })];
                                                    case 4:
                                                        tooast = _a.sent();
                                                        tooast.present();
                                                        appVerifier.clear();
                                                        _a.label = 5;
                                                    case 5: return [2 /*return*/];
                                                }
                                            });
                                        }); }
                                    }
                                ]
                            })];
                    case 1:
                        prompt_1 = _a.sent();
                        prompt_1.present();
                        return [3 /*break*/, 3];
                    case 2:
                        firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().sendPasswordResetEmail(email)
                            .then(function (result) { return __awaiter(_this, void 0, void 0, function () {
                            var tooast;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, toast.create({
                                            message: 'Un email de modification de votre mot de passe vous a été envoyé.',
                                            duration: 10000,
                                            position: 'middle',
                                            color: 'success',
                                            showCloseButton: true,
                                            closeButtonText: 'FERMER'
                                        })];
                                    case 1:
                                        tooast = _a.sent();
                                        tooast.present();
                                        modal.dismiss();
                                        return [2 /*return*/];
                                }
                            });
                        }); }, function (error) { return __awaiter(_this, void 0, void 0, function () {
                            return __generator(this, function (_a) {
                                erreur(error, toast);
                                appVerifier.clear();
                                return [2 /*return*/];
                            });
                        }); });
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    UpPasswordPage.prototype.MajPwd2 = function () {
    };
    UpPasswordPage.prototype.presentToastMdp = function () {
        return __awaiter(this, void 0, void 0, function () {
            var toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Les mots de passe ne sont pas les mêmes',
                            duration: 5000,
                            position: 'middle',
                            color: 'danger'
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    UpPasswordPage.prototype.presentToast = function (err, toast) {
        return __awaiter(this, void 0, void 0, function () {
            var tooast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (err.code == "auth/provider-already-linked") {
                            err.message = "Cet utilisateur existe déjà.";
                        }
                        else if (err.code == "auth/argument-error") {
                            err.message = "Veuillez vérifier les paramètres du formulaire.";
                        }
                        else if (err.code == "auth/network-request-failed") {
                            err.message = "Veuillez vérifier vos paramètres réseau.";
                        }
                        else if (err.code == "auth/too-many-request") {
                            err.message = "Les demandes de votre périphérique sont bloquées en raison d'activités inhabituelles. Veuillez réessayer plus tard.";
                        }
                        else if (err.code == "auth/invalid-email") {
                            err.message = "L'email est invalide.";
                        }
                        else if (err.code == "auth/invalid-phone-number") {
                            err.message = "Le format du numéro de téléphone est invalide.";
                        }
                        else if (err.code == "auth/wrong-password") {
                            err.message = "Le mot de passe est invalide.";
                        }
                        else if (err.code == "auth/user-disabled") {
                            err.message = "Le compte a été désactivé par un administrateur. Veuillez contacter le service client.";
                        }
                        else if (err.code == "auth/weak-password") {
                            err.message = "Le mot de passe doit contenir 6 caractères.";
                        }
                        else if (err.code == "Input erronés") {
                            err.message = "Veuillez vérifier les valeurs entrées.";
                        }
                        else {
                            err.message = "Un problème est survenu. Veuillez contacter le service client.";
                        }
                        return [4 /*yield*/, toast.create({
                                message: err.message,
                                duration: 10000,
                                position: 'middle',
                                color: 'danger',
                                showCloseButton: true,
                                closeButtonText: 'FERMER'
                            })];
                    case 1:
                        tooast = _a.sent();
                        tooast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    UpPasswordPage.prototype.initForm = function () {
        this.authForm = this.formBuilder.group({
            'Date': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            'password': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            'password2': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            'phoneNumber': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
        });
        this.Date = this.authForm.controls['Date'];
        this.password = this.authForm.controls['password'];
        this.password2 = this.authForm.controls['password2'];
        this.phoneNumber = this.authForm.controls['phoneNumber'];
    };
    UpPasswordPage.prototype.managePassword = function () {
        if (this.passwordtype == 'password') {
            this.passwordtype = 'text';
            this.passeye = 'eye-off';
        }
        else {
            this.passwordtype = 'password';
            this.passeye = 'eye';
        }
    };
    UpPasswordPage.prototype.ionViewDidLoad = function () {
        this.recaptchaVerifier = new firebase__WEBPACK_IMPORTED_MODULE_3__["auth"].RecaptchaVerifier('recaptcha-container', {
            // 'size': 'invisible',
            'callback': function (response) {
                // reCAPTCHA solved - will proceed with submit function
                console.log(response);
                return true;
            },
            'expired-callback': function () {
                // Reset reCAPTCHA?
                console.log('recaptcha expired');
            }
        });
    };
    UpPasswordPage.prototype.managePassword2 = function () {
        if (this.passwordtype2 == 'password') {
            this.passwordtype2 = 'text';
            this.passeye2 = 'eye-off';
        }
        else {
            this.passwordtype2 = 'password';
            this.passeye2 = 'eye';
        }
    };
    UpPasswordPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-up-password',
            template: __webpack_require__(/*! ./up-password.page.html */ "./src/app/Modal/up-password/up-password.page.html"),
            styles: [__webpack_require__(/*! ./up-password.page.scss */ "./src/app/Modal/up-password/up-password.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ActionSheetController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["MenuController"],
            src_Services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["AlertController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavParams"]])
    ], UpPasswordPage);
    return UpPasswordPage;
}());



/***/ }),

/***/ "./src/app/Modal/up-phone/up-phone.module.ts":
/*!***************************************************!*\
  !*** ./src/app/Modal/up-phone/up-phone.module.ts ***!
  \***************************************************/
/*! exports provided: UpPhonePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpPhonePageModule", function() { return UpPhonePageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _up_phone_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./up-phone.page */ "./src/app/Modal/up-phone/up-phone.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};





var UpPhonePageModule = /** @class */ (function () {
    function UpPhonePageModule() {
    }
    UpPhonePageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["ReactiveFormsModule"],
            ],
            declarations: [_up_phone_page__WEBPACK_IMPORTED_MODULE_4__["UpPhonePage"]],
            entryComponents: [
                _up_phone_page__WEBPACK_IMPORTED_MODULE_4__["UpPhonePage"]
            ]
        })
    ], UpPhonePageModule);
    return UpPhonePageModule;
}());



/***/ }),

/***/ "./src/app/Modal/up-phone/up-phone.page.html":
/*!***************************************************!*\
  !*** ./src/app/Modal/up-phone/up-phone.page.html ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n      <ion-button (click)=\"close()\">\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n    <ion-title>Modifier mon numéro de télephone</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content padding>\n  <form [formGroup]=\"authForm\" >\n\n    <ion-item>\n      <ion-label><ion-icon name=\"call\"></ion-icon>&nbsp;<ion-icon name=\"add\"></ion-icon></ion-label>\n      <ion-input placeholder=\"Ancien numéro (ex : 33123456789)\" type=\"text\" formControlName=\"phoneNumber\" clearInput></ion-input>\n    </ion-item>\n    <ion-item>\n        <ion-label><ion-icon ios=\"ios-mail\" md=\"md-mail\"></ion-icon></ion-label>\n          <ion-input placeholder=\"Email\" type=\"email\" formControlName=\"email\" clearInput></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label><ion-icon ios=\"ios-unlock\" md=\"md-unlock\"></ion-icon></ion-label>\n      <ion-input minlength=\"6\" [formControl]=\"password\" id=\"password\" type=\"{{passwordtype}}\" required placeholder=\"Mot de passe\"></ion-input>\n      <button ion-button fill=\"clear\" class=\"eye-icon-btn buttoneye\" type=\"button\" item-right (click)=\"managePassword()\">\n        <ion-icon name=\"{{passeye}}\"></ion-icon></button>\n    </ion-item>\n      <div id=\"recaptcha-container\" ></div>\n      <ion-item>\n        <ion-label><ion-icon name=\"call\"></ion-icon>&nbsp;<ion-icon name=\"add\"></ion-icon></ion-label>\n        <ion-input placeholder=\"Nouveau numéro (ex : 33123456789)\" type=\"text\" formControlName=\"NewphoneNumber\" clearInput></ion-input>\n      </ion-item>\n  </form>\n</ion-content>\n<ion-toolbar color=\"primary\">\n  <ion-button expand=\"block\" type=\"submit\" (click)=\"ionViewDidLoad(); onSubmitForm()\">Modifier mon numéro de télephone</ion-button>\n</ion-toolbar>"

/***/ }),

/***/ "./src/app/Modal/up-phone/up-phone.page.scss":
/*!***************************************************!*\
  !*** ./src/app/Modal/up-phone/up-phone.page.scss ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .faux {\n  color: red; }\n\n:host .eye-icon-btn {\n  background-color: transparent !important;\n  color: black;\n  font-size: 2.2rem !important; }\n\n:host .buttoneye {\n  color: #333986 !important;\n  background: none !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvTW9kYWwvdXAtcGhvbmUvQzpcXFVzZXJzXFxJcmlzIEdlcmFsZG9cXERvY3VtZW50c1xcT3V0YWxtYWZpblxcT3V0YWxtYS9zcmNcXGFwcFxcTW9kYWxcXHVwLXBob25lXFx1cC1waG9uZS5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFFTyxVQUNILEVBQUE7O0FBSEo7RUFNUSx3Q0FBd0M7RUFDeEMsWUFBWTtFQUNaLDRCQUE0QixFQUFBOztBQVJwQztFQVdRLHlCQUEyQjtFQUMzQiwyQkFBNEIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL01vZGFsL3VwLXBob25lL3VwLXBob25lLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0e1xyXG4gICAgLmZhdXh7XHJcbiAgICAgICBjb2xvcjpyZWRcclxuICAgIH1cclxuXHJcbiAgICAuZXllLWljb24tYnRue1xyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgY29sb3I6IGJsYWNrO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMi4ycmVtICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcbiAgICAuYnV0dG9uZXlle1xyXG4gICAgICAgIGNvbG9yIDogICMzMzM5ODYgIWltcG9ydGFudDtcclxuICAgICAgICBiYWNrZ3JvdW5kOiAgbm9uZSAhaW1wb3J0YW50O1xyXG4gICAgICB9XHJcbn0iXX0= */"

/***/ }),

/***/ "./src/app/Modal/up-phone/up-phone.page.ts":
/*!*************************************************!*\
  !*** ./src/app/Modal/up-phone/up-phone.page.ts ***!
  \*************************************************/
/*! exports provided: UpPhonePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UpPhonePage", function() { return UpPhonePage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var src_Services_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/Services/auth.service */ "./src/Services/auth.service.ts");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_5__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};






var UpPhonePage = /** @class */ (function () {
    function UpPhonePage(modalCtrl, actionSheetController, authService, navCtrl, toastCtrl, menuCtrl, formBuilder, alertCtrl) {
        this.modalCtrl = modalCtrl;
        this.actionSheetController = actionSheetController;
        this.authService = authService;
        this.navCtrl = navCtrl;
        this.toastCtrl = toastCtrl;
        this.menuCtrl = menuCtrl;
        this.formBuilder = formBuilder;
        this.alertCtrl = alertCtrl;
        this.VigiK = "";
        this.passwordtype = 'password';
        this.passeye = 'eye';
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_3__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        this.VigiK = VigiK;
    }
    UpPhonePage.prototype.onSubmitForm = function () {
        var _this = this;
        var presentToastBravo = this.presentToastBravo;
        var toast = this.toastCtrl;
        var presentToast = this.presentToast;
        var num = this.authForm.get('phoneNumber').value;
        var num2 = this.authForm.get('NewphoneNumber').value;
        var email2 = num + '@fakeMail.ou';
        var email = this.authForm.get('email').value;
        var password = this.authForm.get('password').value;
        var writeUser = this.writeUserData;
        var nav = this.navCtrl;
        var str = num2;
        var ret = "";
        if (this.authForm.get('phoneNumber').valid != true || this.authForm.get('NewphoneNumber').valid != true || num2 == null || num == null) {
            var err = { code: "Input erronés", message: "" };
            presentToast(err, toast);
        }
        else {
            for (var i = 0; i < str.length; i++) {
                if (i >= str.length - 3) {
                    ret += str.charAt(i);
                }
                else {
                    ret += "x";
                }
            }
            if (email == null) {
                email = email2;
            }
            this.authService.signInUser(email, password).then(function (result) {
                console.log('result >>', result, email);
                _this.UpdatePhone(writeUser, ret, toast, presentToastBravo, presentToast).then(function () {
                });
            }, function (err) { return __awaiter(_this, void 0, void 0, function () {
                return __generator(this, function (_a) {
                    presentToast(err, toast);
                    firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().signOut();
                    this.recaptchaVerifier.clear();
                    return [2 /*return*/];
                });
            }); });
        }
    };
    UpPhonePage.prototype.UpdatePhone = function (writeUser, ret, toast, presentToastBravo, presentToast) {
        return __awaiter(this, void 0, void 0, function () {
            var num, email, Newemail_1, phoneNumber, appVerifier_1, provider;
            var _this = this;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (!(firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.phoneNumber == "+" + this.authForm.get('phoneNumber').value)) return [3 /*break*/, 1];
                        num = this.authForm.get('NewphoneNumber').value;
                        email = this.authForm.get('email').value;
                        Newemail_1 = num + '@fakeMail.ou';
                        phoneNumber = '+' + num;
                        appVerifier_1 = this.recaptchaVerifier;
                        provider = new firebase__WEBPACK_IMPORTED_MODULE_3__["auth"].PhoneAuthProvider();
                        provider.verifyPhoneNumber(phoneNumber, appVerifier_1)
                            .then(function (confirmationResult) { return __awaiter(_this, void 0, void 0, function () {
                            var prompt;
                            return __generator(this, function (_a) {
                                switch (_a.label) {
                                    case 0: return [4 /*yield*/, this.alertCtrl.create({
                                            header: 'Un code de confimation a été envoyé au : ' + '+' + ret,
                                            inputs: [{ name: 'confirmationCode', placeholder: 'Entrez le code de confirmation' }],
                                            buttons: [
                                                {
                                                    text: 'Annuler',
                                                    handler: function (data) {
                                                        appVerifier_1.clear();
                                                    }
                                                },
                                                {
                                                    text: 'Valider',
                                                    handler: function (data) {
                                                        var verificationCode = data.confirmationCode;
                                                        var credential = firebase__WEBPACK_IMPORTED_MODULE_3__["auth"].PhoneAuthProvider.credential(confirmationResult, verificationCode);
                                                        firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.updatePhoneNumber(credential)
                                                            .then((function () {
                                                            if (email == "") {
                                                                firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.updateEmail(Newemail_1).then(function () {
                                                                    writeUser();
                                                                });
                                                                presentToastBravo(toast);
                                                            }
                                                            else {
                                                                writeUser();
                                                            }
                                                        }));
                                                        return firebase__WEBPACK_IMPORTED_MODULE_3__["auth"].PhoneAuthProvider.credential(confirmationResult, verificationCode);
                                                    }
                                                }
                                            ]
                                        })];
                                    case 1:
                                        prompt = _a.sent();
                                        prompt.present();
                                        return [2 /*return*/];
                                }
                            });
                        }); })
                            .catch(function (error) {
                            this.recaptchaVerifier.clear();
                            presentToast(error, toast);
                        });
                        return [3 /*break*/, 3];
                    case 1:
                        this.recaptchaVerifier.clear();
                        return [4 /*yield*/, this.toastCtrl.create({
                                message: "Une erreur est survenu, veuillez vérifier vos informations ou contacter le service client si le problème persiste",
                                duration: 10000,
                                position: 'middle',
                                color: 'danger',
                                showCloseButton: true,
                                closeButtonText: 'FERMER'
                            })];
                    case 2:
                        _a.sent();
                        _a.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    UpPhonePage.prototype.writeUserData = function () {
        firebase__WEBPACK_IMPORTED_MODULE_3__["database"]().ref('user/' + firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.uid).set([
            {
                email: crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.email.trim(), this.VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8),
                emailVerified: firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.emailVerified,
                phoneNumber: crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.phoneNumber.trim(), this.VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8),
                displayName: crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.displayName.trim(), this.VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8),
                date_naiss: crypto_js__WEBPACK_IMPORTED_MODULE_5__["AES"].decrypt(firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.photoURL.trim(), this.VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_5__["enc"].Utf8),
                désativé: false
            }
        ]).then(function (snapshot) {
        }, function (error) {
        });
        ;
    };
    UpPhonePage.prototype.ngOnInit = function () {
        var _this = this;
        firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().languageCode = 'fr';
        this.initForm();
        firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().onAuthStateChanged(function (user) {
            if (user) {
                _this.isAuth = false;
            }
            else {
                _this.isAuth = false;
                _this.navCtrl.navigateForward('');
            }
        });
    };
    UpPhonePage.prototype.close = function () {
        this.modalCtrl.dismiss();
    };
    UpPhonePage.prototype.managePassword = function () {
        if (this.passwordtype == 'password') {
            this.passwordtype = 'text';
            this.passeye = 'eye-off';
        }
        else {
            this.passwordtype = 'password';
            this.passeye = 'eye';
        }
    };
    UpPhonePage.prototype.presentToast = function (err, toast) {
        return __awaiter(this, void 0, void 0, function () {
            var tooast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        if (err.code == "auth/provider-already-linked") {
                            err.message = "Cet utilisateur existe déjà.";
                        }
                        else if (err.code == "auth/argument-error") {
                            err.message = "Veuillez vérifier les paramètres du formulaire.";
                        }
                        else if (err.code == "auth/network-request-failed") {
                            err.message = "Veuillez vérifier vos paramètres réseau.";
                        }
                        else if (err.code == "auth/too-many-request") {
                            err.message = "Les demandes de votre périphérique sont bloquées en raison d'activités inhabituelles. Veuillez réessayer plus tard.";
                        }
                        else if (err.code == "auth/invalid-email") {
                            err.message = "L'email est invalide.";
                        }
                        else if (err.code == "auth/invalid-phone-number") {
                            err.message = "Le format du numéro de téléphone est invalide.";
                        }
                        else if (err.code == "auth/wrong-password") {
                            err.message = "Le mot de passe est invalide.";
                        }
                        else if (err.code == "auth/user-disabled") {
                            err.message = "Le compte a été désactivé par un administrateur. Veuillez contacter le service client.";
                        }
                        else if (err.code == "auth/weak-password") {
                            err.message = "Le mot de passe doit contenir 6 caractères.";
                        }
                        else if (err.code == "Input erronés") {
                            err.message = "Veuillez vérifier les valeurs entrées.";
                        }
                        else {
                            err.message = "Un problème est survenu. Veuillez contacter le service client.";
                        }
                        return [4 /*yield*/, toast.create({
                                message: err.message,
                                duration: 10000,
                                position: 'middle',
                                color: 'danger',
                                showCloseButton: true,
                                closeButtonText: 'FERMER'
                            })];
                    case 1:
                        tooast = _a.sent();
                        tooast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    UpPhonePage.prototype.presentToastMdp = function () {
        return __awaiter(this, void 0, void 0, function () {
            var toast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Les mots de passe ne sont pas identiques.',
                            duration: 10000,
                            position: 'middle',
                            color: 'danger',
                            showCloseButton: true,
                            closeButtonText: 'FERMER'
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    UpPhonePage.prototype.presentToastBravo = function (toast) {
        return __awaiter(this, void 0, void 0, function () {
            var tooast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, toast.create({
                            message: 'Bien enregistré',
                            duration: 3000,
                            position: 'middle',
                            color: 'success'
                        })];
                    case 1:
                        tooast = _a.sent();
                        tooast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    UpPhonePage.prototype.ionViewDidLoad = function () {
        this.recaptchaVerifier = new firebase__WEBPACK_IMPORTED_MODULE_3__["auth"].RecaptchaVerifier('recaptcha-container', {
            // 'size': 'invisible',
            'callback': function (response) {
                // reCAPTCHA solved - will proceed with submit function
                return true;
            },
            'expired-callback': function () {
                // Reset reCAPTCHA?
            }
        });
    };
    UpPhonePage.prototype.initForm = function () {
        this.authForm = this.formBuilder.group({
            'userName': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            'email': [null],
            'password': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            'phoneNumber': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
            'NewphoneNumber': [null, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])],
        });
        this.email = this.authForm.controls['email'];
        this.password = this.authForm.controls['password'];
        this.phoneNumber = this.authForm.controls['phoneNumber'];
        this.NewphoneNumber = this.authForm.controls['NewphoneNumber'];
    };
    UpPhonePage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-up-phone',
            template: __webpack_require__(/*! ./up-phone.page.html */ "./src/app/Modal/up-phone/up-phone.page.html"),
            styles: [__webpack_require__(/*! ./up-phone.page.scss */ "./src/app/Modal/up-phone/up-phone.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ActionSheetController"],
            src_Services_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ToastController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["MenuController"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["AlertController"]])
    ], UpPhonePage);
    return UpPhonePage;
}());



/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};


var routes = [
    { path: 'tabs', loadChildren: './tabs/tabs.module#TabsPageModule' },
    { path: 'satisfaction-form', loadChildren: './Modal/satisfaction-form/satisfaction-form.module#SatisfactionFormPageModule' },
    { path: 'tableau-suivi', loadChildren: './tableau-suivi/tableau-suivi.module#TableauSuiviPageModule' },
    { path: '', loadChildren: './login/login.module#LoginPageModule' },
    { path: 'facture-pdf', loadChildren: './Modal/facture-pdf/facture-pdf.module#FacturePDFPageModule' },
];
var AppRoutingModule = /** @class */ (function () {
    function AppRoutingModule() {
    }
    AppRoutingModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_1__["PreloadAllModules"] })
            ],
            exports: [_angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"]]
        })
    ], AppRoutingModule);
    return AppRoutingModule;
}());



/***/ }),

/***/ "./src/app/app.component.html":
/*!************************************!*\
  !*** ./src/app/app.component.html ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n    <ion-app>\n      \n\n\n    <ion-split-pane color=\"primary\">\n      <ion-menu disable><ion-content>\n          <div (click)=\"goToProfil()\" class=\"profile\" padding  >\n              <ion-button clear mode=\"ios\" size=\"small\"><ion-icon name=\"create\" size=\"large\" color=\"light\" mode=\"md\" slot=\"end\"></ion-icon></ion-button>\n              <!-- <ion-avatar class=\"md\" text-center >\n                <img [src]=\"'assets/img/noavatar.png'\">\n              </ion-avatar> -->\n              <!-- <div id=\"cercle\" text-center> <ion-label color=\"light\"><br><br>IG</ion-label></div> -->\n              <div class=\"avatar-circle\">\n                  <span class=\"initials\">{{lettre}}</span>\n                </div>\n              <h5 text-center>{{nomUser}}</h5>\n            </div>\n<br>\n        \n              <ion-list lines=\"none\" class=\"itlist\">\n            <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages\">\n              <ion-item [routerDirection]=\"'root'\" [routerLink]=\"[p.url]\">\n                 <ion-icon slot=\"start\" color=\"medium\" [name]=\"p.icon\"></ion-icon>\n                <ion-label>\n                  {{p.title}}\n                </ion-label>\n                \n              </ion-item>\n              <hr>\n            </ion-menu-toggle>\n          </ion-list>\n        </ion-content>\n        <ion-footer>\n            <ion-toolbar color=\"primary\">\n              <ion-buttons slot=\"start\">\n                <ion-button (click)=\"logOut()\">\n                  <ion-icon name=\"log-out\" slot=\"start\"></ion-icon>\n                  Logout\n                </ion-button>\n              </ion-buttons>\n            </ion-toolbar>\n          </ion-footer>\n      </ion-menu>\n      <ion-router-outlet main></ion-router-outlet>\n    </ion-split-pane>\n    \n  </ion-app>"

/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "@charset \"UTF-8\";\n.tab-button-item-active {\n  color: #454EB2; }\n.color-white {\n  color: white; }\n.tab-btn-selected, .tab-btn:hover {\n  color: var(–color-selected); }\nhr {\n  height: 3px !important;\n  width: 100% !important;\n  background: #ABB1B6 !important;\n  display: block !important;\n  font-size: 2em !important;\n  opacity: 1 !important;\n  visibility: visible !important; }\n.bg-dark-blue {\n  background-color: #333986 !important; }\n.outalma-title {\n  color: white;\n  float: left;\n  margin-left: -2vh;\n  margin-top: 1vh; }\n.logo {\n  height: 5vh;\n  margin-left: -4vh;\n  float: left;\n  overflow: hidden; }\n.choix {\n  height: 5vh;\n  margin-bottom: 5vh; }\n:host ion-split-pane.split-pane-visible > .split-pane-side {\n  max-width: 270px !important; }\n:host .avatar-circle {\n  width: 100px;\n  height: 100px;\n  background-color: black;\n  text-align: center;\n  border-radius: 50%;\n  -webkit-border-radius: 50%;\n  -moz-border-radius: 50%;\n  margin-left: auto;\n  margin-right: auto; }\n:host .initials {\n  position: relative;\n  top: 25px;\n  /* 25% of parent */\n  font-size: 50px;\n  /* 50% of parent */\n  line-height: 50px;\n  /* 50% of parent */\n  color: #fff;\n  font-family: \"Courier New\", monospace;\n  font-weight: bold; }\n:host ion-menu .profile {\n  background: var(--ion-color-primary); }\n:host ion-menu .profile ion-avatar {\n    width: 84px;\n    height: 84px;\n    margin: 0 auto; }\n:host ion-menu .profile h5, :host ion-menu .profile p {\n    color: #fff; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9DOlxcVXNlcnNcXElyaXMgR2VyYWxkb1xcRG9jdW1lbnRzXFxPdXRhbG1hZmluXFxPdXRhbG1hL3NyY1xcYXBwXFxhcHAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FDQWhCO0VBQ0ksY0FBYyxFQUFBO0FBTWhCO0VBQ0ksWUFBWSxFQUFBO0FBRWhCO0VBQ0UsMkJBQU8sRUFBcUI7QUFJaEM7RUFFRSxzQkFBc0I7RUFDdEIsc0JBQXNCO0VBQ3RCLDhCQUE4QjtFQUM5Qix5QkFBeUI7RUFDekIseUJBQXlCO0VBQ3pCLHFCQUFxQjtFQUNyQiw4QkFBOEIsRUFBQTtBQUVoQztFQUNFLG9DQUFvQyxFQUFBO0FBS3RDO0VBQ0UsWUFBWTtFQUNaLFdBQVU7RUFDVixpQkFBaUI7RUFDakIsZUFBZSxFQUFBO0FBR2pCO0VBQ0UsV0FBVztFQUNYLGlCQUFnQjtFQUNoQixXQUFVO0VBQ1YsZ0JBQWdCLEVBQUE7QUFHbEI7RUFDRSxXQUFVO0VBQ1Ysa0JBQWlCLEVBQUE7QUFHbkI7RUFFSSwyQkFBMkIsRUFBQTtBQUYvQjtFQU1JLFlBQVk7RUFDWixhQUFhO0VBQ2IsdUJBQXVCO0VBQ3ZCLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsMEJBQTBCO0VBQzFCLHVCQUF1QjtFQUN2QixpQkFBaUI7RUFDakIsa0JBQWtCLEVBQUE7QUFkdEI7RUFrQkksa0JBQWtCO0VBQ2xCLFNBQVM7RUFBRSxrQkFBQTtFQUNYLGVBQWU7RUFBRSxrQkFBQTtFQUNqQixpQkFBaUI7RUFBRSxrQkFBQTtFQUNuQixXQUFXO0VBQ1gscUNBQXFDO0VBQ3JDLGlCQUFpQixFQUFBO0FBeEJyQjtFQWtDTSxvQ0FBb0MsRUFBQTtBQWxDMUM7SUFxQ1EsV0FBVztJQUNYLFlBQVk7SUFDWixjQUFjLEVBQUE7QUF2Q3RCO0lBMkNRLFdBQVcsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBjaGFyc2V0IFwiVVRGLThcIjtcbi50YWItYnV0dG9uLWl0ZW0tYWN0aXZlIHtcbiAgY29sb3I6ICM0NTRFQjI7IH1cblxuLmNvbG9yLXdoaXRlIHtcbiAgY29sb3I6IHdoaXRlOyB9XG5cbi50YWItYnRuLXNlbGVjdGVkLCAudGFiLWJ0bjpob3ZlciB7XG4gIGNvbG9yOiB2YXIo4oCTY29sb3Itc2VsZWN0ZWQpOyB9XG5cbmhyIHtcbiAgaGVpZ2h0OiAzcHggIWltcG9ydGFudDtcbiAgd2lkdGg6IDEwMCUgIWltcG9ydGFudDtcbiAgYmFja2dyb3VuZDogI0FCQjFCNiAhaW1wb3J0YW50O1xuICBkaXNwbGF5OiBibG9jayAhaW1wb3J0YW50O1xuICBmb250LXNpemU6IDJlbSAhaW1wb3J0YW50O1xuICBvcGFjaXR5OiAxICFpbXBvcnRhbnQ7XG4gIHZpc2liaWxpdHk6IHZpc2libGUgIWltcG9ydGFudDsgfVxuXG4uYmctZGFyay1ibHVlIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzMzMzk4NiAhaW1wb3J0YW50OyB9XG5cbi5vdXRhbG1hLXRpdGxlIHtcbiAgY29sb3I6IHdoaXRlO1xuICBmbG9hdDogbGVmdDtcbiAgbWFyZ2luLWxlZnQ6IC0ydmg7XG4gIG1hcmdpbi10b3A6IDF2aDsgfVxuXG4ubG9nbyB7XG4gIGhlaWdodDogNXZoO1xuICBtYXJnaW4tbGVmdDogLTR2aDtcbiAgZmxvYXQ6IGxlZnQ7XG4gIG92ZXJmbG93OiBoaWRkZW47IH1cblxuLmNob2l4IHtcbiAgaGVpZ2h0OiA1dmg7XG4gIG1hcmdpbi1ib3R0b206IDV2aDsgfVxuXG46aG9zdCBpb24tc3BsaXQtcGFuZS5zcGxpdC1wYW5lLXZpc2libGUgPiAuc3BsaXQtcGFuZS1zaWRlIHtcbiAgbWF4LXdpZHRoOiAyNzBweCAhaW1wb3J0YW50OyB9XG5cbjpob3N0IC5hdmF0YXItY2lyY2xlIHtcbiAgd2lkdGg6IDEwMHB4O1xuICBoZWlnaHQ6IDEwMHB4O1xuICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG4gIC13ZWJraXQtYm9yZGVyLXJhZGl1czogNTAlO1xuICAtbW96LWJvcmRlci1yYWRpdXM6IDUwJTtcbiAgbWFyZ2luLWxlZnQ6IGF1dG87XG4gIG1hcmdpbi1yaWdodDogYXV0bzsgfVxuXG46aG9zdCAuaW5pdGlhbHMge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogMjVweDtcbiAgLyogMjUlIG9mIHBhcmVudCAqL1xuICBmb250LXNpemU6IDUwcHg7XG4gIC8qIDUwJSBvZiBwYXJlbnQgKi9cbiAgbGluZS1oZWlnaHQ6IDUwcHg7XG4gIC8qIDUwJSBvZiBwYXJlbnQgKi9cbiAgY29sb3I6ICNmZmY7XG4gIGZvbnQtZmFtaWx5OiBcIkNvdXJpZXIgTmV3XCIsIG1vbm9zcGFjZTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7IH1cblxuOmhvc3QgaW9uLW1lbnUgLnByb2ZpbGUge1xuICBiYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSk7IH1cbiAgOmhvc3QgaW9uLW1lbnUgLnByb2ZpbGUgaW9uLWF2YXRhciB7XG4gICAgd2lkdGg6IDg0cHg7XG4gICAgaGVpZ2h0OiA4NHB4O1xuICAgIG1hcmdpbjogMCBhdXRvOyB9XG4gIDpob3N0IGlvbi1tZW51IC5wcm9maWxlIGg1LCA6aG9zdCBpb24tbWVudSAucHJvZmlsZSBwIHtcbiAgICBjb2xvcjogI2ZmZjsgfVxuIiwiLnRhYi1idXR0b24taXRlbS1hY3RpdmV7XG4gICAgY29sb3I6ICM0NTRFQjI7XG4gIH1cblxuLy8gICAuYWN0aXZhdGVkIHtcbi8vICAgICBiYWNrZ3JvdW5kLWNvbG9yOiBncmVlbjtcbi8vICB9ICBcbiAgLmNvbG9yLXdoaXRle1xuICAgICAgY29sb3I6IHdoaXRlO1xuICB9XG4gIC50YWItYnRuLXNlbGVjdGVkLCAudGFiLWJ0bjpob3ZlciB7XG4gICAgY29sb3I6IHZhcijigJNjb2xvci1zZWxlY3RlZCk7XG4gICAgfVxuXG4gICAgXG5ociB7XG4gIC8vYm9yZGVyOiAycHggc29saWQgcmVkICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogM3B4ICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6ICNBQkIxQjYgIWltcG9ydGFudDtcbiAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAyZW0gIWltcG9ydGFudDtcbiAgb3BhY2l0eTogMSAhaW1wb3J0YW50O1xuICB2aXNpYmlsaXR5OiB2aXNpYmxlICFpbXBvcnRhbnQ7XG59XG4uYmctZGFyay1ibHVle1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzMzOTg2ICFpbXBvcnRhbnQ7XG4gIC8vIHBhZGRpbmctdG9wOiAydmg7XG4gIC8vIHBhZGRpbmctYm90dG9tOiAydmg7XG59XG5cbi5vdXRhbG1hLXRpdGxle1xuICBjb2xvcjogd2hpdGU7XG4gIGZsb2F0OmxlZnQ7XG4gIG1hcmdpbi1sZWZ0OiAtMnZoO1xuICBtYXJnaW4tdG9wOiAxdmg7XG59XG5cbi5sb2dvIHtcbiAgaGVpZ2h0OiA1dmg7XG4gIG1hcmdpbi1sZWZ0Oi00dmg7XG4gIGZsb2F0OmxlZnQ7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG5cbi5jaG9peCB7XG4gIGhlaWdodDo1dmg7XG4gIG1hcmdpbi1ib3R0b206NXZoO1xufVxuXG46aG9zdCB7XG4gIGlvbi1zcGxpdC1wYW5lLnNwbGl0LXBhbmUtdmlzaWJsZSA+IC5zcGxpdC1wYW5lLXNpZGUge1xuICAgIG1heC13aWR0aDogMjcwcHggIWltcG9ydGFudDtcbiAgfVxuXG4gIC5hdmF0YXItY2lyY2xlIHtcbiAgICB3aWR0aDogMTAwcHg7XG4gICAgaGVpZ2h0OiAxMDBweDtcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiBibGFjaztcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gICAgYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIC13ZWJraXQtYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIC1tb3otYm9yZGVyLXJhZGl1czogNTAlO1xuICAgIG1hcmdpbi1sZWZ0OiBhdXRvO1xuICAgIG1hcmdpbi1yaWdodDogYXV0bztcbiAgfVxuICBcbiAgLmluaXRpYWxzIHtcbiAgICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gICAgdG9wOiAyNXB4OyAvKiAyNSUgb2YgcGFyZW50ICovXG4gICAgZm9udC1zaXplOiA1MHB4OyAvKiA1MCUgb2YgcGFyZW50ICovXG4gICAgbGluZS1oZWlnaHQ6IDUwcHg7IC8qIDUwJSBvZiBwYXJlbnQgKi9cbiAgICBjb2xvcjogI2ZmZjtcbiAgICBmb250LWZhbWlseTogXCJDb3VyaWVyIE5ld1wiLCBtb25vc3BhY2U7XG4gICAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIH1cbiAgXG4gIFxuICBcbiAgXG5cblxuICBpb24tbWVudSB7XG4gICAgLnByb2ZpbGUge1xuICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpO1xuICAgIFxuICAgICAgaW9uLWF2YXRhciB7XG4gICAgICAgIHdpZHRoOiA4NHB4O1xuICAgICAgICBoZWlnaHQ6IDg0cHg7XG4gICAgICAgIG1hcmdpbjogMCBhdXRvO1xuICAgICAgfVxuICAgIFxuICAgICAgaDUsIHAge1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICAgIH1cbiAgICB9XG4gIH1cbn0iXX0= */"

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _Modal_profil_profil_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./Modal/profil/profil.page */ "./src/app/Modal/profil/profil.page.ts");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_6__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};









var connex = 0;
var AppComponent = /** @class */ (function () {
    function AppComponent(platform, splashScreen, statusBar, router, modalCtrl, navCtrl, menuCtrl) {
        var _this = this;
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.router = router;
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.menuCtrl = menuCtrl;
        this.nomUser = "Inconnu";
        this.lettre = "";
        //  authPage:any = LoginPage;
        // @ViewChild('content') content: NavController;
        this.appPages = [];
        platform.ready().then(function () {
            statusBar.styleDefault();
            splashScreen.hide();
            var config = {
                apiKey: "AIzaSyDoJ_MiRjaw4pG6BLuG1Ri-JJZlvXSAjNU",
                authDomain: "outalma-suivi.firebaseapp.com",
                databaseURL: "https://outalma-suivi.firebaseio.com",
                projectId: "outalma-suivi",
                storageBucket: "outalma-suivi.appspot.com",
                messagingSenderId: "13060033088"
            };
            firebase__WEBPACK_IMPORTED_MODULE_6__["initializeApp"](config);
            var connectedRef = firebase__WEBPACK_IMPORTED_MODULE_6__["database"]().ref(".info/connected");
            if (connex != 0) {
                connectedRef.on("value", function (snap) {
                    if (snap.val() === true) {
                        console.log('en connexion');
                    }
                    else {
                        alert("Vous êtes actuellement hors connexion.\nLes informations ne sont pas à jour.\nNéanmoins, toutes les fonctionnalités restent disponibles et vos actions seront enregistrées lorsque vous vous reconnecterez à un réseau.");
                    }
                });
            }
            else {
                connex = 1;
                console.log('Init');
            }
            _this.refreshPage();
            firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().onAuthStateChanged(function (user) {
                if (user) {
                    _this.nomUser = firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().currentUser.displayName;
                    var email = firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().currentUser.email;
                    _this.lettre = _this.nomUser.charAt(0);
                    console.log(_this.lettre, "rien");
                    if (email.includes("@outalma.com")) {
                        _this.appPages = [
                            {
                                title: 'Commandes',
                                url: '/tabs/tabs/tableau-suivi',
                                icon: 'list-box'
                            },
                            {
                                title: 'Service Client',
                                url: '/tabs/tabs/message2',
                                icon: 'chatbubbles'
                            },
                            {
                                title: 'Faire une demande',
                                url: '/tabs/tabs/forms',
                                icon: 'add-circle-outline'
                            }
                        ];
                    }
                    else {
                        _this.appPages = [
                            {
                                title: 'Suivi',
                                url: '/tabs/tabs/suivi',
                                icon: 'cube'
                            },
                            {
                                title: 'Service Client',
                                url: '/tabs/tabs/message3',
                                icon: 'chatbubbles'
                            },
                            {
                                title: 'Faire une demande',
                                url: '/tabs/tabs/forms',
                                icon: 'add-circle-outline'
                            }
                        ];
                    }
                    // this.isAuth = true;
                    // this.navCtrl.navigateForward('tabs/tabs/suivi');
                }
                else {
                    _this.isAuth = false;
                    _this.navCtrl.navigateForward('');
                }
            });
        });
    }
    AppComponent.prototype.refreshPage = function () {
        var _this = this;
        setTimeout(function () {
            _this.cooling();
        }, 4000);
    };
    AppComponent.prototype.cooling = function () {
        var _this = this;
        setTimeout(function () {
            setTimeout(function () {
                if (firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().currentUser.uid != null) {
                    console.log(_this.nomUser, "nthisomUser");
                    _this.nomUser = firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().currentUser.displayName;
                    var email = firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().currentUser.email;
                    _this.lettre = _this.nomUser.charAt(0);
                    console.log(_this.lettre, "rien");
                    if (email.includes("@outalma.com")) {
                        _this.appPages = [
                            {
                                title: 'Commandes',
                                url: '/tabs/tabs/tableau-suivi',
                                icon: 'list-box'
                            },
                            {
                                title: 'Service Client',
                                url: '/tabs/tabs/message2',
                                icon: 'chatbubbles'
                            },
                            {
                                title: 'Faire une demande',
                                url: '/tabs/tabs/forms',
                                icon: 'add-circle-outline'
                            }
                        ];
                    }
                    else {
                        _this.appPages = [
                            {
                                title: 'Suivi',
                                url: '/tabs/tabs/suivi',
                                icon: 'cube'
                            },
                            {
                                title: 'Service Client',
                                url: '/tabs/tabs/message3',
                                icon: 'chatbubbles'
                            },
                            {
                                title: 'Faire une demande',
                                url: '/tabs/tabs/forms',
                                icon: 'add-circle-outline'
                            }
                        ];
                    }
                }
                else {
                    _this.isAuth = false;
                    _this.navCtrl.navigateForward('');
                }
            }, 4000);
            _this.refreshPage();
        }, 4000);
    };
    AppComponent.prototype.ngOnInit = function () {
        console.log(this.nomUser, "nthisomUser");
        this.refreshPage();
        console.log('heihiehziaeh');
        this.Voirdonnees();
    };
    AppComponent.prototype.goToProfil = function () {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _Modal_profil_profil_page__WEBPACK_IMPORTED_MODULE_5__["ProfilPage"],
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.present();
                        console.log("jeld,");
                        return [2 /*return*/];
                }
            });
        });
    };
    AppComponent.prototype.doRefresh = function (event) {
        console.log('Go to Reload');
        setTimeout(function () {
            console.log('Async operation has ended');
            event.target.complete();
        }, 2000);
    };
    AppComponent.prototype.logOut = function () {
        firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().signOut();
        this.isAuth = false;
        this.navCtrl.navigateForward('');
        this.menuCtrl.enable(false);
    };
    AppComponent.prototype.Voirdonnees = function () {
        var InTabDemandes = [];
        firebase__WEBPACK_IMPORTED_MODULE_6__["database"]().ref('/user/' + firebase__WEBPACK_IMPORTED_MODULE_6__["auth"]().currentUser.uid + "/").on("value", function (snapshot) {
            var suivibdd = snapshot.val();
            suivibdd.forEach(function (entry) {
                InTabDemandes.push(entry);
            });
        }, function (error) {
            console.log("Error dans VoirDonnees: " + error.code);
        });
        this.info = InTabDemandes;
        console.log("voir taba = ", this.info);
        this.nomUser = this.info['0']['Anom'] + ' ' + this.info['0']['Prenom'];
    };
    AppComponent.prototype.onNavigate = function (page, data) {
        this.router.navigateByUrl(page, data ? data : null);
    };
    AppComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-root',
            template: __webpack_require__(/*! ./app.component.html */ "./src/app/app.component.html"),
            styles: [__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_1__["Platform"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__["SplashScreen"],
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__["StatusBar"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["ModalController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["NavController"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_1__["MenuController"]])
    ], AppComponent);
    return AppComponent;
}());



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/ngx/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _Modal_profil_profil_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./Modal/profil/profil.module */ "./src/app/Modal/profil/profil.module.ts");
/* harmony import */ var src_Services_auth_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! src/Services/auth.service */ "./src/Services/auth.service.ts");
/* harmony import */ var _phone_login_phone_login_component__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./phone-login/phone-login.component */ "./src/app/phone-login/phone-login.component.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};












var AppModule = /** @class */ (function () {
    function AppModule() {
    }
    AppModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            declarations: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"], _phone_login_phone_login_component__WEBPACK_IMPORTED_MODULE_11__["PhoneLoginComponent"]],
            entryComponents: [],
            imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_7__["AppRoutingModule"], _Modal_profil_profil_module__WEBPACK_IMPORTED_MODULE_9__["ProfilPageModule"], _angular_common__WEBPACK_IMPORTED_MODULE_6__["CommonModule"]],
            providers: [
                _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_5__["StatusBar"],
                _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_4__["SplashScreen"],
                src_Services_auth_service__WEBPACK_IMPORTED_MODULE_10__["AuthService"],
                { provide: _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicRouteStrategy"] }
            ],
            bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
        })
    ], AppModule);
    return AppModule;
}());



/***/ }),

/***/ "./src/app/phone-login/phone-login.component.html":
/*!********************************************************!*\
  !*** ./src/app/phone-login/phone-login.component.html ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content padding>\n  <!-- <div [hidden]=\"user\">\n    <h1>Sign In with Your Phone Number</h1>\n  \n    <label for=\"phone\">Phone Number</label><br>\n    <input type=\"text\" [(ngModel)]=\"phoneNumber.country\"  class=\"input\" placeholder=\"1\"    maxlength=\"2\">\n    <input type=\"text\" [(ngModel)]=\"phoneNumber.area\"     class=\"input\" placeholder=\"949\"  maxlength=\"3\">\n    <input type=\"text\" [(ngModel)]=\"phoneNumber.prefix\"   class=\"input\" placeholder=\"555\"  maxlength=\"3\">\n    <input type=\"text\" [(ngModel)]=\"phoneNumber.line\"     class=\"input\" placeholder=\"5555\" maxlength=\"4\">\n  \n    <div id=\"recaptcha-container\"></div>\n  \n    <button (click)=\"sendLoginCode()\">SMS Text Login Code</button>\n  \n    <div *ngIf=\"windowRef.confirmationResult\">\n      <hr>\n      <label for=\"code\">Enter your Verification Code Here</label><br>\n      <input type=\"text\" name=\"code\" [(ngModel)]=\"verificationCode\">\n  \n      <button (click)=\"verifyLoginCode()\">Verify</button>\n    </div>\n  \n  </div>\n  \n  <div *ngIf=\"user\">\n    You have successfully logged in with your phone number!\n  \n    UserId: {{ user?.uid }}\n  \n  </div> -->\n</ion-content>"

/***/ }),

/***/ "./src/app/phone-login/phone-login.component.scss":
/*!********************************************************!*\
  !*** ./src/app/phone-login/phone-login.component.scss ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Bob25lLWxvZ2luL3Bob25lLWxvZ2luLmNvbXBvbmVudC5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/phone-login/phone-login.component.ts":
/*!******************************************************!*\
  !*** ./src/app/phone-login/phone-login.component.ts ***!
  \******************************************************/
/*! exports provided: PhoneLoginComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PhoneLoginComponent", function() { return PhoneLoginComponent; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var PhoneLoginComponent = /** @class */ (function () {
    // export class PhoneNumber {
    //   country: string;
    //   area: string;
    //   prefix: string;
    //   line: string;
    //   // format phone numbers as E.164
    //   get e164() {
    //     const num = this.country + this.area + this.prefix + this.line
    //     return `+${num}`
    //   }
    // }
    function PhoneLoginComponent() {
    }
    // windowRef: any;
    // phoneNumber = new PhoneNumber()
    // verificationCode: string;
    // user: any;
    // constructor(private win: WindowService) { }
    PhoneLoginComponent.prototype.ngOnInit = function () {
        //   this.windowRef = this.win.windowRef
        //   this.windowRef.recaptchaVerifier = new firebase.auth.RecaptchaVerifier('recaptcha-container')
        //   this.windowRef.recaptchaVerifier.render()
    };
    PhoneLoginComponent = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-phone-login',
            template: __webpack_require__(/*! ./phone-login.component.html */ "./src/app/phone-login/phone-login.component.html"),
            styles: [__webpack_require__(/*! ./phone-login.component.scss */ "./src/app/phone-login/phone-login.component.scss")]
        })
        // export class PhoneNumber {
        //   country: string;
        //   area: string;
        //   prefix: string;
        //   line: string;
        //   // format phone numbers as E.164
        //   get e164() {
        //     const num = this.country + this.area + this.prefix + this.line
        //     return `+${num}`
        //   }
        // }
    ], PhoneLoginComponent);
    return PhoneLoginComponent;
}());



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
var environment = {
    production: true
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/fesm5/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(function (err) { return console.log(err); });


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\Iris Geraldo\Documents\Outalmafin\Outalma\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main.js.map