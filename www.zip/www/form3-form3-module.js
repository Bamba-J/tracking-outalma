(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["form3-form3-module"],{

/***/ "./src/app/form3/form3.module.ts":
/*!***************************************!*\
  !*** ./src/app/form3/form3.module.ts ***!
  \***************************************/
/*! exports provided: Form3PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Form3PageModule", function() { return Form3PageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _form3_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./form3.page */ "./src/app/form3/form3.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var routes = [
    {
        path: '',
        component: _form3_page__WEBPACK_IMPORTED_MODULE_5__["Form3Page"]
    }
];
var Form3PageModule = /** @class */ (function () {
    function Form3PageModule() {
    }
    Form3PageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes)
            ],
            declarations: [_form3_page__WEBPACK_IMPORTED_MODULE_5__["Form3Page"]]
        })
    ], Form3PageModule);
    return Form3PageModule;
}());



/***/ }),

/***/ "./src/app/form3/form3.page.html":
/*!***************************************!*\
  !*** ./src/app/form3/form3.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar>\n      <ion-title>Enlèvement</ion-title>\n    </ion-toolbar>\n<ion-toolbar color=\"primary\">\n    <ion-buttons slot=\"start\">\n        <ion-back-button text=\"Retour\" defaultHref=\"/tabs/tabs/forms\"></ion-back-button>\n      </ion-buttons>\n  <ion-title>Enlèvement</ion-title>\n</ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  \n  <div class=\"encadre\">\n  <ion-item (click)=\"setColor('#Iprenom3')\">\n    <ion-label position=\"floating\">Prénom :</ion-label>\n    <ion-input id=\"Iprenom3\" clearInput [(ngModel)]=\"Prenom3\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n  \n  <ion-item (click)=\"setColor('#Inom3')\">\n      <ion-label position=\"floating\">Nom :</ion-label>\n      <ion-input id=\"Inom3\" clearInput [(ngModel)]=\"Nom3\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n\n  <ion-item (click)=\"setColor('#Itelephone3')\">\n    <ion-label position=\"floating\">Téléphone :</ion-label>\n    <ion-input id=\"Itelephone3\" clearInput [(ngModel)]=\"Telephone3\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n</div>\n  <div class=\"encadre\">\n\n  <ion-item *ngIf=\"!alive0\" class=\"rd_name\" (click)=\"setColor('#Iad_rue_e3')\">\n    <ion-label position=\"floating\">Enlèvement à l'adresse :</ion-label>\n    <ion-input id=\"Iad_rue_e3\" clearInput [(ngModel)]=\"Ad_rue_E3\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n  <ion-item *ngIf=\"!alive0\" class=\"rd_postal\" (click)=\"setColor('#Iad_postal_e3')\">\n      <ion-label position=\"floating\">Code postal :</ion-label>\n      <ion-input id=\"Iad_postal_e3\" clearInput [(ngModel)]=\"Ad_postal_E3\" class=\"inputer centered\"></ion-input>\n    </ion-item>\n    <ion-item *ngIf=\"!alive0\" class=\"rd_postal\" (click)=\"setColor('#Iad_pays_e3')\">\n      <ion-label position=\"floating\">Pays :</ion-label>\n      <ion-input id=\"Iad_pays_e3\" clearInput [(ngModel)]=\"Ad_pays_E3\" class=\"inputer centered\"></ion-input>\n    </ion-item>\n  \n\n<ion-item *ngIf=\"!alive\" class=\"rd_name\" (click)=\"setColor('#Iad_rue_l3')\">\n  <ion-label position=\"floating\">Livraison à l'adresse :</ion-label>\n  <ion-input id=\"Iad_rue_l3\" clearInput [(ngModel)]=\"Ad_rue_L3\" class=\"inputer centered\"></ion-input>\n</ion-item>\n<ion-item *ngIf=\"!alive\" class=\"rd_postal\" (click)=\"setColor('#Iad_postal_l3')\">\n    <ion-label position=\"floating\">Code postal :</ion-label>\n    <ion-input id=\"Iad_postal_l3\" clearInput [(ngModel)]=\"Ad_postal_L3\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n  <ion-item class=\"rd_postal\" (click)=\"setColor('#Iad_pays_l3')\">\n    <ion-label position=\"floating\">Pays :</ion-label>\n    <ion-input id=\"Iad_pays_l3\" clearInput [(ngModel)]=\"Ad_pays_L3\" class=\"inputer centered\"></ion-input>\n  </ion-item>\n\n  </div>\n  <ion-button (click)=\"checkAg3()\">\n    Enregistrer\n  </ion-button>\n</ion-content>\n\n"

/***/ }),

/***/ "./src/app/form3/form3.page.scss":
/*!***************************************!*\
  !*** ./src/app/form3/form3.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host ion-input {\n  border-bottom: 1px solid darkgrey; }\n\n:host .hiden {\n  display: none; }\n\n:host .ddl {\n  min-width: 100vh !important; }\n\n:host .rd_nbr {\n  display: inline-block;\n  width: 30%; }\n\n:host .rd_name {\n  display: inline-block;\n  width: 70%; }\n\n:host .rd_postal {\n  display: inline-block;\n  width: 50%; }\n\n:host .encadre {\n  border: 2px solid #343582;\n  border-radius: 1em;\n  padding: 1%;\n  margin-bottom: 2%; }\n\n:host .inputer {\n  color: #525865;\n  border-radius: 4px;\n  border: 1px solid #d1d1d1;\n  box-shadow: inset 1px 2px 8px rgba(0, 0, 0, 0.07);\n  font-family: inherit;\n  font-size: 1em;\n  line-height: 1.45;\n  outline: none;\n  padding: 0.6em 1.45em 0.7em;\n  transition: .18s ease-out; }\n\n:host .inputer:hover {\n  box-shadow: inset 1px 2px 8px rgba(0, 0, 0, 0.02); }\n\n:host .inputer:focus {\n  color: #4b515d;\n  border: 1px solid #B8B6B6;\n  box-shadow: inset 1px 2px 4px rgba(0, 0, 0, 0.01), 0px 0px 8px rgba(0, 0, 0, 0.2); }\n\n:host .item-interactive, :host .item-lines-full {\n  --border-width: 0 0 0px 0;\n  --show-full-highlight: 1;\n  --show-inset-highlight: 0; }\n\n:host .item-interactive.ion-touched.ion-invalid, :host .item-interactive.item-has-focus {\n  --full-highlight-height:0px;\n  --inset-highlight-height:0px; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZm9ybTMvQzpcXFVzZXJzXFxJcmlzIEdlcmFsZG9cXERvY3VtZW50c1xcT3V0YWxtYWZpblxcT3V0YWxtYS9zcmNcXGFwcFxcZm9ybTNcXGZvcm0zLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVRLGlDQUFrQyxFQUFBOztBQUYxQztFQU1RLGFBQWEsRUFBQTs7QUFOckI7RUFVUSwyQkFBMEIsRUFBQTs7QUFWbEM7RUFjUSxxQkFBcUI7RUFDckIsVUFBUyxFQUFBOztBQWZqQjtFQWtCUSxxQkFBcUI7RUFDckIsVUFBVSxFQUFBOztBQW5CbEI7RUFzQlEscUJBQXFCO0VBQ3JCLFVBQVUsRUFBQTs7QUF2QmxCO0VBMEJRLHlCQUF5QjtFQUN6QixrQkFBa0I7RUFDbEIsV0FBVTtFQUNWLGlCQUFpQixFQUFBOztBQTdCekI7RUFpQ1EsY0FBYztFQUNkLGtCQUFrQjtFQUNsQix5QkFBeUI7RUFDekIsaURBQWlEO0VBQ2pELG9CQUFvQjtFQUNwQixjQUFjO0VBQ2QsaUJBQWlCO0VBQ2pCLGFBQWE7RUFDYiwyQkFBMkI7RUFJM0IseUJBQXlCLEVBQUE7O0FBN0NqQztFQWdETSxpREFBaUQsRUFBQTs7QUFoRHZEO0VBbURNLGNBQWM7RUFDZCx5QkFBeUI7RUFDekIsaUZBQWlGLEVBQUE7O0FBckR2RjtFQXlEUSx5QkFBZTtFQUNmLHdCQUFzQjtFQUN0Qix5QkFBdUIsRUFBQTs7QUEzRC9CO0VBOERRLDJCQUF3QjtFQUN4Qiw0QkFBeUIsRUFBQSIsImZpbGUiOiJzcmMvYXBwL2Zvcm0zL2Zvcm0zLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIjpob3N0e1xyXG4gICAgaW9uLWlucHV0IHtcclxuICAgICAgICBib3JkZXItYm90dG9tIDogMXB4IHNvbGlkIGRhcmtncmV5O1xyXG4gICAgfVxyXG5cclxuICAgIC5oaWRlbiB7XHJcbiAgICAgICAgZGlzcGxheTogbm9uZTtcclxuICAgICAgfVxyXG5cclxuICAgIC5kZGx7XHJcbiAgICAgICAgbWluLXdpZHRoOjEwMHZoICFpbXBvcnRhbnQ7XHJcbiAgICB9XHJcblxyXG4gICAgLnJkX25icntcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XHJcbiAgICAgICAgd2lkdGg6MzAlO1xyXG4gICAgfVxyXG4gICAgLnJkX25hbWV7XHJcbiAgICAgICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xyXG4gICAgICAgIHdpZHRoOiA3MCU7XHJcbiAgICB9XHJcbiAgICAucmRfcG9zdGFse1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZS1ibG9jaztcclxuICAgICAgICB3aWR0aDogNTAlO1xyXG4gICAgfVxyXG4gICAgLmVuY2FkcmV7XHJcbiAgICAgICAgYm9yZGVyOiAycHggc29saWQgIzM0MzU4MjtcclxuICAgICAgICBib3JkZXItcmFkaXVzOiAxZW07XHJcbiAgICAgICAgcGFkZGluZzoxJTtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAyJTtcclxuICAgIH1cclxuICAgIC5pbnB1dGVye1xyXG4gICAgICAgIC8vIGJhY2tncm91bmQ6ICNmZmY7XHJcbiAgICAgICAgY29sb3I6ICM1MjU4NjU7XHJcbiAgICAgICAgYm9yZGVyLXJhZGl1czogNHB4O1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNkMWQxZDE7XHJcbiAgICAgICAgYm94LXNoYWRvdzogaW5zZXQgMXB4IDJweCA4cHggcmdiYSgwLCAwLCAwLCAwLjA3KTtcclxuICAgICAgICBmb250LWZhbWlseTogaW5oZXJpdDtcclxuICAgICAgICBmb250LXNpemU6IDFlbTtcclxuICAgICAgICBsaW5lLWhlaWdodDogMS40NTtcclxuICAgICAgICBvdXRsaW5lOiBub25lO1xyXG4gICAgICAgIHBhZGRpbmc6IDAuNmVtIDEuNDVlbSAwLjdlbTtcclxuICAgICAgICAtd2Via2l0LXRyYW5zaXRpb246IC4xOHMgZWFzZS1vdXQ7XHJcbiAgICAgICAgLW1vei10cmFuc2l0aW9uOiAuMThzIGVhc2Utb3V0O1xyXG4gICAgICAgIC1vLXRyYW5zaXRpb246IC4xOHMgZWFzZS1vdXQ7XHJcbiAgICAgICAgdHJhbnNpdGlvbjogLjE4cyBlYXNlLW91dDtcclxuICAgIH1cclxuICAgIC5pbnB1dGVyOmhvdmVyIHtcclxuICAgICAgYm94LXNoYWRvdzogaW5zZXQgMXB4IDJweCA4cHggcmdiYSgwLCAwLCAwLCAwLjAyKTtcclxuICAgIH1cclxuICAgIC5pbnB1dGVyOmZvY3VzIHtcclxuICAgICAgY29sb3I6ICM0YjUxNWQ7XHJcbiAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNCOEI2QjY7XHJcbiAgICAgIGJveC1zaGFkb3c6IGluc2V0IDFweCAycHggNHB4IHJnYmEoMCwgMCwgMCwgMC4wMSksIDBweCAwcHggOHB4IHJnYmEoMCwgMCwgMCwgMC4yKTtcclxuICAgIH1cclxuXHJcbiAgICAuaXRlbS1pbnRlcmFjdGl2ZSwgLml0ZW0tbGluZXMtZnVsbCB7XHJcbiAgICAgICAgLS1ib3JkZXItd2lkdGg6IDAgMCAwcHggMDtcclxuICAgICAgICAtLXNob3ctZnVsbC1oaWdobGlnaHQ6IDE7XHJcbiAgICAgICAgLS1zaG93LWluc2V0LWhpZ2hsaWdodDogMDtcclxuICAgIH1cclxuICAgIC5pdGVtLWludGVyYWN0aXZlLmlvbi10b3VjaGVkLmlvbi1pbnZhbGlkLCAuaXRlbS1pbnRlcmFjdGl2ZS5pdGVtLWhhcy1mb2N1cyB7XHJcbiAgICAgICAgLS1mdWxsLWhpZ2hsaWdodC1oZWlnaHQ6MHB4O1xyXG4gICAgICAgIC0taW5zZXQtaGlnaGxpZ2h0LWhlaWdodDowcHg7XHJcbiAgICB9XHJcbiAgICBcclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/form3/form3.page.ts":
/*!*************************************!*\
  !*** ./src/app/form3/form3.page.ts ***!
  \*************************************/
/*! exports provided: Form3Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Form3Page", function() { return Form3Page; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_3__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};




var Form3Page = /** @class */ (function () {
    function Form3Page(toastCtrl) {
        this.toastCtrl = toastCtrl;
        this.VigiK = "";
        this.TabDemandes = [];
        this.TabUser2 = [];
        this.TabFields = [
            {
                Ad_pay_l: '',
                Ad_rue_l: '',
                Ad_pos_l: '',
                Ad_pay_e: '',
                Ad_rue_e: '',
                Ad_pos_e: '',
                Nom: '',
                Atype: 'Demande',
                Date_crea: '',
                Date_livraison: '',
                Desc_colis: '',
                Etat: 'En attente',
                Liste_envies: '',
                Num_colis: '',
                Num_com: '',
                Prenom: '',
                Site_prov: '',
                Type_demande: '3',
                Type_envoi: '',
                Telephone: '',
                i: '123456',
                icon: 'paper',
                id: '123456',
                Priorite: 'gris',
                UID: '',
            }
        ];
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        var InTabDemandes = [];
        //firebase.database().ref('/user/QLz2y3HDBKd9tGZkQ44K505dFN93').on("value", function(snapshot) {
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/user/' + firebase__WEBPACK_IMPORTED_MODULE_1__["auth"]().currentUser.uid).on("value", function (snapshot) {
            // firebase.database().ref('/form').on("value", function(snapshot) {
            var tg = snapshot.val();
            tg.forEach(function (entry) {
                console.log("ent :" + entry.displayName);
                InTabDemandes.push(entry);
            });
        }, function (error) {
            console.log("Error dans VoirDonnees: " + error.code);
        });
        this.TabDemandes = InTabDemandes;
        console.log("voir tabDD ", this.TabDemandes);
        //this.Nom2 = this.TabDemandes[0]['displayName'];
        this.Telephone3 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['phoneNumber'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Nom3 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Nom'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Prenom3 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Prenom'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_rue_L3 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Ad_rue_l'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_postal_L3 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Ad_pos_l'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_pays_L3 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Ad_pay_l'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_rue_E3 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Ad_rue_e'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_postal_E3 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Ad_pos_e'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
        this.Ad_pays_E3 = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].decrypt(this.TabDemandes[0]['Ad_pay_e'].trim(), VigiK.trim()).toString(crypto_js__WEBPACK_IMPORTED_MODULE_3__["enc"].Utf8);
    }
    Form3Page.prototype.ngOnInit = function () {
    };
    Form3Page.prototype.checkAg3 = function () {
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        var utc = new Date().toJSON().slice(0, 10).replace(/-/g, '-');
        var elmpre3 = document.querySelector("#Iprenom3");
        var elmnom3 = document.querySelector("#Inom3");
        var elmtel3 = document.querySelector("#Itelephone3");
        var elmrueE3 = document.querySelector("#Iad_rue_e3");
        var elmposE3 = document.querySelector("#Iad_postal_e3");
        var elmpayE3 = document.querySelector("#Iad_pays_e3");
        var elmrueL3 = document.querySelector("#Iad_rue_l3");
        var elmposL3 = document.querySelector("#Iad_postal_l3");
        var elmpayL3 = document.querySelector("#Iad_pays_l3");
        this.TabFields[0]['UID'] = firebase__WEBPACK_IMPORTED_MODULE_1__["auth"]().currentUser.uid;
        this.TabFields[0]['Date_crea'] = utc;
        if (!this.Prenom3 || this.Prenom3.length < 1) {
            elmpre3.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Prenom'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Prenom3.trim(), VigiK.trim()).toString();
            elmpre3.style.borderColor = 'green';
        }
        if (!this.Nom3 || this.Nom3.length < 1) {
            elmnom3.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Nom'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Nom3.trim(), VigiK.trim()).toString();
            elmnom3.style.borderColor = 'green';
        }
        if (!this.Telephone3 || this.Telephone3.length < 10) {
            elmtel3.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Telephone'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Telephone3.trim(), VigiK.trim()).toString();
            elmtel3.style.borderColor = 'green';
        }
        if (!this.Ad_rue_E3 || this.Ad_rue_E3.length < 2) {
            elmrueE3.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_rue_e'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_rue_E3.trim(), VigiK.trim()).toString();
            elmrueE3.style.borderColor = 'green';
        }
        if (!this.Ad_postal_E3 || this.Ad_postal_E3.length < 2) {
            elmposE3.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_pos_e'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_postal_E3.trim(), VigiK.trim()).toString();
            elmposE3.style.borderColor = 'green';
        }
        if (!this.Ad_pays_E3 || this.Ad_pays_E3.length < 2) {
            elmpayE3.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_pay_e'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_pays_E3.trim(), VigiK.trim()).toString();
            elmpayE3.style.borderColor = 'green';
        }
        if (!this.Ad_rue_L3 || this.Ad_rue_L3.length < 2) {
            elmrueL3.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_rue_l'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_pays_L3.trim(), VigiK.trim()).toString();
            elmrueL3.style.borderColor = 'green';
        }
        if (!this.Ad_postal_L3 || this.Ad_postal_L3.length < 2) {
            elmposL3.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_pos_l'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_postal_L3.trim(), VigiK.trim()).toString();
            elmposL3.style.borderColor = 'green';
        }
        if (!this.Ad_pays_L3 || this.Ad_pays_L3.length < 2) {
            elmpayL3.style.borderColor = '#FF0000';
            return;
        }
        else {
            this.TabFields[0]['Ad_pay_l'] = crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt(this.Ad_pays_L3.trim(), VigiK.trim()).toString();
            elmpayL3.style.borderColor = 'green';
        }
        this.writeUserData();
        this.presentToastBravo();
    };
    Form3Page.prototype.presentToastBravo = function () {
        return __awaiter(this, void 0, void 0, function () {
            var tooast;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toastCtrl.create({
                            message: 'Votre demande a bien été enregistrée.',
                            duration: 3000,
                            position: 'middle',
                            color: 'success'
                        })];
                    case 1:
                        tooast = _a.sent();
                        tooast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    Form3Page.prototype.writeUserData = function () {
        var _this = this;
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        var lena = 0;
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/suivi_details').on("value", function (snapshot) {
            var tg = snapshot.val();
            lena = tg.length;
        }, function (error) {
            console.log("Error dans VoirDonnees: " + error.code);
        });
        this.TabFields[0]['i'] = lena.toString();
        this.TabFields[0]['id'] = lena.toString();
        console.log("TABFIELD" + this.TabFields[0]['i']);
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('suivi_details/' + lena).set(this.TabFields[0]).then(function (data) {
            // console.log('data :',data);
            console.log("voir donn", _this.TabUser2);
        }, function (error) {
            console.log(error, _this.TabUser2);
        });
        var utc = new Date().toJSON().slice(0, 10).replace(/-/g, '/');
        var TabFirstMsg = [];
        TabFirstMsg.push({ DateMsg: utc, Message: crypto_js__WEBPACK_IMPORTED_MODULE_3__["AES"].encrypt('Votre demande est en cours de traitement'.trim(), VigiK.trim()).toString(), Notification: 1, UserID: 'Compute' });
        firebase__WEBPACK_IMPORTED_MODULE_1__["database"]().ref('/msg_suivi/' + (lena - 1)).set(TabFirstMsg).then(function (data) {
        }, function (error) {
            console.log(error, TabFirstMsg);
        });
    };
    Form3Page.prototype.setColor = function (idlbl) {
        var id4elem = document.querySelector(idlbl);
        id4elem.style.borderColor = '#FFFFFF';
    };
    Form3Page = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-form3',
            template: __webpack_require__(/*! ./form3.page.html */ "./src/app/form3/form3.page.html"),
            styles: [__webpack_require__(/*! ./form3.page.scss */ "./src/app/form3/form3.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
    ], Form3Page);
    return Form3Page;
}());



/***/ })

}]);
//# sourceMappingURL=form3-form3-module.js.map