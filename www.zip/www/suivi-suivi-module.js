(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["suivi-suivi-module"],{

/***/ "./src/app/suivi/suivi.module.ts":
/*!***************************************!*\
  !*** ./src/app/suivi/suivi.module.ts ***!
  \***************************************/
/*! exports provided: SuiviPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuiviPageModule", function() { return SuiviPageModule; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _suivi_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./suivi.page */ "./src/app/suivi/suivi.page.ts");
/* harmony import */ var _Modal_message_message_module__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Modal/message/message.module */ "./src/app/Modal/message/message.module.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};







var routes = [
    {
        path: '',
        component: _suivi_page__WEBPACK_IMPORTED_MODULE_5__["SuiviPage"]
    }
];
var SuiviPageModule = /** @class */ (function () {
    function SuiviPageModule() {
    }
    SuiviPageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_1__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouterModule"].forChild(routes),
                _Modal_message_message_module__WEBPACK_IMPORTED_MODULE_6__["MessagePageModule"]
            ],
            declarations: [_suivi_page__WEBPACK_IMPORTED_MODULE_5__["SuiviPage"]]
        })
    ], SuiviPageModule);
    return SuiviPageModule;
}());



/***/ }),

/***/ "./src/app/suivi/suivi.page.html":
/*!***************************************!*\
  !*** ./src/app/suivi/suivi.page.html ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n<ion-header>\n    <ion-toolbar>\n      </ion-toolbar>\n  <ion-toolbar color=\"primary\">\n    <ion-title >Suivi</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n\n\n\n<ion-content class=\"quai\" padding>\n\n    <ion-card *ngFor=\"let s of suivi\"  [class]=\"s.Priorite\" >\n        <ion-item>\n          <ion-icon [name]=\"s.icon\" size=\"large\" class=\"broown\" slot=\"start\"></ion-icon>\n          <ion-card-subtitle  size=\"100%\">{{s.Atype}} #{{s.id}}</ion-card-subtitle>\n          <ion-button *ngIf=\"s.Atype==='Colis'\" (click)=\"goToPDF(s.id)\">Facture</ion-button>\n          <ion-button *ngIf=\"s.Etat==='En attente de validation du devis'\" (click)=\"goToPDF(s.id)\">Devis</ion-button>\n          <ion-button *ngIf=\"s.Etat==='En attente de validation du devis'\" (click)=\"Accepter(s.id)\">Accepter le devis</ion-button>\n          <ion-card-subtitle slot=\"end\">{{s.Date_crea}}</ion-card-subtitle>\n          \n        </ion-item>\n        <ion-button (click)=\"goToChat(s.id,s.Ad_pay_e,s.Ad_rue_e,s.Ad_pos_e, s.Ad_pay_l,s.Ad_rue_l,s.Ad_pos_l,s.Desc_colis,s.Site_prov,s.Telephone,s.Liste_envies,s.Type_envoi)\" Expand=\"full\" fill=\"clear\">\n        <ion-card-content >\n          {{s.Etat}}\n        </ion-card-content></ion-button>\n      </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/suivi/suivi.page.scss":
/*!***************************************!*\
  !*** ./src/app/suivi/suivi.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ":host .broown {\n  color: #A0522D; }\n\n:host .vert {\n  background-color: #c3f37b; }\n\n:host .orange {\n  background-color: #f5c670; }\n\n:host .gris {\n  background-color: rgba(255, 255, 255, 0.26); }\n\n:host .rouge {\n  background-color: #f57e7e;\n  color: white !important; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc3VpdmkvQzpcXFVzZXJzXFxJcmlzIEdlcmFsZG9cXERvY3VtZW50c1xcT3V0YWxtYWZpblxcT3V0YWxtYS9zcmNcXGFwcFxcc3VpdmlcXHN1aXZpLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUVRLGNBQWMsRUFBQTs7QUFGdEI7RUFLTSx5QkFBb0MsRUFBQTs7QUFMMUM7RUFRTSx5QkFBb0MsRUFBQTs7QUFSMUM7RUFXTSwyQ0FBMkMsRUFBQTs7QUFYakQ7RUFjTSx5QkFBb0M7RUFDcEMsdUJBQXNCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC9zdWl2aS9zdWl2aS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyI6aG9zdHtcclxuICAgIC5icm9vd257XHJcbiAgICAgICAgY29sb3I6ICNBMDUyMkQ7XHJcbiAgICB9XHJcbiAgICAudmVydHtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE5NSwgMjQzLCAxMjMpO1xyXG4gICAgfVxyXG4gICAgLm9yYW5nZXtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI0NSwgMTk4LCAxMTIpO1xyXG4gICAgICB9XHJcbiAgICAuZ3Jpc3tcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiYSgyNTUsIDI1NSwgMjU1LCAwLjI2KTtcclxuICAgIH1cclxuICAgIC5yb3VnZXtcclxuICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDI0NSwgMTI2LCAxMjYpO1xyXG4gICAgICBjb2xvcjogd2hpdGUhaW1wb3J0YW50O1xyXG4gICAgfVxyXG5cclxufSJdfQ== */"

/***/ }),

/***/ "./src/app/suivi/suivi.page.ts":
/*!*************************************!*\
  !*** ./src/app/suivi/suivi.page.ts ***!
  \*************************************/
/*! exports provided: SuiviPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SuiviPage", function() { return SuiviPage; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _Modal_message_message_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../Modal/message/message.page */ "./src/app/Modal/message/message.page.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! crypto-js */ "./node_modules/crypto-js/index.js");
/* harmony import */ var crypto_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(crypto_js__WEBPACK_IMPORTED_MODULE_4__);
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (undefined && undefined.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};





var devis;
var suivis = [];
var SuiviPage = /** @class */ (function () {
    function SuiviPage(modalCtrl, navCtrl) {
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.VigiK = "";
        this.suividem = [
            {
                id: 4,
                i: '8989',
                etat: 'En attente',
                date: '20/12/18',
                class: 'gris',
            },
            {
                id: 1,
                i: '3455',
                etat: 'En cours de traitement',
                date: '10/02/19',
                class: 'vert'
            },
            { id: 2,
                i: '6789',
                etat: 'En attente de réponse',
                date: '21/12/18',
                class: 'rouge',
            },
            {
                id: 3,
                i: '3678',
                etat: 'En attente',
                date: '14/01/19',
                class: 'gris',
            },
        ];
        this.suivi = [];
        this.suivis = this.suivi;
        this.Atype = this.suividem['0'].date;
        var VigiK = "";
        firebase__WEBPACK_IMPORTED_MODULE_3__["database"]().ref('/Cry/').on("value", function (snapshot) {
            var tg = snapshot.val();
            VigiK = tg[0]['Vigi'];
        }, function (error) {
            console.log("Error dans Cry: " + error.code);
        });
        this.VigiK = VigiK;
        this.refreshPage();
    }
    SuiviPage.prototype.refreshPage = function () {
        var _this = this;
        setTimeout(function () {
            _this.cooling();
        }, 10000);
    };
    SuiviPage.prototype.cooling = function () {
        var _this = this;
        setTimeout(function () {
            _this.Voirdonnees();
            _this.refreshPage();
        }, 10000);
    };
    SuiviPage.prototype.goToChat = function (id, Ad_pay_e, Ad_rue_e, Ad_pos_e, Ad_pay_l, Ad_rue_l, Ad_pos_l, Desc_colis, Site_prov, Telephone, Liste_envies, Type_envoi) {
        return __awaiter(this, void 0, void 0, function () {
            var modal;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.modalCtrl.create({
                            component: _Modal_message_message_page__WEBPACK_IMPORTED_MODULE_1__["MessagePage"],
                            componentProps: { 'suivi': this.suivi,
                                'Adresse_liv': Ad_pay_l + " " + Ad_pos_l + " " + Ad_rue_l,
                                'Adresse_exp': Ad_pay_e + " " + Ad_pos_e + " " + Ad_rue_e,
                                'Desc_colis': Desc_colis,
                                'Site_prov': Site_prov,
                                "Telephone": Telephone,
                                "List_envie": Liste_envies,
                                "Type_envoi": Type_envoi,
                                'i': id }
                        })];
                    case 1:
                        modal = _a.sent();
                        modal.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    SuiviPage.prototype.Voirdonnees = function () {
        var _this = this;
        return new Promise(function (resolve) {
            setTimeout(function () {
                resolve('resolved');
                var InTabDemandes = [];
                firebase__WEBPACK_IMPORTED_MODULE_3__["database"]().ref('/suivi_details').on("value", function (snapshot) {
                    var sv = snapshot.val();
                    sv.forEach(function (entry) {
                        InTabDemandes.push(entry);
                    });
                }, function (error) {
                });
                _this.suivi = InTabDemandes;
                suivis = _this.suivi;
                var val = firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.uid;
                if (val && val.trim() != '') {
                    _this.suivi = suivis.filter(function (s) {
                        return (s.UID.toLowerCase().indexOf(val.toLowerCase()) > -1);
                    });
                }
            }, 1000);
        });
    };
    SuiviPage.prototype.ngOnInit = function () {
        return __awaiter(this, void 0, void 0, function () {
            var icon;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.Voirdonnees()];
                    case 1:
                        _a.sent();
                        suivis = this.suivi;
                        if (true) {
                            icon = "paper";
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    SuiviPage.prototype.getItems3 = function () {
        return __awaiter(this, void 0, void 0, function () {
            var val, _a;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0: 
                    // Reset items back to all of the items
                    return [4 /*yield*/, this.Voirdonnees()
                        // set val to the value of the searchbar
                    ];
                    case 1:
                        // Reset items back to all of the items
                        _b.sent();
                        val = firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.uid;
                        if (!(val && val.trim() != '')) return [3 /*break*/, 3];
                        _a = this;
                        return [4 /*yield*/, suivis.filter(function (s) {
                                return (s.UID.toLowerCase().indexOf(val.toLowerCase()) > -1);
                            })];
                    case 2:
                        _a.suivi = _b.sent();
                        _b.label = 3;
                    case 3: return [2 /*return*/];
                }
            });
        });
    };
    SuiviPage.prototype.Accepter = function (id) {
        firebase__WEBPACK_IMPORTED_MODULE_3__["database"]().ref('suivi_details/' + id + '/Etat').set(crypto_js__WEBPACK_IMPORTED_MODULE_4__["AES"].encrypt('En attente de paiement'.trim(), this.VigiK.trim()).toString()).then(function (snapshot) {
        }, function (error) {
            console.log(error);
        });
        this.ngOnInit();
    };
    SuiviPage.prototype.goToPDF = function (id) {
        firebase__WEBPACK_IMPORTED_MODULE_3__["database"]().ref('devis/' + id).on("value", function (snapshot) {
            devis = snapshot.val();
        }, function (error) {
        });
        this.inp = devis;
        var u = 0;
        var inpu;
        inpu = devis.length;
        var input;
        while (inpu != u) {
            input += "&lib" + u + "=" + this.inp[u]['Libellé'] + "&pri" + u + "=" + this.inp[u]['Prix'];
            u++;
        }
        window.open("http://localhost:8000/?a=" + firebase__WEBPACK_IMPORTED_MODULE_3__["auth"]().currentUser.displayName + '&id=' + id + '&y=2' + input + '', '_system', 'location=yes');
    };
    SuiviPage = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-suivi',
            template: __webpack_require__(/*! ./suivi.page.html */ "./src/app/suivi/suivi.page.html"),
            styles: [__webpack_require__(/*! ./suivi.page.scss */ "./src/app/suivi/suivi.page.scss")]
        }),
        __metadata("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]])
    ], SuiviPage);
    return SuiviPage;
}());



/***/ })

}]);
//# sourceMappingURL=suivi-suivi-module.js.map