(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["tab1-tab1-module"],{

/***/ "./src/app/tab1/tab1.module.ts":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.module.ts ***!
  \*************************************/
/*! exports provided: Tab1PageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1PageModule", function() { return Tab1PageModule; });
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _tab1_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tab1.page */ "./src/app/tab1/tab1.page.ts");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};






var Tab1PageModule = /** @class */ (function () {
    function Tab1PageModule() {
    }
    Tab1PageModule = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["NgModule"])({
            imports: [
                _ionic_angular__WEBPACK_IMPORTED_MODULE_0__["IonicModule"],
                _angular_common__WEBPACK_IMPORTED_MODULE_3__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_1__["RouterModule"].forChild([{ path: '', component: _tab1_page__WEBPACK_IMPORTED_MODULE_5__["Tab1Page"] }])
            ],
            declarations: [_tab1_page__WEBPACK_IMPORTED_MODULE_5__["Tab1Page"]]
        })
    ], Tab1PageModule);
    return Tab1PageModule;
}());



/***/ }),

/***/ "./src/app/tab1/tab1.page.html":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.page.html ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-img src=\"/assets/img/logo-white.png\" class=\"logo\"></ion-img>\n    <ion-label class=\"outalma-title\">Outalmapp</ion-label>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <!-- <ion-img [src]=\"../img/logo.png\"></ion-img> -->\n    <!-- <ion-card class=\"welcome-card\">\n      <ion-img src=\"/assets/shapes.svg\"></ion-img>\n      <ion-card-header>\n        <ion-card-subtitle>Get Started</ion-card-subtitle>\n        <ion-card-title>Welcome to Ionic</ion-card-title>\n      </ion-card-header>\n      <ion-card-content>\n        <p>Now that your app has been created, you'll want to start building out features and components. Check out some of the resources below for next steps.</p>\n      </ion-card-content>\n    </ion-card> -->\n    <ion-list lines=\"none\" class=\"itlist\">\n      <ion-list-header>\n        <ion-label><ion-icon slot=\"start\" color=\"medium\" name=\"search\"></ion-icon>Rechercher</ion-label>\n      </ion-list-header>\n      <hr>\n      <ion-item href=\"https://ionicframework.com/docs/\" class=\"choix\">\n        <ion-icon slot=\"start\" color=\"medium\" name=\"list-box\"></ion-icon>\n        <ion-label>Tableau de suivi des commandes</ion-label>\n      </ion-item>\n      <hr>\n      <ion-item href=\"https://ionicframework.com/docs/building/scaffolding\" class=\"choix\">\n        <ion-icon slot=\"start\" color=\"medium\" name=\"archive\"></ion-icon>\n        <ion-label>Mise à jour et édition des suivis</ion-label>\n      </ion-item>\n      <hr>\n      <ion-item href=\"https://ionicframework.com/docs/layout/structure\" class=\"choix\">\n        <ion-icon slot=\"start\" color=\"medium\" name=\"chatbubbles\"></ion-icon>\n        <ion-label>Discussion Clientèle</ion-label>\n      </ion-item>\n      <hr>\n      <ion-item href=\"https://ionicframework.com/docs/theming/basics\" class=\"choix\">\n        <ion-icon slot=\"start\" color=\"medium\" name=\"add-circle-outline\"></ion-icon>\n        <ion-label>Ajouter un client ou une demande</ion-label>\n      </ion-item>\n      <hr>\n    </ion-list>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/tab1/tab1.page.scss":
/*!*************************************!*\
  !*** ./src/app/tab1/tab1.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "hr {\n  height: 3px !important;\n  width: 100% !important;\n  background: #ABB1B6 !important;\n  display: block !important;\n  font-size: 2em !important;\n  opacity: 1 !important;\n  visibility: visible !important; }\n\n.bg-dark-blue {\n  background-color: #333986; }\n\n.outalma-title {\n  color: white;\n  float: left;\n  margin-left: -2vh;\n  margin-top: 1vh; }\n\n.logo {\n  height: 5vh;\n  margin-left: -4vh;\n  float: left;\n  overflow: hidden; }\n\n.choix {\n  height: 5vh;\n  margin-bottom: 5vh; }\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvdGFiMS9DOlxcVXNlcnNcXElyaXMgR2VyYWxkb1xcRG9jdW1lbnRzXFxPdXRhbG1hZmluXFxPdXRhbG1hL3NyY1xcYXBwXFx0YWIxXFx0YWIxLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTtFQUVFLHNCQUFzQjtFQUN0QixzQkFBc0I7RUFDdEIsOEJBQThCO0VBQzlCLHlCQUF5QjtFQUN6Qix5QkFBeUI7RUFDekIscUJBQXFCO0VBQ3JCLDhCQUE4QixFQUFBOztBQUVoQztFQUNFLHlCQUF5QixFQUFBOztBQUszQjtFQUNFLFlBQVk7RUFDWixXQUFVO0VBQ1YsaUJBQWlCO0VBQ2pCLGVBQWUsRUFBQTs7QUFHakI7RUFDRSxXQUFXO0VBQ1gsaUJBQWdCO0VBQ2hCLFdBQVU7RUFDVixnQkFBZ0IsRUFBQTs7QUFHbEI7RUFDRSxXQUFVO0VBQ1Ysa0JBQWlCLEVBQUEiLCJmaWxlIjoic3JjL2FwcC90YWIxL3RhYjEucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG5ociB7XG4gIC8vYm9yZGVyOiAycHggc29saWQgcmVkICFpbXBvcnRhbnQ7XG4gIGhlaWdodDogM3B4ICFpbXBvcnRhbnQ7XG4gIHdpZHRoOiAxMDAlICFpbXBvcnRhbnQ7XG4gIGJhY2tncm91bmQ6ICNBQkIxQjYgIWltcG9ydGFudDtcbiAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcbiAgZm9udC1zaXplOiAyZW0gIWltcG9ydGFudDtcbiAgb3BhY2l0eTogMSAhaW1wb3J0YW50O1xuICB2aXNpYmlsaXR5OiB2aXNpYmxlICFpbXBvcnRhbnQ7XG59XG4uYmctZGFyay1ibHVle1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzMzOTg2O1xuICAvLyBwYWRkaW5nLXRvcDogMnZoO1xuICAvLyBwYWRkaW5nLWJvdHRvbTogMnZoO1xufVxuXG4ub3V0YWxtYS10aXRsZXtcbiAgY29sb3I6IHdoaXRlO1xuICBmbG9hdDpsZWZ0O1xuICBtYXJnaW4tbGVmdDogLTJ2aDtcbiAgbWFyZ2luLXRvcDogMXZoO1xufVxuXG4ubG9nbyB7XG4gIGhlaWdodDogNXZoO1xuICBtYXJnaW4tbGVmdDotNHZoO1xuICBmbG9hdDpsZWZ0O1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuXG4uY2hvaXgge1xuICBoZWlnaHQ6NXZoO1xuICBtYXJnaW4tYm90dG9tOjV2aDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/tab1/tab1.page.ts":
/*!***********************************!*\
  !*** ./src/app/tab1/tab1.page.ts ***!
  \***********************************/
/*! exports provided: Tab1Page */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tab1Page", function() { return Tab1Page; });
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
var __decorate = (undefined && undefined.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};

var Tab1Page = /** @class */ (function () {
    function Tab1Page() {
    }
    Tab1Page = __decorate([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["Component"])({
            selector: 'app-tab1',
            template: __webpack_require__(/*! ./tab1.page.html */ "./src/app/tab1/tab1.page.html"),
            styles: [__webpack_require__(/*! ./tab1.page.scss */ "./src/app/tab1/tab1.page.scss")]
        })
    ], Tab1Page);
    return Tab1Page;
}());



/***/ })

}]);
//# sourceMappingURL=tab1-tab1-module.js.map